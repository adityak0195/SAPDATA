package com.knorr_bremse.sap_com.sernrUpdateInProdOrder;

public class ZZQ_SERNR_UPDATE_IN_PRODORDERProxy implements com.knorr_bremse.sap_com.sernrUpdateInProdOrder.ZZQ_SERNR_UPDATE_IN_PRODORDER_PortType {
  private String _endpoint = null;
  private com.knorr_bremse.sap_com.sernrUpdateInProdOrder.ZZQ_SERNR_UPDATE_IN_PRODORDER_PortType zZQ_SERNR_UPDATE_IN_PRODORDER_PortType = null;
  
  public ZZQ_SERNR_UPDATE_IN_PRODORDERProxy() {
    _initZZQ_SERNR_UPDATE_IN_PRODORDERProxy();
  }
  
  public ZZQ_SERNR_UPDATE_IN_PRODORDERProxy(String endpoint) {
    _endpoint = endpoint;
    _initZZQ_SERNR_UPDATE_IN_PRODORDERProxy();
  }
  
  private void _initZZQ_SERNR_UPDATE_IN_PRODORDERProxy() {
    try {
      zZQ_SERNR_UPDATE_IN_PRODORDER_PortType = (new com.knorr_bremse.sap_com.sernrUpdateInProdOrder.ZZQ_SERNR_UPDATE_IN_PRODORDER_ServiceLocator()).getCONF_EXCH_SERNR();
      if (zZQ_SERNR_UPDATE_IN_PRODORDER_PortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)zZQ_SERNR_UPDATE_IN_PRODORDER_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)zZQ_SERNR_UPDATE_IN_PRODORDER_PortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (zZQ_SERNR_UPDATE_IN_PRODORDER_PortType != null)
      ((javax.xml.rpc.Stub)zZQ_SERNR_UPDATE_IN_PRODORDER_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.knorr_bremse.sap_com.sernrUpdateInProdOrder.ZZQ_SERNR_UPDATE_IN_PRODORDER_PortType getZZQ_SERNR_UPDATE_IN_PRODORDER_PortType() {
    if (zZQ_SERNR_UPDATE_IN_PRODORDER_PortType == null)
      _initZZQ_SERNR_UPDATE_IN_PRODORDERProxy();
    return zZQ_SERNR_UPDATE_IN_PRODORDER_PortType;
  }
  
  public void ZZQ_SERNR_UPDATE_IN_PRODORDER(java.lang.String IV_CALLER_ID, java.lang.String IV_CURRENT_SERIALNUMBER, java.lang.String IV_DO_ALL_PRECHECKS_ONLY, java.lang.String IV_MATERIAL_NUMBER, java.lang.String IV_NEW_SERIALNUMBER, java.lang.String IV_PRODUCTION_ORDER, com.knorr_bremse.sap_com.sernrUpdateInProdOrder.holders.ZZQ_T_IBASE_DATA_FILEHolder ET_CONFIG, com.knorr_bremse.sap_com.sernrUpdateInProdOrder.holders.ZZQ_T_CONFIG_RETURN_MESSAGEHolder ET_RETURN, javax.xml.rpc.holders.StringHolder e_FL_CANCEL, javax.xml.rpc.holders.StringHolder e_FL_REWORK) throws java.rmi.RemoteException{
    if (zZQ_SERNR_UPDATE_IN_PRODORDER_PortType == null)
      _initZZQ_SERNR_UPDATE_IN_PRODORDERProxy();
    zZQ_SERNR_UPDATE_IN_PRODORDER_PortType.ZZQ_SERNR_UPDATE_IN_PRODORDER(IV_CALLER_ID, IV_CURRENT_SERIALNUMBER, IV_DO_ALL_PRECHECKS_ONLY, IV_MATERIAL_NUMBER, IV_NEW_SERIALNUMBER, IV_PRODUCTION_ORDER, ET_CONFIG, ET_RETURN, e_FL_CANCEL, e_FL_REWORK);
  }
  
  
}