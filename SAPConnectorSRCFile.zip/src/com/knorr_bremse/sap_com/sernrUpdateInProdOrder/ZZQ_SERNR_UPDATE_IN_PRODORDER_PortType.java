/**
 * ZZQ_SERNR_UPDATE_IN_PRODORDER_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.sernrUpdateInProdOrder;

public interface ZZQ_SERNR_UPDATE_IN_PRODORDER_PortType extends java.rmi.Remote {
    public void ZZQ_SERNR_UPDATE_IN_PRODORDER(java.lang.String IV_CALLER_ID, java.lang.String IV_CURRENT_SERIALNUMBER, java.lang.String IV_DO_ALL_PRECHECKS_ONLY, java.lang.String IV_MATERIAL_NUMBER, java.lang.String IV_NEW_SERIALNUMBER, java.lang.String IV_PRODUCTION_ORDER, com.knorr_bremse.sap_com.sernrUpdateInProdOrder.holders.ZZQ_T_IBASE_DATA_FILEHolder ET_CONFIG, com.knorr_bremse.sap_com.sernrUpdateInProdOrder.holders.ZZQ_T_CONFIG_RETURN_MESSAGEHolder ET_RETURN, javax.xml.rpc.holders.StringHolder e_FL_CANCEL, javax.xml.rpc.holders.StringHolder e_FL_REWORK) throws java.rmi.RemoteException;
}
