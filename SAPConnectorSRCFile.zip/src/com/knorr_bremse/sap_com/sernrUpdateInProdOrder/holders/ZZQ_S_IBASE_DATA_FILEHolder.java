/**
 * ZZQ_S_IBASE_DATA_FILEHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.sernrUpdateInProdOrder.holders;

public final class ZZQ_S_IBASE_DATA_FILEHolder implements javax.xml.rpc.holders.Holder {
    public com.knorr_bremse.sap_com.sernrUpdateInProdOrder.ZZQ_S_IBASE_DATA_FILE value;

    public ZZQ_S_IBASE_DATA_FILEHolder() {
    }

    public ZZQ_S_IBASE_DATA_FILEHolder(com.knorr_bremse.sap_com.sernrUpdateInProdOrder.ZZQ_S_IBASE_DATA_FILE value) {
        this.value = value;
    }

}
