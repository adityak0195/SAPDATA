/**
 * ZZQ_CONFIG_RETURN_MESSAGEHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.sernrUpdateInProdOrder.holders;

public final class ZZQ_CONFIG_RETURN_MESSAGEHolder implements javax.xml.rpc.holders.Holder {
    public com.knorr_bremse.sap_com.sernrUpdateInProdOrder.ZZQ_CONFIG_RETURN_MESSAGE value;

    public ZZQ_CONFIG_RETURN_MESSAGEHolder() {
    }

    public ZZQ_CONFIG_RETURN_MESSAGEHolder(com.knorr_bremse.sap_com.sernrUpdateInProdOrder.ZZQ_CONFIG_RETURN_MESSAGE value) {
        this.value = value;
    }

}
