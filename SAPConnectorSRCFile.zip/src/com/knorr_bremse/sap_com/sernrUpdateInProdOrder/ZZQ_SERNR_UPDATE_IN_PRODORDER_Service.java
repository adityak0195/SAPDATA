/**
 * ZZQ_SERNR_UPDATE_IN_PRODORDER_Service.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.sernrUpdateInProdOrder;

public interface ZZQ_SERNR_UPDATE_IN_PRODORDER_Service extends javax.xml.rpc.Service {
    public java.lang.String getCONF_EXCH_SERNRAddress();
    public void setHttpAddress(java.lang.String address);

    public com.knorr_bremse.sap_com.sernrUpdateInProdOrder.ZZQ_SERNR_UPDATE_IN_PRODORDER_PortType getCONF_EXCH_SERNR() throws javax.xml.rpc.ServiceException;

    public com.knorr_bremse.sap_com.sernrUpdateInProdOrder.ZZQ_SERNR_UPDATE_IN_PRODORDER_PortType getCONF_EXCH_SERNR(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
