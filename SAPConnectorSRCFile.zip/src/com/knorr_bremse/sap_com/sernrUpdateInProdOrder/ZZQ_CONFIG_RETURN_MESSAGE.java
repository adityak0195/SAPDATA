/**
 * ZZQ_CONFIG_RETURN_MESSAGE.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.sernrUpdateInProdOrder;

public class ZZQ_CONFIG_RETURN_MESSAGE  implements java.io.Serializable {
    private java.lang.String MSG_LINE;

    private java.lang.String MSG_TYPE;

    private java.lang.String MSG_ID;

    private java.lang.String MSG_NO;

    private java.lang.String MSG_V1;

    private java.lang.String MSG_V2;

    private java.lang.String MSG_V3;

    private java.lang.String MSG_V4;

    private java.lang.String MSG_TXT;

    public ZZQ_CONFIG_RETURN_MESSAGE() {
    }

    public ZZQ_CONFIG_RETURN_MESSAGE(
           java.lang.String MSG_LINE,
           java.lang.String MSG_TYPE,
           java.lang.String MSG_ID,
           java.lang.String MSG_NO,
           java.lang.String MSG_V1,
           java.lang.String MSG_V2,
           java.lang.String MSG_V3,
           java.lang.String MSG_V4,
           java.lang.String MSG_TXT) {
           this.MSG_LINE = MSG_LINE;
           this.MSG_TYPE = MSG_TYPE;
           this.MSG_ID = MSG_ID;
           this.MSG_NO = MSG_NO;
           this.MSG_V1 = MSG_V1;
           this.MSG_V2 = MSG_V2;
           this.MSG_V3 = MSG_V3;
           this.MSG_V4 = MSG_V4;
           this.MSG_TXT = MSG_TXT;
    }


    /**
     * Gets the MSG_LINE value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @return MSG_LINE
     */
    public java.lang.String getMSG_LINE() {
        return MSG_LINE;
    }


    /**
     * Sets the MSG_LINE value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @param MSG_LINE
     */
    public void setMSG_LINE(java.lang.String MSG_LINE) {
        this.MSG_LINE = MSG_LINE;
    }


    /**
     * Gets the MSG_TYPE value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @return MSG_TYPE
     */
    public java.lang.String getMSG_TYPE() {
        return MSG_TYPE;
    }


    /**
     * Sets the MSG_TYPE value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @param MSG_TYPE
     */
    public void setMSG_TYPE(java.lang.String MSG_TYPE) {
        this.MSG_TYPE = MSG_TYPE;
    }


    /**
     * Gets the MSG_ID value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @return MSG_ID
     */
    public java.lang.String getMSG_ID() {
        return MSG_ID;
    }


    /**
     * Sets the MSG_ID value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @param MSG_ID
     */
    public void setMSG_ID(java.lang.String MSG_ID) {
        this.MSG_ID = MSG_ID;
    }


    /**
     * Gets the MSG_NO value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @return MSG_NO
     */
    public java.lang.String getMSG_NO() {
        return MSG_NO;
    }


    /**
     * Sets the MSG_NO value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @param MSG_NO
     */
    public void setMSG_NO(java.lang.String MSG_NO) {
        this.MSG_NO = MSG_NO;
    }


    /**
     * Gets the MSG_V1 value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @return MSG_V1
     */
    public java.lang.String getMSG_V1() {
        return MSG_V1;
    }


    /**
     * Sets the MSG_V1 value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @param MSG_V1
     */
    public void setMSG_V1(java.lang.String MSG_V1) {
        this.MSG_V1 = MSG_V1;
    }


    /**
     * Gets the MSG_V2 value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @return MSG_V2
     */
    public java.lang.String getMSG_V2() {
        return MSG_V2;
    }


    /**
     * Sets the MSG_V2 value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @param MSG_V2
     */
    public void setMSG_V2(java.lang.String MSG_V2) {
        this.MSG_V2 = MSG_V2;
    }


    /**
     * Gets the MSG_V3 value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @return MSG_V3
     */
    public java.lang.String getMSG_V3() {
        return MSG_V3;
    }


    /**
     * Sets the MSG_V3 value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @param MSG_V3
     */
    public void setMSG_V3(java.lang.String MSG_V3) {
        this.MSG_V3 = MSG_V3;
    }


    /**
     * Gets the MSG_V4 value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @return MSG_V4
     */
    public java.lang.String getMSG_V4() {
        return MSG_V4;
    }


    /**
     * Sets the MSG_V4 value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @param MSG_V4
     */
    public void setMSG_V4(java.lang.String MSG_V4) {
        this.MSG_V4 = MSG_V4;
    }


    /**
     * Gets the MSG_TXT value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @return MSG_TXT
     */
    public java.lang.String getMSG_TXT() {
        return MSG_TXT;
    }


    /**
     * Sets the MSG_TXT value for this ZZQ_CONFIG_RETURN_MESSAGE.
     * 
     * @param MSG_TXT
     */
    public void setMSG_TXT(java.lang.String MSG_TXT) {
        this.MSG_TXT = MSG_TXT;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ZZQ_CONFIG_RETURN_MESSAGE)) return false;
        ZZQ_CONFIG_RETURN_MESSAGE other = (ZZQ_CONFIG_RETURN_MESSAGE) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.MSG_LINE==null && other.getMSG_LINE()==null) || 
             (this.MSG_LINE!=null &&
              this.MSG_LINE.equals(other.getMSG_LINE()))) &&
            ((this.MSG_TYPE==null && other.getMSG_TYPE()==null) || 
             (this.MSG_TYPE!=null &&
              this.MSG_TYPE.equals(other.getMSG_TYPE()))) &&
            ((this.MSG_ID==null && other.getMSG_ID()==null) || 
             (this.MSG_ID!=null &&
              this.MSG_ID.equals(other.getMSG_ID()))) &&
            ((this.MSG_NO==null && other.getMSG_NO()==null) || 
             (this.MSG_NO!=null &&
              this.MSG_NO.equals(other.getMSG_NO()))) &&
            ((this.MSG_V1==null && other.getMSG_V1()==null) || 
             (this.MSG_V1!=null &&
              this.MSG_V1.equals(other.getMSG_V1()))) &&
            ((this.MSG_V2==null && other.getMSG_V2()==null) || 
             (this.MSG_V2!=null &&
              this.MSG_V2.equals(other.getMSG_V2()))) &&
            ((this.MSG_V3==null && other.getMSG_V3()==null) || 
             (this.MSG_V3!=null &&
              this.MSG_V3.equals(other.getMSG_V3()))) &&
            ((this.MSG_V4==null && other.getMSG_V4()==null) || 
             (this.MSG_V4!=null &&
              this.MSG_V4.equals(other.getMSG_V4()))) &&
            ((this.MSG_TXT==null && other.getMSG_TXT()==null) || 
             (this.MSG_TXT!=null &&
              this.MSG_TXT.equals(other.getMSG_TXT())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMSG_LINE() != null) {
            _hashCode += getMSG_LINE().hashCode();
        }
        if (getMSG_TYPE() != null) {
            _hashCode += getMSG_TYPE().hashCode();
        }
        if (getMSG_ID() != null) {
            _hashCode += getMSG_ID().hashCode();
        }
        if (getMSG_NO() != null) {
            _hashCode += getMSG_NO().hashCode();
        }
        if (getMSG_V1() != null) {
            _hashCode += getMSG_V1().hashCode();
        }
        if (getMSG_V2() != null) {
            _hashCode += getMSG_V2().hashCode();
        }
        if (getMSG_V3() != null) {
            _hashCode += getMSG_V3().hashCode();
        }
        if (getMSG_V4() != null) {
            _hashCode += getMSG_V4().hashCode();
        }
        if (getMSG_TXT() != null) {
            _hashCode += getMSG_TXT().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ZZQ_CONFIG_RETURN_MESSAGE.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:rfc:functions", "ZZQ_CONFIG_RETURN_MESSAGE"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSG_LINE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSG_LINE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSG_TYPE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSG_TYPE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSG_ID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSG_ID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSG_NO");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSG_NO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSG_V1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSG_V1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSG_V2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSG_V2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSG_V3");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSG_V3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSG_V4");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSG_V4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSG_TXT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MSG_TXT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
