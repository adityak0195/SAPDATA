/**
 * ZZQ_S_IBASE_DATA_FILE.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.sernrUpdateInProdOrder;

public class ZZQ_S_IBASE_DATA_FILE  implements java.io.Serializable {
    private java.lang.String HEAD;

    private java.lang.String KOMAT;

    private java.lang.String KOSER;

    private java.lang.String POSMAT;

    private java.lang.String POSER;

    private java.lang.String BATCH;

    private java.lang.String KWEEK;

    private java.lang.String KYEAR;

    private java.lang.String ZZHSDAT;

    private java.lang.String ZZWERKS;

    private java.lang.String ZZAEIND;

    private java.lang.String ZZMODIF_STAT;

    private java.lang.String ZZMOUNTED_BY;

    private java.lang.String ZZAPPROVED_BY;

    private java.lang.String ZZCERTIFIED_BY;

    private java.lang.String NOTICE;

    private java.lang.String AUFNR;

    private java.lang.String FL_ERROR;

    private java.lang.String MISSING_ITEMS;

    public ZZQ_S_IBASE_DATA_FILE() {
    }

    public ZZQ_S_IBASE_DATA_FILE(
           java.lang.String HEAD,
           java.lang.String KOMAT,
           java.lang.String KOSER,
           java.lang.String POSMAT,
           java.lang.String POSER,
           java.lang.String BATCH,
           java.lang.String KWEEK,
           java.lang.String KYEAR,
           java.lang.String ZZHSDAT,
           java.lang.String ZZWERKS,
           java.lang.String ZZAEIND,
           java.lang.String ZZMODIF_STAT,
           java.lang.String ZZMOUNTED_BY,
           java.lang.String ZZAPPROVED_BY,
           java.lang.String ZZCERTIFIED_BY,
           java.lang.String NOTICE,
           java.lang.String AUFNR,
           java.lang.String FL_ERROR,
           java.lang.String MISSING_ITEMS) {
           this.HEAD = HEAD;
           this.KOMAT = KOMAT;
           this.KOSER = KOSER;
           this.POSMAT = POSMAT;
           this.POSER = POSER;
           this.BATCH = BATCH;
           this.KWEEK = KWEEK;
           this.KYEAR = KYEAR;
           this.ZZHSDAT = ZZHSDAT;
           this.ZZWERKS = ZZWERKS;
           this.ZZAEIND = ZZAEIND;
           this.ZZMODIF_STAT = ZZMODIF_STAT;
           this.ZZMOUNTED_BY = ZZMOUNTED_BY;
           this.ZZAPPROVED_BY = ZZAPPROVED_BY;
           this.ZZCERTIFIED_BY = ZZCERTIFIED_BY;
           this.NOTICE = NOTICE;
           this.AUFNR = AUFNR;
           this.FL_ERROR = FL_ERROR;
           this.MISSING_ITEMS = MISSING_ITEMS;
    }


    /**
     * Gets the HEAD value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return HEAD
     */
    public java.lang.String getHEAD() {
        return HEAD;
    }


    /**
     * Sets the HEAD value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param HEAD
     */
    public void setHEAD(java.lang.String HEAD) {
        this.HEAD = HEAD;
    }


    /**
     * Gets the KOMAT value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return KOMAT
     */
    public java.lang.String getKOMAT() {
        return KOMAT;
    }


    /**
     * Sets the KOMAT value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param KOMAT
     */
    public void setKOMAT(java.lang.String KOMAT) {
        this.KOMAT = KOMAT;
    }


    /**
     * Gets the KOSER value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return KOSER
     */
    public java.lang.String getKOSER() {
        return KOSER;
    }


    /**
     * Sets the KOSER value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param KOSER
     */
    public void setKOSER(java.lang.String KOSER) {
        this.KOSER = KOSER;
    }


    /**
     * Gets the POSMAT value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return POSMAT
     */
    public java.lang.String getPOSMAT() {
        return POSMAT;
    }


    /**
     * Sets the POSMAT value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param POSMAT
     */
    public void setPOSMAT(java.lang.String POSMAT) {
        this.POSMAT = POSMAT;
    }


    /**
     * Gets the POSER value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return POSER
     */
    public java.lang.String getPOSER() {
        return POSER;
    }


    /**
     * Sets the POSER value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param POSER
     */
    public void setPOSER(java.lang.String POSER) {
        this.POSER = POSER;
    }


    /**
     * Gets the BATCH value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return BATCH
     */
    public java.lang.String getBATCH() {
        return BATCH;
    }


    /**
     * Sets the BATCH value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param BATCH
     */
    public void setBATCH(java.lang.String BATCH) {
        this.BATCH = BATCH;
    }


    /**
     * Gets the KWEEK value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return KWEEK
     */
    public java.lang.String getKWEEK() {
        return KWEEK;
    }


    /**
     * Sets the KWEEK value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param KWEEK
     */
    public void setKWEEK(java.lang.String KWEEK) {
        this.KWEEK = KWEEK;
    }


    /**
     * Gets the KYEAR value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return KYEAR
     */
    public java.lang.String getKYEAR() {
        return KYEAR;
    }


    /**
     * Sets the KYEAR value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param KYEAR
     */
    public void setKYEAR(java.lang.String KYEAR) {
        this.KYEAR = KYEAR;
    }


    /**
     * Gets the ZZHSDAT value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return ZZHSDAT
     */
    public java.lang.String getZZHSDAT() {
        return ZZHSDAT;
    }


    /**
     * Sets the ZZHSDAT value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param ZZHSDAT
     */
    public void setZZHSDAT(java.lang.String ZZHSDAT) {
        this.ZZHSDAT = ZZHSDAT;
    }


    /**
     * Gets the ZZWERKS value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return ZZWERKS
     */
    public java.lang.String getZZWERKS() {
        return ZZWERKS;
    }


    /**
     * Sets the ZZWERKS value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param ZZWERKS
     */
    public void setZZWERKS(java.lang.String ZZWERKS) {
        this.ZZWERKS = ZZWERKS;
    }


    /**
     * Gets the ZZAEIND value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return ZZAEIND
     */
    public java.lang.String getZZAEIND() {
        return ZZAEIND;
    }


    /**
     * Sets the ZZAEIND value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param ZZAEIND
     */
    public void setZZAEIND(java.lang.String ZZAEIND) {
        this.ZZAEIND = ZZAEIND;
    }


    /**
     * Gets the ZZMODIF_STAT value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return ZZMODIF_STAT
     */
    public java.lang.String getZZMODIF_STAT() {
        return ZZMODIF_STAT;
    }


    /**
     * Sets the ZZMODIF_STAT value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param ZZMODIF_STAT
     */
    public void setZZMODIF_STAT(java.lang.String ZZMODIF_STAT) {
        this.ZZMODIF_STAT = ZZMODIF_STAT;
    }


    /**
     * Gets the ZZMOUNTED_BY value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return ZZMOUNTED_BY
     */
    public java.lang.String getZZMOUNTED_BY() {
        return ZZMOUNTED_BY;
    }


    /**
     * Sets the ZZMOUNTED_BY value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param ZZMOUNTED_BY
     */
    public void setZZMOUNTED_BY(java.lang.String ZZMOUNTED_BY) {
        this.ZZMOUNTED_BY = ZZMOUNTED_BY;
    }


    /**
     * Gets the ZZAPPROVED_BY value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return ZZAPPROVED_BY
     */
    public java.lang.String getZZAPPROVED_BY() {
        return ZZAPPROVED_BY;
    }


    /**
     * Sets the ZZAPPROVED_BY value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param ZZAPPROVED_BY
     */
    public void setZZAPPROVED_BY(java.lang.String ZZAPPROVED_BY) {
        this.ZZAPPROVED_BY = ZZAPPROVED_BY;
    }


    /**
     * Gets the ZZCERTIFIED_BY value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return ZZCERTIFIED_BY
     */
    public java.lang.String getZZCERTIFIED_BY() {
        return ZZCERTIFIED_BY;
    }


    /**
     * Sets the ZZCERTIFIED_BY value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param ZZCERTIFIED_BY
     */
    public void setZZCERTIFIED_BY(java.lang.String ZZCERTIFIED_BY) {
        this.ZZCERTIFIED_BY = ZZCERTIFIED_BY;
    }


    /**
     * Gets the NOTICE value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return NOTICE
     */
    public java.lang.String getNOTICE() {
        return NOTICE;
    }


    /**
     * Sets the NOTICE value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param NOTICE
     */
    public void setNOTICE(java.lang.String NOTICE) {
        this.NOTICE = NOTICE;
    }


    /**
     * Gets the AUFNR value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return AUFNR
     */
    public java.lang.String getAUFNR() {
        return AUFNR;
    }


    /**
     * Sets the AUFNR value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param AUFNR
     */
    public void setAUFNR(java.lang.String AUFNR) {
        this.AUFNR = AUFNR;
    }


    /**
     * Gets the FL_ERROR value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return FL_ERROR
     */
    public java.lang.String getFL_ERROR() {
        return FL_ERROR;
    }


    /**
     * Sets the FL_ERROR value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param FL_ERROR
     */
    public void setFL_ERROR(java.lang.String FL_ERROR) {
        this.FL_ERROR = FL_ERROR;
    }


    /**
     * Gets the MISSING_ITEMS value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @return MISSING_ITEMS
     */
    public java.lang.String getMISSING_ITEMS() {
        return MISSING_ITEMS;
    }


    /**
     * Sets the MISSING_ITEMS value for this ZZQ_S_IBASE_DATA_FILE.
     * 
     * @param MISSING_ITEMS
     */
    public void setMISSING_ITEMS(java.lang.String MISSING_ITEMS) {
        this.MISSING_ITEMS = MISSING_ITEMS;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ZZQ_S_IBASE_DATA_FILE)) return false;
        ZZQ_S_IBASE_DATA_FILE other = (ZZQ_S_IBASE_DATA_FILE) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.HEAD==null && other.getHEAD()==null) || 
             (this.HEAD!=null &&
              this.HEAD.equals(other.getHEAD()))) &&
            ((this.KOMAT==null && other.getKOMAT()==null) || 
             (this.KOMAT!=null &&
              this.KOMAT.equals(other.getKOMAT()))) &&
            ((this.KOSER==null && other.getKOSER()==null) || 
             (this.KOSER!=null &&
              this.KOSER.equals(other.getKOSER()))) &&
            ((this.POSMAT==null && other.getPOSMAT()==null) || 
             (this.POSMAT!=null &&
              this.POSMAT.equals(other.getPOSMAT()))) &&
            ((this.POSER==null && other.getPOSER()==null) || 
             (this.POSER!=null &&
              this.POSER.equals(other.getPOSER()))) &&
            ((this.BATCH==null && other.getBATCH()==null) || 
             (this.BATCH!=null &&
              this.BATCH.equals(other.getBATCH()))) &&
            ((this.KWEEK==null && other.getKWEEK()==null) || 
             (this.KWEEK!=null &&
              this.KWEEK.equals(other.getKWEEK()))) &&
            ((this.KYEAR==null && other.getKYEAR()==null) || 
             (this.KYEAR!=null &&
              this.KYEAR.equals(other.getKYEAR()))) &&
            ((this.ZZHSDAT==null && other.getZZHSDAT()==null) || 
             (this.ZZHSDAT!=null &&
              this.ZZHSDAT.equals(other.getZZHSDAT()))) &&
            ((this.ZZWERKS==null && other.getZZWERKS()==null) || 
             (this.ZZWERKS!=null &&
              this.ZZWERKS.equals(other.getZZWERKS()))) &&
            ((this.ZZAEIND==null && other.getZZAEIND()==null) || 
             (this.ZZAEIND!=null &&
              this.ZZAEIND.equals(other.getZZAEIND()))) &&
            ((this.ZZMODIF_STAT==null && other.getZZMODIF_STAT()==null) || 
             (this.ZZMODIF_STAT!=null &&
              this.ZZMODIF_STAT.equals(other.getZZMODIF_STAT()))) &&
            ((this.ZZMOUNTED_BY==null && other.getZZMOUNTED_BY()==null) || 
             (this.ZZMOUNTED_BY!=null &&
              this.ZZMOUNTED_BY.equals(other.getZZMOUNTED_BY()))) &&
            ((this.ZZAPPROVED_BY==null && other.getZZAPPROVED_BY()==null) || 
             (this.ZZAPPROVED_BY!=null &&
              this.ZZAPPROVED_BY.equals(other.getZZAPPROVED_BY()))) &&
            ((this.ZZCERTIFIED_BY==null && other.getZZCERTIFIED_BY()==null) || 
             (this.ZZCERTIFIED_BY!=null &&
              this.ZZCERTIFIED_BY.equals(other.getZZCERTIFIED_BY()))) &&
            ((this.NOTICE==null && other.getNOTICE()==null) || 
             (this.NOTICE!=null &&
              this.NOTICE.equals(other.getNOTICE()))) &&
            ((this.AUFNR==null && other.getAUFNR()==null) || 
             (this.AUFNR!=null &&
              this.AUFNR.equals(other.getAUFNR()))) &&
            ((this.FL_ERROR==null && other.getFL_ERROR()==null) || 
             (this.FL_ERROR!=null &&
              this.FL_ERROR.equals(other.getFL_ERROR()))) &&
            ((this.MISSING_ITEMS==null && other.getMISSING_ITEMS()==null) || 
             (this.MISSING_ITEMS!=null &&
              this.MISSING_ITEMS.equals(other.getMISSING_ITEMS())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getHEAD() != null) {
            _hashCode += getHEAD().hashCode();
        }
        if (getKOMAT() != null) {
            _hashCode += getKOMAT().hashCode();
        }
        if (getKOSER() != null) {
            _hashCode += getKOSER().hashCode();
        }
        if (getPOSMAT() != null) {
            _hashCode += getPOSMAT().hashCode();
        }
        if (getPOSER() != null) {
            _hashCode += getPOSER().hashCode();
        }
        if (getBATCH() != null) {
            _hashCode += getBATCH().hashCode();
        }
        if (getKWEEK() != null) {
            _hashCode += getKWEEK().hashCode();
        }
        if (getKYEAR() != null) {
            _hashCode += getKYEAR().hashCode();
        }
        if (getZZHSDAT() != null) {
            _hashCode += getZZHSDAT().hashCode();
        }
        if (getZZWERKS() != null) {
            _hashCode += getZZWERKS().hashCode();
        }
        if (getZZAEIND() != null) {
            _hashCode += getZZAEIND().hashCode();
        }
        if (getZZMODIF_STAT() != null) {
            _hashCode += getZZMODIF_STAT().hashCode();
        }
        if (getZZMOUNTED_BY() != null) {
            _hashCode += getZZMOUNTED_BY().hashCode();
        }
        if (getZZAPPROVED_BY() != null) {
            _hashCode += getZZAPPROVED_BY().hashCode();
        }
        if (getZZCERTIFIED_BY() != null) {
            _hashCode += getZZCERTIFIED_BY().hashCode();
        }
        if (getNOTICE() != null) {
            _hashCode += getNOTICE().hashCode();
        }
        if (getAUFNR() != null) {
            _hashCode += getAUFNR().hashCode();
        }
        if (getFL_ERROR() != null) {
            _hashCode += getFL_ERROR().hashCode();
        }
        if (getMISSING_ITEMS() != null) {
            _hashCode += getMISSING_ITEMS().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ZZQ_S_IBASE_DATA_FILE.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:rfc:functions", "ZZQ_S_IBASE_DATA_FILE"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HEAD");
        elemField.setXmlName(new javax.xml.namespace.QName("", "HEAD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOMAT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "KOMAT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOSER");
        elemField.setXmlName(new javax.xml.namespace.QName("", "KOSER"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("POSMAT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "POSMAT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("POSER");
        elemField.setXmlName(new javax.xml.namespace.QName("", "POSER"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BATCH");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BATCH"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KWEEK");
        elemField.setXmlName(new javax.xml.namespace.QName("", "KWEEK"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KYEAR");
        elemField.setXmlName(new javax.xml.namespace.QName("", "KYEAR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ZZHSDAT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZZHSDAT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ZZWERKS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZZWERKS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ZZAEIND");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZZAEIND"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ZZMODIF_STAT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZZMODIF_STAT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ZZMOUNTED_BY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZZMOUNTED_BY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ZZAPPROVED_BY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZZAPPROVED_BY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ZZCERTIFIED_BY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZZCERTIFIED_BY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NOTICE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "NOTICE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AUFNR");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AUFNR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FL_ERROR");
        elemField.setXmlName(new javax.xml.namespace.QName("", "FL_ERROR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MISSING_ITEMS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MISSING_ITEMS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
