/**
 * Y_P_GET_PLANNED_WORKING_TIMEResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.plannedWorkingTime;

public class Y_P_GET_PLANNED_WORKING_TIMEResponse  implements java.io.Serializable {
    private com.knorr_bremse.sap_com.plannedWorkingTime.ZAPO_RES_SHIFTS[] ET_DATA;

    public Y_P_GET_PLANNED_WORKING_TIMEResponse() {
    }

    public Y_P_GET_PLANNED_WORKING_TIMEResponse(
           com.knorr_bremse.sap_com.plannedWorkingTime.ZAPO_RES_SHIFTS[] ET_DATA) {
           this.ET_DATA = ET_DATA;
    }


    /**
     * Gets the ET_DATA value for this Y_P_GET_PLANNED_WORKING_TIMEResponse.
     * 
     * @return ET_DATA
     */
    public com.knorr_bremse.sap_com.plannedWorkingTime.ZAPO_RES_SHIFTS[] getET_DATA() {
        return ET_DATA;
    }


    /**
     * Sets the ET_DATA value for this Y_P_GET_PLANNED_WORKING_TIMEResponse.
     * 
     * @param ET_DATA
     */
    public void setET_DATA(com.knorr_bremse.sap_com.plannedWorkingTime.ZAPO_RES_SHIFTS[] ET_DATA) {
        this.ET_DATA = ET_DATA;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Y_P_GET_PLANNED_WORKING_TIMEResponse)) return false;
        Y_P_GET_PLANNED_WORKING_TIMEResponse other = (Y_P_GET_PLANNED_WORKING_TIMEResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ET_DATA==null && other.getET_DATA()==null) || 
             (this.ET_DATA!=null &&
              java.util.Arrays.equals(this.ET_DATA, other.getET_DATA())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getET_DATA() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getET_DATA());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getET_DATA(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Y_P_GET_PLANNED_WORKING_TIMEResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:rfc:functions", ">Y_P_GET_PLANNED_WORKING_TIME.Response"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ET_DATA");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ET_DATA"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:rfc:functions", "ZAPO_RES_SHIFTS"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "item"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
