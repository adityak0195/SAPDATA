package com.knorr_bremse.sap_com.plannedWorkingTime;

public class SI_OUT_Worx_PlannedWorkingTime_SYNCProxy implements com.knorr_bremse.sap_com.plannedWorkingTime.SI_OUT_Worx_PlannedWorkingTime_SYNC {
  private String _endpoint = null;
  private com.knorr_bremse.sap_com.plannedWorkingTime.SI_OUT_Worx_PlannedWorkingTime_SYNC sI_OUT_Worx_PlannedWorkingTime_SYNC = null;
  
  public SI_OUT_Worx_PlannedWorkingTime_SYNCProxy() {
    _initSI_OUT_Worx_PlannedWorkingTime_SYNCProxy();
  }
  
  public SI_OUT_Worx_PlannedWorkingTime_SYNCProxy(String endpoint) {
    _endpoint = endpoint;
    _initSI_OUT_Worx_PlannedWorkingTime_SYNCProxy();
  }
  
  private void _initSI_OUT_Worx_PlannedWorkingTime_SYNCProxy() {
    try {
      sI_OUT_Worx_PlannedWorkingTime_SYNC = (new com.knorr_bremse.sap_com.plannedWorkingTime.SI_OUT_Worx_PlannedWorkingTime_SYNCServiceLocator()).getHTTPS_Port();
      if (sI_OUT_Worx_PlannedWorkingTime_SYNC != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)sI_OUT_Worx_PlannedWorkingTime_SYNC)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)sI_OUT_Worx_PlannedWorkingTime_SYNC)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (sI_OUT_Worx_PlannedWorkingTime_SYNC != null)
      ((javax.xml.rpc.Stub)sI_OUT_Worx_PlannedWorkingTime_SYNC)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.knorr_bremse.sap_com.plannedWorkingTime.SI_OUT_Worx_PlannedWorkingTime_SYNC getSI_OUT_Worx_PlannedWorkingTime_SYNC() {
    if (sI_OUT_Worx_PlannedWorkingTime_SYNC == null)
      _initSI_OUT_Worx_PlannedWorkingTime_SYNCProxy();
    return sI_OUT_Worx_PlannedWorkingTime_SYNC;
  }
  
  public com.knorr_bremse.sap_com.plannedWorkingTime.Y_P_GET_PLANNED_WORKING_TIMEResponse SI_OUT_Worx_PlannedWorkingTime_SYNC(com.knorr_bremse.sap_com.plannedWorkingTime.DT_Worx_PlannedWorkingTime MT_Worx_PlannedWorkingTime) throws java.rmi.RemoteException{
    if (sI_OUT_Worx_PlannedWorkingTime_SYNC == null)
      _initSI_OUT_Worx_PlannedWorkingTime_SYNCProxy();
    return sI_OUT_Worx_PlannedWorkingTime_SYNC.SI_OUT_Worx_PlannedWorkingTime_SYNC(MT_Worx_PlannedWorkingTime);
  }
  
  
}