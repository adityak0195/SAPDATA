/**
 * YYP_TS_WORX_CONFIRMATION.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.plannedWorkingTime;

import java.util.UUID;

import com.ptc.kb.sap.TimeUtility;
import com.thingworx.metadata.DataShapeDefinition;
import com.thingworx.metadata.FieldDefinition;
import com.thingworx.types.BaseTypes;
import com.thingworx.types.collections.ValueCollection;
import com.thingworx.types.primitives.DatetimePrimitive;
import com.thingworx.types.primitives.NumberPrimitive;
import com.thingworx.types.primitives.StringPrimitive;

/**
 * Confirmation Data for thing Worx (demo)
 */
public class YYP_TS_WORX_CONFIRMATION  implements java.io.Serializable {
    /* Order Number */
    private java.lang.String ORDERID;

    /* Total order quantity */
    private java.math.BigDecimal LOTSIZE;

    /* Base Unit of Measure */
    private java.lang.String LOTSIZE_UNIT;

    /* Completion confirmation number for the operation */
    private java.lang.String CONFIRMATION_NO;

    /* Confirmation counter */
    private java.lang.String CONFIRMATION_COUNTER;

    /* Created On */
    private com.knorr_bremse.sap_com.plannedWorkingTime.Date CREATED_ON;

    /* Entry time */
    private com.knorr_bremse.sap_com.plannedWorkingTime.Time CREATED_AT;

    /* Yield to Be Confirmed */
    private java.math.BigDecimal YIELD;

    /* Scrap to Be Confirmed */
    private java.math.BigDecimal SCRAP;

    /* Current rework quantity to be confirmed */
    private java.math.BigDecimal REWORK;

    /* Confirmation unit of measure */
    private java.lang.String CONF_QUAN_UNIT;

    /* Sequence */
    private java.lang.String SEQUENCE;

    /* Operation/Activity Number */
    private java.lang.String OPERATION;

    /* Routing number of operations in the order */
    private java.lang.String ROUTING_NO;

    /* General counter for order */
    private java.lang.String ROUTING_COUNTER;

    /* Standard Value */
    private java.math.BigDecimal TIME_PER_PART;

    /* Unit of measure for the standard value */
    private java.lang.String TIME_UNIT;

    public YYP_TS_WORX_CONFIRMATION() {
    }

    public YYP_TS_WORX_CONFIRMATION(
           java.lang.String ORDERID,
           java.math.BigDecimal LOTSIZE,
           java.lang.String LOTSIZE_UNIT,
           java.lang.String CONFIRMATION_NO,
           java.lang.String CONFIRMATION_COUNTER,
           com.knorr_bremse.sap_com.plannedWorkingTime.Date CREATED_ON,
           com.knorr_bremse.sap_com.plannedWorkingTime.Time CREATED_AT,
           java.math.BigDecimal YIELD,
           java.math.BigDecimal SCRAP,
           java.math.BigDecimal REWORK,
           java.lang.String CONF_QUAN_UNIT,
           java.lang.String SEQUENCE,
           java.lang.String OPERATION,
           java.lang.String ROUTING_NO,
           java.lang.String ROUTING_COUNTER,
           java.math.BigDecimal TIME_PER_PART,
           java.lang.String TIME_UNIT) {
           this.ORDERID = ORDERID;
           this.LOTSIZE = LOTSIZE;
           this.LOTSIZE_UNIT = LOTSIZE_UNIT;
           this.CONFIRMATION_NO = CONFIRMATION_NO;
           this.CONFIRMATION_COUNTER = CONFIRMATION_COUNTER;
           this.CREATED_ON = CREATED_ON;
           this.CREATED_AT = CREATED_AT;
           this.YIELD = YIELD;
           this.SCRAP = SCRAP;
           this.REWORK = REWORK;
           this.CONF_QUAN_UNIT = CONF_QUAN_UNIT;
           this.SEQUENCE = SEQUENCE;
           this.OPERATION = OPERATION;
           this.ROUTING_NO = ROUTING_NO;
           this.ROUTING_COUNTER = ROUTING_COUNTER;
           this.TIME_PER_PART = TIME_PER_PART;
           this.TIME_UNIT = TIME_UNIT;
    }


    /**
     * Gets the ORDERID value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @return ORDERID   * Order Number
     */
    public java.lang.String getORDERID() {
        return ORDERID;
    }


    /**
     * Sets the ORDERID value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @param ORDERID   * Order Number
     */
    public void setORDERID(java.lang.String ORDERID) {
        this.ORDERID = ORDERID;
    }


    /**
     * Gets the LOTSIZE value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @return LOTSIZE   * Total order quantity
     */
    public java.math.BigDecimal getLOTSIZE() {
        return LOTSIZE;
    }


    /**
     * Sets the LOTSIZE value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @param LOTSIZE   * Total order quantity
     */
    public void setLOTSIZE(java.math.BigDecimal LOTSIZE) {
        this.LOTSIZE = LOTSIZE;
    }


    /**
     * Gets the LOTSIZE_UNIT value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @return LOTSIZE_UNIT   * Base Unit of Measure
     */
    public java.lang.String getLOTSIZE_UNIT() {
        return LOTSIZE_UNIT;
    }


    /**
     * Sets the LOTSIZE_UNIT value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @param LOTSIZE_UNIT   * Base Unit of Measure
     */
    public void setLOTSIZE_UNIT(java.lang.String LOTSIZE_UNIT) {
        this.LOTSIZE_UNIT = LOTSIZE_UNIT;
    }


    /**
     * Gets the CONFIRMATION_NO value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @return CONFIRMATION_NO   * Completion confirmation number for the operation
     */
    public java.lang.String getCONFIRMATION_NO() {
        return CONFIRMATION_NO;
    }


    /**
     * Sets the CONFIRMATION_NO value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @param CONFIRMATION_NO   * Completion confirmation number for the operation
     */
    public void setCONFIRMATION_NO(java.lang.String CONFIRMATION_NO) {
        this.CONFIRMATION_NO = CONFIRMATION_NO;
    }


    /**
     * Gets the CONFIRMATION_COUNTER value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @return CONFIRMATION_COUNTER   * Confirmation counter
     */
    public java.lang.String getCONFIRMATION_COUNTER() {
        return CONFIRMATION_COUNTER;
    }


    /**
     * Sets the CONFIRMATION_COUNTER value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @param CONFIRMATION_COUNTER   * Confirmation counter
     */
    public void setCONFIRMATION_COUNTER(java.lang.String CONFIRMATION_COUNTER) {
        this.CONFIRMATION_COUNTER = CONFIRMATION_COUNTER;
    }


    /**
     * Gets the CREATED_ON value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @return CREATED_ON   * Created On
     */
    public com.knorr_bremse.sap_com.plannedWorkingTime.Date getCREATED_ON() {
        return CREATED_ON;
    }


    /**
     * Sets the CREATED_ON value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @param CREATED_ON   * Created On
     */
    public void setCREATED_ON(com.knorr_bremse.sap_com.plannedWorkingTime.Date CREATED_ON) {
        this.CREATED_ON = CREATED_ON;
    }


    /**
     * Gets the CREATED_AT value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @return CREATED_AT   * Entry time
     */
    public com.knorr_bremse.sap_com.plannedWorkingTime.Time getCREATED_AT() {
        return CREATED_AT;
    }


    /**
     * Sets the CREATED_AT value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @param CREATED_AT   * Entry time
     */
    public void setCREATED_AT(com.knorr_bremse.sap_com.plannedWorkingTime.Time CREATED_AT) {
        this.CREATED_AT = CREATED_AT;
    }


    /**
     * Gets the YIELD value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @return YIELD   * Yield to Be Confirmed
     */
    public java.math.BigDecimal getYIELD() {
        return YIELD;
    }


    /**
     * Sets the YIELD value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @param YIELD   * Yield to Be Confirmed
     */
    public void setYIELD(java.math.BigDecimal YIELD) {
        this.YIELD = YIELD;
    }


    /**
     * Gets the SCRAP value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @return SCRAP   * Scrap to Be Confirmed
     */
    public java.math.BigDecimal getSCRAP() {
        return SCRAP;
    }


    /**
     * Sets the SCRAP value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @param SCRAP   * Scrap to Be Confirmed
     */
    public void setSCRAP(java.math.BigDecimal SCRAP) {
        this.SCRAP = SCRAP;
    }


    /**
     * Gets the REWORK value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @return REWORK   * Current rework quantity to be confirmed
     */
    public java.math.BigDecimal getREWORK() {
        return REWORK;
    }


    /**
     * Sets the REWORK value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @param REWORK   * Current rework quantity to be confirmed
     */
    public void setREWORK(java.math.BigDecimal REWORK) {
        this.REWORK = REWORK;
    }


    /**
     * Gets the CONF_QUAN_UNIT value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @return CONF_QUAN_UNIT   * Confirmation unit of measure
     */
    public java.lang.String getCONF_QUAN_UNIT() {
        return CONF_QUAN_UNIT;
    }


    /**
     * Sets the CONF_QUAN_UNIT value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @param CONF_QUAN_UNIT   * Confirmation unit of measure
     */
    public void setCONF_QUAN_UNIT(java.lang.String CONF_QUAN_UNIT) {
        this.CONF_QUAN_UNIT = CONF_QUAN_UNIT;
    }


    /**
     * Gets the SEQUENCE value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @return SEQUENCE   * Sequence
     */
    public java.lang.String getSEQUENCE() {
        return SEQUENCE;
    }


    /**
     * Sets the SEQUENCE value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @param SEQUENCE   * Sequence
     */
    public void setSEQUENCE(java.lang.String SEQUENCE) {
        this.SEQUENCE = SEQUENCE;
    }


    /**
     * Gets the OPERATION value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @return OPERATION   * Operation/Activity Number
     */
    public java.lang.String getOPERATION() {
        return OPERATION;
    }


    /**
     * Sets the OPERATION value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @param OPERATION   * Operation/Activity Number
     */
    public void setOPERATION(java.lang.String OPERATION) {
        this.OPERATION = OPERATION;
    }


    /**
     * Gets the ROUTING_NO value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @return ROUTING_NO   * Routing number of operations in the order
     */
    public java.lang.String getROUTING_NO() {
        return ROUTING_NO;
    }


    /**
     * Sets the ROUTING_NO value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @param ROUTING_NO   * Routing number of operations in the order
     */
    public void setROUTING_NO(java.lang.String ROUTING_NO) {
        this.ROUTING_NO = ROUTING_NO;
    }


    /**
     * Gets the ROUTING_COUNTER value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @return ROUTING_COUNTER   * General counter for order
     */
    public java.lang.String getROUTING_COUNTER() {
        return ROUTING_COUNTER;
    }


    /**
     * Sets the ROUTING_COUNTER value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @param ROUTING_COUNTER   * General counter for order
     */
    public void setROUTING_COUNTER(java.lang.String ROUTING_COUNTER) {
        this.ROUTING_COUNTER = ROUTING_COUNTER;
    }


    /**
     * Gets the TIME_PER_PART value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @return TIME_PER_PART   * Standard Value
     */
    public java.math.BigDecimal getTIME_PER_PART() {
        return TIME_PER_PART;
    }


    /**
     * Sets the TIME_PER_PART value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @param TIME_PER_PART   * Standard Value
     */
    public void setTIME_PER_PART(java.math.BigDecimal TIME_PER_PART) {
        this.TIME_PER_PART = TIME_PER_PART;
    }


    /**
     * Gets the TIME_UNIT value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @return TIME_UNIT   * Unit of measure for the standard value
     */
    public java.lang.String getTIME_UNIT() {
        return TIME_UNIT;
    }


    /**
     * Sets the TIME_UNIT value for this YYP_TS_WORX_CONFIRMATION.
     * 
     * @param TIME_UNIT   * Unit of measure for the standard value
     */
    public void setTIME_UNIT(java.lang.String TIME_UNIT) {
        this.TIME_UNIT = TIME_UNIT;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof YYP_TS_WORX_CONFIRMATION)) return false;
        YYP_TS_WORX_CONFIRMATION other = (YYP_TS_WORX_CONFIRMATION) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ORDERID==null && other.getORDERID()==null) || 
             (this.ORDERID!=null &&
              this.ORDERID.equals(other.getORDERID()))) &&
            ((this.LOTSIZE==null && other.getLOTSIZE()==null) || 
             (this.LOTSIZE!=null &&
              this.LOTSIZE.equals(other.getLOTSIZE()))) &&
            ((this.LOTSIZE_UNIT==null && other.getLOTSIZE_UNIT()==null) || 
             (this.LOTSIZE_UNIT!=null &&
              this.LOTSIZE_UNIT.equals(other.getLOTSIZE_UNIT()))) &&
            ((this.CONFIRMATION_NO==null && other.getCONFIRMATION_NO()==null) || 
             (this.CONFIRMATION_NO!=null &&
              this.CONFIRMATION_NO.equals(other.getCONFIRMATION_NO()))) &&
            ((this.CONFIRMATION_COUNTER==null && other.getCONFIRMATION_COUNTER()==null) || 
             (this.CONFIRMATION_COUNTER!=null &&
              this.CONFIRMATION_COUNTER.equals(other.getCONFIRMATION_COUNTER()))) &&
            ((this.CREATED_ON==null && other.getCREATED_ON()==null) || 
             (this.CREATED_ON!=null &&
              this.CREATED_ON.equals(other.getCREATED_ON()))) &&
            ((this.CREATED_AT==null && other.getCREATED_AT()==null) || 
             (this.CREATED_AT!=null &&
              this.CREATED_AT.equals(other.getCREATED_AT()))) &&
            ((this.YIELD==null && other.getYIELD()==null) || 
             (this.YIELD!=null &&
              this.YIELD.equals(other.getYIELD()))) &&
            ((this.SCRAP==null && other.getSCRAP()==null) || 
             (this.SCRAP!=null &&
              this.SCRAP.equals(other.getSCRAP()))) &&
            ((this.REWORK==null && other.getREWORK()==null) || 
             (this.REWORK!=null &&
              this.REWORK.equals(other.getREWORK()))) &&
            ((this.CONF_QUAN_UNIT==null && other.getCONF_QUAN_UNIT()==null) || 
             (this.CONF_QUAN_UNIT!=null &&
              this.CONF_QUAN_UNIT.equals(other.getCONF_QUAN_UNIT()))) &&
            ((this.SEQUENCE==null && other.getSEQUENCE()==null) || 
             (this.SEQUENCE!=null &&
              this.SEQUENCE.equals(other.getSEQUENCE()))) &&
            ((this.OPERATION==null && other.getOPERATION()==null) || 
             (this.OPERATION!=null &&
              this.OPERATION.equals(other.getOPERATION()))) &&
            ((this.ROUTING_NO==null && other.getROUTING_NO()==null) || 
             (this.ROUTING_NO!=null &&
              this.ROUTING_NO.equals(other.getROUTING_NO()))) &&
            ((this.ROUTING_COUNTER==null && other.getROUTING_COUNTER()==null) || 
             (this.ROUTING_COUNTER!=null &&
              this.ROUTING_COUNTER.equals(other.getROUTING_COUNTER()))) &&
            ((this.TIME_PER_PART==null && other.getTIME_PER_PART()==null) || 
             (this.TIME_PER_PART!=null &&
              this.TIME_PER_PART.equals(other.getTIME_PER_PART()))) &&
            ((this.TIME_UNIT==null && other.getTIME_UNIT()==null) || 
             (this.TIME_UNIT!=null &&
              this.TIME_UNIT.equals(other.getTIME_UNIT())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getORDERID() != null) {
            _hashCode += getORDERID().hashCode();
        }
        if (getLOTSIZE() != null) {
            _hashCode += getLOTSIZE().hashCode();
        }
        if (getLOTSIZE_UNIT() != null) {
            _hashCode += getLOTSIZE_UNIT().hashCode();
        }
        if (getCONFIRMATION_NO() != null) {
            _hashCode += getCONFIRMATION_NO().hashCode();
        }
        if (getCONFIRMATION_COUNTER() != null) {
            _hashCode += getCONFIRMATION_COUNTER().hashCode();
        }
        if (getCREATED_ON() != null) {
            _hashCode += getCREATED_ON().hashCode();
        }
        if (getCREATED_AT() != null) {
            _hashCode += getCREATED_AT().hashCode();
        }
        if (getYIELD() != null) {
            _hashCode += getYIELD().hashCode();
        }
        if (getSCRAP() != null) {
            _hashCode += getSCRAP().hashCode();
        }
        if (getREWORK() != null) {
            _hashCode += getREWORK().hashCode();
        }
        if (getCONF_QUAN_UNIT() != null) {
            _hashCode += getCONF_QUAN_UNIT().hashCode();
        }
        if (getSEQUENCE() != null) {
            _hashCode += getSEQUENCE().hashCode();
        }
        if (getOPERATION() != null) {
            _hashCode += getOPERATION().hashCode();
        }
        if (getROUTING_NO() != null) {
            _hashCode += getROUTING_NO().hashCode();
        }
        if (getROUTING_COUNTER() != null) {
            _hashCode += getROUTING_COUNTER().hashCode();
        }
        if (getTIME_PER_PART() != null) {
            _hashCode += getTIME_PER_PART().hashCode();
        }
        if (getTIME_UNIT() != null) {
            _hashCode += getTIME_UNIT().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(YYP_TS_WORX_CONFIRMATION.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:rfc:functions", "YYP_TS_WORX_CONFIRMATION"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ORDERID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ORDERID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LOTSIZE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "LOTSIZE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LOTSIZE_UNIT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "LOTSIZE_UNIT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONFIRMATION_NO");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CONFIRMATION_NO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONFIRMATION_COUNTER");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CONFIRMATION_COUNTER"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CREATED_ON");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CREATED_ON"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:rfc:functions", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CREATED_AT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CREATED_AT"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:rfc:functions", "time"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YIELD");
        elemField.setXmlName(new javax.xml.namespace.QName("", "YIELD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SCRAP");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SCRAP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REWORK");
        elemField.setXmlName(new javax.xml.namespace.QName("", "REWORK"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONF_QUAN_UNIT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CONF_QUAN_UNIT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SEQUENCE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SEQUENCE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OPERATION");
        elemField.setXmlName(new javax.xml.namespace.QName("", "OPERATION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ROUTING_NO");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ROUTING_NO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ROUTING_COUNTER");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ROUTING_COUNTER"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TIME_PER_PART");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TIME_PER_PART"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TIME_UNIT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TIME_UNIT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

	@Override
	public String toString() {
		return "YYP_TS_WORX_CONFIRMATION [ORDERID=" + ORDERID + ", LOTSIZE=" + LOTSIZE + ", LOTSIZE_UNIT="
				+ LOTSIZE_UNIT + ", CONFIRMATION_NO=" + CONFIRMATION_NO + ", CONFIRMATION_COUNTER="
				+ CONFIRMATION_COUNTER + ", CREATED_ON=" + CREATED_ON + ", CREATED_AT=" + CREATED_AT + ", YIELD="
				+ YIELD + ", SCRAP=" + SCRAP + ", REWORK=" + REWORK + ", CONF_QUAN_UNIT=" + CONF_QUAN_UNIT
				+ ", SEQUENCE=" + SEQUENCE + ", OPERATION=" + OPERATION + ", ROUTING_NO=" + ROUTING_NO
				+ ", ROUTING_COUNTER=" + ROUTING_COUNTER + ", TIME_PER_PART=" + TIME_PER_PART + ", TIME_UNIT="
				+ TIME_UNIT + "]";
	}

	public ValueCollection toValueCollection(String workCenter, String plant) {
		ValueCollection vc = new ValueCollection();
		//vc.put("pk", new StringPrimitive(UUID.randomUUID().toString()));
		vc.put("pk", new StringPrimitive(CONFIRMATION_NO + "_" + CONFIRMATION_COUNTER));
		vc.put("workCenter", new StringPrimitive(workCenter));		// For traceability
		vc.put("plant", new StringPrimitive(plant));				// For traceability
		vc.put("orderId", new StringPrimitive(ORDERID));
		vc.put("lotSize", new NumberPrimitive(LOTSIZE.doubleValue()));
		vc.put("lotSizeUnit", new StringPrimitive(LOTSIZE_UNIT));
		vc.put("confirmationNo", new StringPrimitive(CONFIRMATION_NO));
		vc.put("confirmationCounter", new StringPrimitive(CONFIRMATION_COUNTER));
		vc.put("createdOn", new StringPrimitive(CREATED_ON.getGenericDateValue()));
		vc.put("createdAt", new StringPrimitive(CREATED_AT.getGenericTimeValue()));
		vc.put("createdTimestamp", new DatetimePrimitive(
				TimeUtility.makeTimestamp(CREATED_ON.getGenericDateValue(), CREATED_AT.getGenericTimeValue()))
			);
		vc.put("yield", new NumberPrimitive(YIELD.doubleValue()));
		vc.put("scrap", new NumberPrimitive(SCRAP.doubleValue()));
		vc.put("rework", new NumberPrimitive(REWORK.doubleValue()));
		vc.put("confQuanUnit", new StringPrimitive(CONF_QUAN_UNIT));
		vc.put("sequence", new StringPrimitive(SEQUENCE));
		vc.put("operation", new StringPrimitive(OPERATION));
		vc.put("routingNo", new StringPrimitive(ROUTING_NO));
		vc.put("routingCounter", new StringPrimitive(ROUTING_COUNTER));
		vc.put("timePerPart", new NumberPrimitive(TIME_PER_PART.doubleValue()));
		vc.put("timeUnit", new StringPrimitive(TIME_UNIT));
		return vc;
	}
//	
//	public static final DataShapeDefinition DATA_SHAPE = new DataShapeDefinition();
//	static {
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("workCenter", BaseTypes.STRING));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("plant", "STRING"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("orderId", "STRING"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("lotSize", "NUMBER"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("lotSizeUnit", "STRING"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("confirmationNo", "STRING"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("confirmationCounter", "STRING"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("createdOn", "STRING"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("createdAt", "STRING"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("createdTimestamp", "DATETIME"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("yield", "NUMBER"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("scrap", "NUMBER"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("rework", "NUMBER"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("confQuanUnit", "STRING"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("sequence", "STRING"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("operation", "STRING"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("routingNo", "STRING"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("routingCounter", "STRING"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("timePerPart", "NUMBER"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("timeUnit", "STRING"));
//	}
    
}
