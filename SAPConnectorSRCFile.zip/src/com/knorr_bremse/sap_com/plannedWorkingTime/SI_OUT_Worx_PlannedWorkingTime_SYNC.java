/**
 * SI_OUT_Worx_PlannedWorkingTime_SYNC.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.plannedWorkingTime;

public interface SI_OUT_Worx_PlannedWorkingTime_SYNC extends java.rmi.Remote {
    public com.knorr_bremse.sap_com.plannedWorkingTime.Y_P_GET_PLANNED_WORKING_TIMEResponse SI_OUT_Worx_PlannedWorkingTime_SYNC(com.knorr_bremse.sap_com.plannedWorkingTime.DT_Worx_PlannedWorkingTime MT_Worx_PlannedWorkingTime) throws java.rmi.RemoteException;
}
