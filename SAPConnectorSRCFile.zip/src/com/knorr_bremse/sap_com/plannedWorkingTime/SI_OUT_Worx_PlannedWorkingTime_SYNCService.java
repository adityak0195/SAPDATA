/**
 * SI_OUT_Worx_PlannedWorkingTime_SYNCService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.plannedWorkingTime;

public interface SI_OUT_Worx_PlannedWorkingTime_SYNCService extends javax.xml.rpc.Service {
    public java.lang.String getHTTPS_PortAddress();

    public com.knorr_bremse.sap_com.plannedWorkingTime.SI_OUT_Worx_PlannedWorkingTime_SYNC getHTTPS_Port() throws javax.xml.rpc.ServiceException;

    public com.knorr_bremse.sap_com.plannedWorkingTime.SI_OUT_Worx_PlannedWorkingTime_SYNC getHTTPS_Port(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public java.lang.String getHTTP_PortAddress();
    public void setHttpsAddress(java.lang.String address);
    public void setHttpAddress(java.lang.String address);
    
    public com.knorr_bremse.sap_com.plannedWorkingTime.SI_OUT_Worx_PlannedWorkingTime_SYNC getHTTP_Port() throws javax.xml.rpc.ServiceException;

    public com.knorr_bremse.sap_com.plannedWorkingTime.SI_OUT_Worx_PlannedWorkingTime_SYNC getHTTP_Port(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
