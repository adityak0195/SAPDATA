/**
 * ZAPO_RES_SHIFTS.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.plannedWorkingTime;

import java.util.UUID;

import com.ptc.kb.sap.TimeUtility;
import com.thingworx.metadata.DataShapeDefinition;
import com.thingworx.metadata.FieldDefinition;
import com.thingworx.types.collections.ValueCollection;
import com.thingworx.types.primitives.DatetimePrimitive;
import com.thingworx.types.primitives.IntegerPrimitive;
import com.thingworx.types.primitives.NumberPrimitive;
import com.thingworx.types.primitives.StringPrimitive;

public class ZAPO_RES_SHIFTS  implements java.io.Serializable {
    /* Client */
    private java.lang.String CLIENT;

    /* Name of Planning Version */
    private java.lang.String VERSION;

    /* Plant */
    private java.lang.String PLANT;

    /* Resource Name */
    private java.lang.String RES_NAME;

    /* Field of type DATS */
    private com.knorr_bremse.sap_com.plannedWorkingTime.Date START_DATE;

    /* Field of type TIMS */
    private com.knorr_bremse.sap_com.plannedWorkingTime.Time START_TIME;

    /* Field of type TIMS */
    private com.knorr_bremse.sap_com.plannedWorkingTime.Time END_TIME;

    /* Version Number Component */
    private java.lang.String QUALIFIER;

    /* Duration in Seconds */
    private java.math.BigInteger AMOUNT;

    /* Rate of Utilization (Percent) */
    private java.math.BigDecimal UTILIZATION;

    /* Name of Shift Definition */
    private java.lang.String TIMEINT;

    /* Short Description */
    private java.lang.String RESDOWNT;

    public ZAPO_RES_SHIFTS() {
    }

    public ZAPO_RES_SHIFTS(
           java.lang.String CLIENT,
           java.lang.String VERSION,
           java.lang.String PLANT,
           java.lang.String RES_NAME,
           com.knorr_bremse.sap_com.plannedWorkingTime.Date START_DATE,
           com.knorr_bremse.sap_com.plannedWorkingTime.Time START_TIME,
           com.knorr_bremse.sap_com.plannedWorkingTime.Time END_TIME,
           java.lang.String QUALIFIER,
           java.math.BigInteger AMOUNT,
           java.math.BigDecimal UTILIZATION,
           java.lang.String TIMEINT,
           java.lang.String RESDOWNT) {
           this.CLIENT = CLIENT;
           this.VERSION = VERSION;
           this.PLANT = PLANT;
           this.RES_NAME = RES_NAME;
           this.START_DATE = START_DATE;
           this.START_TIME = START_TIME;
           this.END_TIME = END_TIME;
           this.QUALIFIER = QUALIFIER;
           this.AMOUNT = AMOUNT;
           this.UTILIZATION = UTILIZATION;
           this.TIMEINT = TIMEINT;
           this.RESDOWNT = RESDOWNT;
    }


    /**
     * Gets the CLIENT value for this ZAPO_RES_SHIFTS.
     * 
     * @return CLIENT   * Client
     */
    public java.lang.String getCLIENT() {
        return CLIENT;
    }


    /**
     * Sets the CLIENT value for this ZAPO_RES_SHIFTS.
     * 
     * @param CLIENT   * Client
     */
    public void setCLIENT(java.lang.String CLIENT) {
        this.CLIENT = CLIENT;
    }


    /**
     * Gets the VERSION value for this ZAPO_RES_SHIFTS.
     * 
     * @return VERSION   * Name of Planning Version
     */
    public java.lang.String getVERSION() {
        return VERSION;
    }


    /**
     * Sets the VERSION value for this ZAPO_RES_SHIFTS.
     * 
     * @param VERSION   * Name of Planning Version
     */
    public void setVERSION(java.lang.String VERSION) {
        this.VERSION = VERSION;
    }


    /**
     * Gets the PLANT value for this ZAPO_RES_SHIFTS.
     * 
     * @return PLANT   * Plant
     */
    public java.lang.String getPLANT() {
        return PLANT;
    }


    /**
     * Sets the PLANT value for this ZAPO_RES_SHIFTS.
     * 
     * @param PLANT   * Plant
     */
    public void setPLANT(java.lang.String PLANT) {
        this.PLANT = PLANT;
    }


    /**
     * Gets the RES_NAME value for this ZAPO_RES_SHIFTS.
     * 
     * @return RES_NAME   * Resource Name
     */
    public java.lang.String getRES_NAME() {
        return RES_NAME;
    }


    /**
     * Sets the RES_NAME value for this ZAPO_RES_SHIFTS.
     * 
     * @param RES_NAME   * Resource Name
     */
    public void setRES_NAME(java.lang.String RES_NAME) {
        this.RES_NAME = RES_NAME;
    }


    /**
     * Gets the START_DATE value for this ZAPO_RES_SHIFTS.
     * 
     * @return START_DATE   * Field of type DATS
     */
    public com.knorr_bremse.sap_com.plannedWorkingTime.Date getSTART_DATE() {
        return START_DATE;
    }


    /**
     * Sets the START_DATE value for this ZAPO_RES_SHIFTS.
     * 
     * @param START_DATE   * Field of type DATS
     */
    public void setSTART_DATE(com.knorr_bremse.sap_com.plannedWorkingTime.Date START_DATE) {
        this.START_DATE = START_DATE;
    }


    /**
     * Gets the START_TIME value for this ZAPO_RES_SHIFTS.
     * 
     * @return START_TIME   * Field of type TIMS
     */
    public com.knorr_bremse.sap_com.plannedWorkingTime.Time getSTART_TIME() {
        return START_TIME;
    }


    /**
     * Sets the START_TIME value for this ZAPO_RES_SHIFTS.
     * 
     * @param START_TIME   * Field of type TIMS
     */
    public void setSTART_TIME(com.knorr_bremse.sap_com.plannedWorkingTime.Time START_TIME) {
        this.START_TIME = START_TIME;
    }


    /**
     * Gets the END_TIME value for this ZAPO_RES_SHIFTS.
     * 
     * @return END_TIME   * Field of type TIMS
     */
    public com.knorr_bremse.sap_com.plannedWorkingTime.Time getEND_TIME() {
        return END_TIME;
    }


    /**
     * Sets the END_TIME value for this ZAPO_RES_SHIFTS.
     * 
     * @param END_TIME   * Field of type TIMS
     */
    public void setEND_TIME(com.knorr_bremse.sap_com.plannedWorkingTime.Time END_TIME) {
        this.END_TIME = END_TIME;
    }


    /**
     * Gets the QUALIFIER value for this ZAPO_RES_SHIFTS.
     * 
     * @return QUALIFIER   * Version Number Component
     */
    public java.lang.String getQUALIFIER() {
        return QUALIFIER;
    }


    /**
     * Sets the QUALIFIER value for this ZAPO_RES_SHIFTS.
     * 
     * @param QUALIFIER   * Version Number Component
     */
    public void setQUALIFIER(java.lang.String QUALIFIER) {
        this.QUALIFIER = QUALIFIER;
    }


    /**
     * Gets the AMOUNT value for this ZAPO_RES_SHIFTS.
     * 
     * @return AMOUNT   * Duration in Seconds
     */
    public java.math.BigInteger getAMOUNT() {
        return AMOUNT;
    }


    /**
     * Sets the AMOUNT value for this ZAPO_RES_SHIFTS.
     * 
     * @param AMOUNT   * Duration in Seconds
     */
    public void setAMOUNT(java.math.BigInteger AMOUNT) {
        this.AMOUNT = AMOUNT;
    }


    /**
     * Gets the UTILIZATION value for this ZAPO_RES_SHIFTS.
     * 
     * @return UTILIZATION   * Rate of Utilization (Percent)
     */
    public java.math.BigDecimal getUTILIZATION() {
        return UTILIZATION;
    }


    /**
     * Sets the UTILIZATION value for this ZAPO_RES_SHIFTS.
     * 
     * @param UTILIZATION   * Rate of Utilization (Percent)
     */
    public void setUTILIZATION(java.math.BigDecimal UTILIZATION) {
        this.UTILIZATION = UTILIZATION;
    }


    /**
     * Gets the TIMEINT value for this ZAPO_RES_SHIFTS.
     * 
     * @return TIMEINT   * Name of Shift Definition
     */
    public java.lang.String getTIMEINT() {
        return TIMEINT;
    }


    /**
     * Sets the TIMEINT value for this ZAPO_RES_SHIFTS.
     * 
     * @param TIMEINT   * Name of Shift Definition
     */
    public void setTIMEINT(java.lang.String TIMEINT) {
        this.TIMEINT = TIMEINT;
    }


    /**
     * Gets the RESDOWNT value for this ZAPO_RES_SHIFTS.
     * 
     * @return RESDOWNT   * Short Description
     */
    public java.lang.String getRESDOWNT() {
        return RESDOWNT;
    }


    /**
     * Sets the RESDOWNT value for this ZAPO_RES_SHIFTS.
     * 
     * @param RESDOWNT   * Short Description
     */
    public void setRESDOWNT(java.lang.String RESDOWNT) {
        this.RESDOWNT = RESDOWNT;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ZAPO_RES_SHIFTS)) return false;
        ZAPO_RES_SHIFTS other = (ZAPO_RES_SHIFTS) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.CLIENT==null && other.getCLIENT()==null) || 
             (this.CLIENT!=null &&
              this.CLIENT.equals(other.getCLIENT()))) &&
            ((this.VERSION==null && other.getVERSION()==null) || 
             (this.VERSION!=null &&
              this.VERSION.equals(other.getVERSION()))) &&
            ((this.PLANT==null && other.getPLANT()==null) || 
             (this.PLANT!=null &&
              this.PLANT.equals(other.getPLANT()))) &&
            ((this.RES_NAME==null && other.getRES_NAME()==null) || 
             (this.RES_NAME!=null &&
              this.RES_NAME.equals(other.getRES_NAME()))) &&
            ((this.START_DATE==null && other.getSTART_DATE()==null) || 
             (this.START_DATE!=null &&
              this.START_DATE.equals(other.getSTART_DATE()))) &&
            ((this.START_TIME==null && other.getSTART_TIME()==null) || 
             (this.START_TIME!=null &&
              this.START_TIME.equals(other.getSTART_TIME()))) &&
            ((this.END_TIME==null && other.getEND_TIME()==null) || 
             (this.END_TIME!=null &&
              this.END_TIME.equals(other.getEND_TIME()))) &&
            ((this.QUALIFIER==null && other.getQUALIFIER()==null) || 
             (this.QUALIFIER!=null &&
              this.QUALIFIER.equals(other.getQUALIFIER()))) &&
            ((this.AMOUNT==null && other.getAMOUNT()==null) || 
             (this.AMOUNT!=null &&
              this.AMOUNT.equals(other.getAMOUNT()))) &&
            ((this.UTILIZATION==null && other.getUTILIZATION()==null) || 
             (this.UTILIZATION!=null &&
              this.UTILIZATION.equals(other.getUTILIZATION()))) &&
            ((this.TIMEINT==null && other.getTIMEINT()==null) || 
             (this.TIMEINT!=null &&
              this.TIMEINT.equals(other.getTIMEINT()))) &&
            ((this.RESDOWNT==null && other.getRESDOWNT()==null) || 
             (this.RESDOWNT!=null &&
              this.RESDOWNT.equals(other.getRESDOWNT())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCLIENT() != null) {
            _hashCode += getCLIENT().hashCode();
        }
        if (getVERSION() != null) {
            _hashCode += getVERSION().hashCode();
        }
        if (getPLANT() != null) {
            _hashCode += getPLANT().hashCode();
        }
        if (getRES_NAME() != null) {
            _hashCode += getRES_NAME().hashCode();
        }
        if (getSTART_DATE() != null) {
            _hashCode += getSTART_DATE().hashCode();
        }
        if (getSTART_TIME() != null) {
            _hashCode += getSTART_TIME().hashCode();
        }
        if (getEND_TIME() != null) {
            _hashCode += getEND_TIME().hashCode();
        }
        if (getQUALIFIER() != null) {
            _hashCode += getQUALIFIER().hashCode();
        }
        if (getAMOUNT() != null) {
            _hashCode += getAMOUNT().hashCode();
        }
        if (getUTILIZATION() != null) {
            _hashCode += getUTILIZATION().hashCode();
        }
        if (getTIMEINT() != null) {
            _hashCode += getTIMEINT().hashCode();
        }
        if (getRESDOWNT() != null) {
            _hashCode += getRESDOWNT().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ZAPO_RES_SHIFTS.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:rfc:functions", "ZAPO_RES_SHIFTS"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLIENT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CLIENT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("VERSION");
        elemField.setXmlName(new javax.xml.namespace.QName("", "VERSION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PLANT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PLANT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RES_NAME");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RES_NAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("START_DATE");
        elemField.setXmlName(new javax.xml.namespace.QName("", "START_DATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:rfc:functions", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("START_TIME");
        elemField.setXmlName(new javax.xml.namespace.QName("", "START_TIME"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:rfc:functions", "time"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("END_TIME");
        elemField.setXmlName(new javax.xml.namespace.QName("", "END_TIME"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:rfc:functions", "time"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QUALIFIER");
        elemField.setXmlName(new javax.xml.namespace.QName("", "QUALIFIER"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMOUNT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AMOUNT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UTILIZATION");
        elemField.setXmlName(new javax.xml.namespace.QName("", "UTILIZATION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TIMEINT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TIMEINT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RESDOWNT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RESDOWNT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

	@Override
	public String toString() {
		return "ZAPO_RES_SHIFTS [CLIENT=" + CLIENT + ", VERSION=" + VERSION + ", PLANT=" + PLANT + ", RES_NAME="
				+ RES_NAME + ", START_DATE=" + START_DATE + ", START_TIME=" + START_TIME + ", END_TIME=" + END_TIME
				+ ", QUALIFIER=" + QUALIFIER + ", AMOUNT=" + AMOUNT + ", UTILIZATION=" + UTILIZATION + ", TIMEINT="
				+ TIMEINT + ", RESDOWNT=" + RESDOWNT + "]";
	}

	public ValueCollection toValueCollection() {
		ValueCollection vc = new ValueCollection();
//		vc.put("pk", new StringPrimitive(UUID.randomUUID().toString()));
		vc.put("pk", new StringPrimitive(RES_NAME + "_" + START_DATE.getGenericDateValue() + "_" + START_TIME.getGenericTimeValue()));
		vc.put("plant", new StringPrimitive(PLANT));
		vc.put("resName", new StringPrimitive(RES_NAME));
		vc.put("qualifier", new StringPrimitive(QUALIFIER));
		vc.put("amount", new IntegerPrimitive(AMOUNT.intValue()));
		vc.put("utilization", new NumberPrimitive(UTILIZATION.doubleValue()));
		vc.put("timeInt", new StringPrimitive(TIMEINT));
		vc.put("resDownt", new StringPrimitive(RESDOWNT));

		vc.put("startDate", new StringPrimitive(START_DATE.getGenericDateValue()));
		vc.put("startTime", new StringPrimitive(START_TIME.getGenericTimeValue()));
		vc.put("startTimestamp", new DatetimePrimitive(
				TimeUtility.makeTimestamp(START_DATE.getGenericDateValue(), START_TIME.getGenericTimeValue()))
			);
		vc.put("endTime", new StringPrimitive(END_TIME.getGenericTimeValue()));
		vc.put("endTimestamp", new DatetimePrimitive(
				TimeUtility.makeTimestamp(START_DATE.getGenericDateValue(), END_TIME.getGenericTimeValue()))
			);
		
		return vc;
	}
//	
//	public static final DataShapeDefinition DATA_SHAPE = new DataShapeDefinition();
//	static {
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("plant", "STRING"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("resName", "STRING"));		// WEF105331_1051_001 
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("startDate", "STRING"));		// 2015-12-20
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("startTime", "STRING"));		// 22:30:00
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("startTimestamp", "DATETIME"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("endTime", "STRING"));		// 24:00:00
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("endTimestamp", "DATETIME"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("qualifier", "STRING"));		// B
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("amount", "INTEGER"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("utilization", "NUMBER"));
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("timeInt", "STRING"));		// YD_SHIFT_1  
//		DATA_SHAPE.addFieldDefinition(new FieldDefinition("resDownt", "STRING"));		// YD_BREAK_1
//	}
    
}
