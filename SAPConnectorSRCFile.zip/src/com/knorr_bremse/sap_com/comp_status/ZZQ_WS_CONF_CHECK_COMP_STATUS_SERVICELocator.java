/**
 * ZZQ_WS_CONF_CHECK_COMP_STATUS_SERVICELocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.comp_status;

public class ZZQ_WS_CONF_CHECK_COMP_STATUS_SERVICELocator extends org.apache.axis.client.Service implements com.knorr_bremse.sap_com.comp_status.ZZQ_WS_CONF_CHECK_COMP_STATUS_SERVICE {

    public ZZQ_WS_CONF_CHECK_COMP_STATUS_SERVICELocator() {
    }


    public ZZQ_WS_CONF_CHECK_COMP_STATUS_SERVICELocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public ZZQ_WS_CONF_CHECK_COMP_STATUS_SERVICELocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    public void setHttpsAddress(java.lang.String address) {
    	CONF_CHECK_COMP_STATUS_address = address;
    }
    // Use to get a proxy class for CONF_CHECK_COMP_STATUS
    private java.lang.String CONF_CHECK_COMP_STATUS_address;

    public java.lang.String getCONF_CHECK_COMP_STATUSAddress() {
        return CONF_CHECK_COMP_STATUS_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String CONF_CHECK_COMP_STATUSWSDDServiceName = "CONF_CHECK_COMP_STATUS";

    public java.lang.String getCONF_CHECK_COMP_STATUSWSDDServiceName() {
        return CONF_CHECK_COMP_STATUSWSDDServiceName;
    }

    public void setCONF_CHECK_COMP_STATUSWSDDServiceName(java.lang.String name) {
        CONF_CHECK_COMP_STATUSWSDDServiceName = name;
    }

    public com.knorr_bremse.sap_com.comp_status.Zzq_ws_conf_check_comp_status getCONF_CHECK_COMP_STATUS() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(CONF_CHECK_COMP_STATUS_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCONF_CHECK_COMP_STATUS(endpoint);
    }

    public com.knorr_bremse.sap_com.comp_status.Zzq_ws_conf_check_comp_status getCONF_CHECK_COMP_STATUS(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.knorr_bremse.sap_com.comp_status.CONF_CHECK_COMP_STATUSStub _stub = new com.knorr_bremse.sap_com.comp_status.CONF_CHECK_COMP_STATUSStub(portAddress, this);
            _stub.setPortName(getCONF_CHECK_COMP_STATUSWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCONF_CHECK_COMP_STATUSEndpointAddress(java.lang.String address) {
        CONF_CHECK_COMP_STATUS_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.knorr_bremse.sap_com.comp_status.Zzq_ws_conf_check_comp_status.class.isAssignableFrom(serviceEndpointInterface)) {
                com.knorr_bremse.sap_com.comp_status.CONF_CHECK_COMP_STATUSStub _stub = new com.knorr_bremse.sap_com.comp_status.CONF_CHECK_COMP_STATUSStub(new java.net.URL(CONF_CHECK_COMP_STATUS_address), this);
                _stub.setPortName(getCONF_CHECK_COMP_STATUSWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("CONF_CHECK_COMP_STATUS".equals(inputPortName)) {
            return getCONF_CHECK_COMP_STATUS();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("urn:sap-com:document:sap:soap:functions:mc-style", "ZZQ_WS_CONF_CHECK_COMP_STATUS_SERVICE");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("urn:sap-com:document:sap:soap:functions:mc-style", "CONF_CHECK_COMP_STATUS"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("CONF_CHECK_COMP_STATUS".equals(portName)) {
            setCONF_CHECK_COMP_STATUSEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
