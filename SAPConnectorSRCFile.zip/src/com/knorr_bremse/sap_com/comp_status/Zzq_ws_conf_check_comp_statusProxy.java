package com.knorr_bremse.sap_com.comp_status;

public class Zzq_ws_conf_check_comp_statusProxy implements com.knorr_bremse.sap_com.comp_status.Zzq_ws_conf_check_comp_status {
  private String _endpoint = null;
  private com.knorr_bremse.sap_com.comp_status.Zzq_ws_conf_check_comp_status zzq_ws_conf_check_comp_status = null;
  
  public Zzq_ws_conf_check_comp_statusProxy() {
    _initZzq_ws_conf_check_comp_statusProxy();
  }
  
  public Zzq_ws_conf_check_comp_statusProxy(String endpoint) {
    _endpoint = endpoint;
    _initZzq_ws_conf_check_comp_statusProxy();
  }
  
  private void _initZzq_ws_conf_check_comp_statusProxy() {
    try {
      zzq_ws_conf_check_comp_status = (new com.knorr_bremse.sap_com.comp_status.ZZQ_WS_CONF_CHECK_COMP_STATUS_SERVICELocator()).getCONF_CHECK_COMP_STATUS();
      if (zzq_ws_conf_check_comp_status != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)zzq_ws_conf_check_comp_status)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)zzq_ws_conf_check_comp_status)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (zzq_ws_conf_check_comp_status != null)
      ((javax.xml.rpc.Stub)zzq_ws_conf_check_comp_status)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.knorr_bremse.sap_com.comp_status.Zzq_ws_conf_check_comp_status getZzq_ws_conf_check_comp_status() {
    if (zzq_ws_conf_check_comp_status == null)
      _initZzq_ws_conf_check_comp_statusProxy();
    return zzq_ws_conf_check_comp_status;
  }
  
  public com.knorr_bremse.sap_com.comp_status.ZzqConfigReturnMessage[] zzqConfigCheckCompStatus(java.lang.String ICallId, java.lang.String IMatnr, java.lang.String ISernr) throws java.rmi.RemoteException{
    if (zzq_ws_conf_check_comp_status == null)
      _initZzq_ws_conf_check_comp_statusProxy();
    return zzq_ws_conf_check_comp_status.zzqConfigCheckCompStatus(ICallId, IMatnr, ISernr);
  }
  
  
}