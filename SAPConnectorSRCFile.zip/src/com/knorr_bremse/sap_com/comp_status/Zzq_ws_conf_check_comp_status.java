/**
 * Zzq_ws_conf_check_comp_status.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.comp_status;

public interface Zzq_ws_conf_check_comp_status extends java.rmi.Remote {
    public com.knorr_bremse.sap_com.comp_status.ZzqConfigReturnMessage[] zzqConfigCheckCompStatus(java.lang.String ICallId, java.lang.String IMatnr, java.lang.String ISernr) throws java.rmi.RemoteException;
}
