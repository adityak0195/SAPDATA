/**
 * ZZQ_WS_CONF_CHECK_COMP_STATUS_SERVICE.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.comp_status;

public interface ZZQ_WS_CONF_CHECK_COMP_STATUS_SERVICE extends javax.xml.rpc.Service {
    public java.lang.String getCONF_CHECK_COMP_STATUSAddress();

    public com.knorr_bremse.sap_com.comp_status.Zzq_ws_conf_check_comp_status getCONF_CHECK_COMP_STATUS() throws javax.xml.rpc.ServiceException;
    public void setHttpsAddress(java.lang.String address);

    public com.knorr_bremse.sap_com.comp_status.Zzq_ws_conf_check_comp_status getCONF_CHECK_COMP_STATUS(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
