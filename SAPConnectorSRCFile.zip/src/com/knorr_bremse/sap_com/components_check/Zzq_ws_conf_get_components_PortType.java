/**
 * Zzq_ws_conf_get_components_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.components_check;

public interface Zzq_ws_conf_get_components_PortType extends java.rmi.Remote {
    public void zzqConfigGetComponents(java.lang.String IAufnr, java.lang.String ICallId, java.lang.String IMatnr, java.lang.String IZzaeind, com.knorr_bremse.sap_com.components_check.holders.ZzqTConfigComponentsHolder etComponents, com.knorr_bremse.sap_com.components_check.holders.ZzqTConfigReturnMessageHolder etReturn) throws java.rmi.RemoteException;
}
