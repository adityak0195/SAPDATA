package com.knorr_bremse.sap_com.components_check;

public class Zzq_ws_conf_get_componentsProxy implements com.knorr_bremse.sap_com.components_check.Zzq_ws_conf_get_components_PortType {
  private String _endpoint = null;
  private com.knorr_bremse.sap_com.components_check.Zzq_ws_conf_get_components_PortType zzq_ws_conf_get_components_PortType = null;
  
  public Zzq_ws_conf_get_componentsProxy() {
    _initZzq_ws_conf_get_componentsProxy();
  }
  
  public Zzq_ws_conf_get_componentsProxy(String endpoint) {
    _endpoint = endpoint;
    _initZzq_ws_conf_get_componentsProxy();
  }
  
  private void _initZzq_ws_conf_get_componentsProxy() {
    try {
      zzq_ws_conf_get_components_PortType = (new com.knorr_bremse.sap_com.components_check.Zzq_ws_conf_get_components_ServiceLocator()).getCONF_GET_COMPONENTS();
      if (zzq_ws_conf_get_components_PortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)zzq_ws_conf_get_components_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)zzq_ws_conf_get_components_PortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (zzq_ws_conf_get_components_PortType != null)
      ((javax.xml.rpc.Stub)zzq_ws_conf_get_components_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.knorr_bremse.sap_com.components_check.Zzq_ws_conf_get_components_PortType getZzq_ws_conf_get_components_PortType() {
    if (zzq_ws_conf_get_components_PortType == null)
      _initZzq_ws_conf_get_componentsProxy();
    return zzq_ws_conf_get_components_PortType;
  }
  
  public void zzqConfigGetComponents(java.lang.String IAufnr, java.lang.String ICallId, java.lang.String IMatnr, java.lang.String IZzaeind, com.knorr_bremse.sap_com.components_check.holders.ZzqTConfigComponentsHolder etComponents, com.knorr_bremse.sap_com.components_check.holders.ZzqTConfigReturnMessageHolder etReturn) throws java.rmi.RemoteException{
    if (zzq_ws_conf_get_components_PortType == null)
      _initZzq_ws_conf_get_componentsProxy();
    zzq_ws_conf_get_components_PortType.zzqConfigGetComponents(IAufnr, ICallId, IMatnr, IZzaeind, etComponents, etReturn);
  }
  
  
}