/**
 * Zzq_ws_conf_get_components_Service.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.components_check;

public interface Zzq_ws_conf_get_components_Service extends javax.xml.rpc.Service {
    public java.lang.String getCONF_GET_COMPONENTSAddress();

    public com.knorr_bremse.sap_com.components_check.Zzq_ws_conf_get_components_PortType getCONF_GET_COMPONENTS() throws javax.xml.rpc.ServiceException;
    public void setHttpsAddress(java.lang.String address);

    public com.knorr_bremse.sap_com.components_check.Zzq_ws_conf_get_components_PortType getCONF_GET_COMPONENTS(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
