/**
 * Zzq_ws_conf_get_components_ServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.components_check;

public class Zzq_ws_conf_get_components_ServiceLocator extends org.apache.axis.client.Service implements com.knorr_bremse.sap_com.components_check.Zzq_ws_conf_get_components_Service {

    public Zzq_ws_conf_get_components_ServiceLocator() {
    }


    public Zzq_ws_conf_get_components_ServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public Zzq_ws_conf_get_components_ServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    public void setHttpsAddress(java.lang.String address) {
    	CONF_GET_COMPONENTS_address = address;
    }
    // Use to get a proxy class for CONF_GET_COMPONENTS
    private java.lang.String CONF_GET_COMPONENTS_address;

    public java.lang.String getCONF_GET_COMPONENTSAddress() {
        return CONF_GET_COMPONENTS_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String CONF_GET_COMPONENTSWSDDServiceName = "CONF_GET_COMPONENTS";

    public java.lang.String getCONF_GET_COMPONENTSWSDDServiceName() {
        return CONF_GET_COMPONENTSWSDDServiceName;
    }

    public void setCONF_GET_COMPONENTSWSDDServiceName(java.lang.String name) {
        CONF_GET_COMPONENTSWSDDServiceName = name;
    }

    public com.knorr_bremse.sap_com.components_check.Zzq_ws_conf_get_components_PortType getCONF_GET_COMPONENTS() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(CONF_GET_COMPONENTS_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCONF_GET_COMPONENTS(endpoint);
    }

    public com.knorr_bremse.sap_com.components_check.Zzq_ws_conf_get_components_PortType getCONF_GET_COMPONENTS(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.knorr_bremse.sap_com.components_check.CONF_GET_COMPONENTSStub _stub = new com.knorr_bremse.sap_com.components_check.CONF_GET_COMPONENTSStub(portAddress, this);
            _stub.setPortName(getCONF_GET_COMPONENTSWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCONF_GET_COMPONENTSEndpointAddress(java.lang.String address) {
        CONF_GET_COMPONENTS_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.knorr_bremse.sap_com.components_check.Zzq_ws_conf_get_components_PortType.class.isAssignableFrom(serviceEndpointInterface)) {
                com.knorr_bremse.sap_com.components_check.CONF_GET_COMPONENTSStub _stub = new com.knorr_bremse.sap_com.components_check.CONF_GET_COMPONENTSStub(new java.net.URL(CONF_GET_COMPONENTS_address), this);
                _stub.setPortName(getCONF_GET_COMPONENTSWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("CONF_GET_COMPONENTS".equals(inputPortName)) {
            return getCONF_GET_COMPONENTS();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("urn:sap-com:document:sap:soap:functions:mc-style", "zzq_ws_conf_get_components");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("urn:sap-com:document:sap:soap:functions:mc-style", "CONF_GET_COMPONENTS"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("CONF_GET_COMPONENTS".equals(portName)) {
            setCONF_GET_COMPONENTSEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
