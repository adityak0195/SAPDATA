/**
 * ZzqSConfigComponents.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.components_check;

public class ZzqSConfigComponents  implements java.io.Serializable {
    private java.lang.String posno;

    private java.lang.String matnrHead;

    private java.lang.String maktxHead;

    private java.lang.String zzaindexBom;

    private java.lang.String werks;

    private java.lang.String zzaindexHead;

    private java.lang.String zzconfigFlagHead;

    private java.lang.String sernpHead;

    private java.lang.String matnrItem;

    private java.lang.String maktxItem;

    private java.lang.String zzaindexItem;

    private java.lang.String zzconfigFlagItem;

    private java.lang.String sernpItem;

    private java.lang.String itemInPlant;

    private java.lang.String configDummy;

    public ZzqSConfigComponents() {
    }

    public ZzqSConfigComponents(
           java.lang.String posno,
           java.lang.String matnrHead,
           java.lang.String maktxHead,
           java.lang.String zzaindexBom,
           java.lang.String werks,
           java.lang.String zzaindexHead,
           java.lang.String zzconfigFlagHead,
           java.lang.String sernpHead,
           java.lang.String matnrItem,
           java.lang.String maktxItem,
           java.lang.String zzaindexItem,
           java.lang.String zzconfigFlagItem,
           java.lang.String sernpItem,
           java.lang.String itemInPlant,
           java.lang.String configDummy) {
           this.posno = posno;
           this.matnrHead = matnrHead;
           this.maktxHead = maktxHead;
           this.zzaindexBom = zzaindexBom;
           this.werks = werks;
           this.zzaindexHead = zzaindexHead;
           this.zzconfigFlagHead = zzconfigFlagHead;
           this.sernpHead = sernpHead;
           this.matnrItem = matnrItem;
           this.maktxItem = maktxItem;
           this.zzaindexItem = zzaindexItem;
           this.zzconfigFlagItem = zzconfigFlagItem;
           this.sernpItem = sernpItem;
           this.itemInPlant = itemInPlant;
           this.configDummy = configDummy;
    }


    /**
     * Gets the posno value for this ZzqSConfigComponents.
     * 
     * @return posno
     */
    public java.lang.String getPosno() {
        return posno;
    }


    /**
     * Sets the posno value for this ZzqSConfigComponents.
     * 
     * @param posno
     */
    public void setPosno(java.lang.String posno) {
        this.posno = posno;
    }


    /**
     * Gets the matnrHead value for this ZzqSConfigComponents.
     * 
     * @return matnrHead
     */
    public java.lang.String getMatnrHead() {
        return matnrHead;
    }


    /**
     * Sets the matnrHead value for this ZzqSConfigComponents.
     * 
     * @param matnrHead
     */
    public void setMatnrHead(java.lang.String matnrHead) {
        this.matnrHead = matnrHead;
    }


    /**
     * Gets the maktxHead value for this ZzqSConfigComponents.
     * 
     * @return maktxHead
     */
    public java.lang.String getMaktxHead() {
        return maktxHead;
    }


    /**
     * Sets the maktxHead value for this ZzqSConfigComponents.
     * 
     * @param maktxHead
     */
    public void setMaktxHead(java.lang.String maktxHead) {
        this.maktxHead = maktxHead;
    }


    /**
     * Gets the zzaindexBom value for this ZzqSConfigComponents.
     * 
     * @return zzaindexBom
     */
    public java.lang.String getZzaindexBom() {
        return zzaindexBom;
    }


    /**
     * Sets the zzaindexBom value for this ZzqSConfigComponents.
     * 
     * @param zzaindexBom
     */
    public void setZzaindexBom(java.lang.String zzaindexBom) {
        this.zzaindexBom = zzaindexBom;
    }


    /**
     * Gets the werks value for this ZzqSConfigComponents.
     * 
     * @return werks
     */
    public java.lang.String getWerks() {
        return werks;
    }


    /**
     * Sets the werks value for this ZzqSConfigComponents.
     * 
     * @param werks
     */
    public void setWerks(java.lang.String werks) {
        this.werks = werks;
    }


    /**
     * Gets the zzaindexHead value for this ZzqSConfigComponents.
     * 
     * @return zzaindexHead
     */
    public java.lang.String getZzaindexHead() {
        return zzaindexHead;
    }


    /**
     * Sets the zzaindexHead value for this ZzqSConfigComponents.
     * 
     * @param zzaindexHead
     */
    public void setZzaindexHead(java.lang.String zzaindexHead) {
        this.zzaindexHead = zzaindexHead;
    }


    /**
     * Gets the zzconfigFlagHead value for this ZzqSConfigComponents.
     * 
     * @return zzconfigFlagHead
     */
    public java.lang.String getZzconfigFlagHead() {
        return zzconfigFlagHead;
    }


    /**
     * Sets the zzconfigFlagHead value for this ZzqSConfigComponents.
     * 
     * @param zzconfigFlagHead
     */
    public void setZzconfigFlagHead(java.lang.String zzconfigFlagHead) {
        this.zzconfigFlagHead = zzconfigFlagHead;
    }


    /**
     * Gets the sernpHead value for this ZzqSConfigComponents.
     * 
     * @return sernpHead
     */
    public java.lang.String getSernpHead() {
        return sernpHead;
    }


    /**
     * Sets the sernpHead value for this ZzqSConfigComponents.
     * 
     * @param sernpHead
     */
    public void setSernpHead(java.lang.String sernpHead) {
        this.sernpHead = sernpHead;
    }


    /**
     * Gets the matnrItem value for this ZzqSConfigComponents.
     * 
     * @return matnrItem
     */
    public java.lang.String getMatnrItem() {
        return matnrItem;
    }


    /**
     * Sets the matnrItem value for this ZzqSConfigComponents.
     * 
     * @param matnrItem
     */
    public void setMatnrItem(java.lang.String matnrItem) {
        this.matnrItem = matnrItem;
    }


    /**
     * Gets the maktxItem value for this ZzqSConfigComponents.
     * 
     * @return maktxItem
     */
    public java.lang.String getMaktxItem() {
        return maktxItem;
    }


    /**
     * Sets the maktxItem value for this ZzqSConfigComponents.
     * 
     * @param maktxItem
     */
    public void setMaktxItem(java.lang.String maktxItem) {
        this.maktxItem = maktxItem;
    }


    /**
     * Gets the zzaindexItem value for this ZzqSConfigComponents.
     * 
     * @return zzaindexItem
     */
    public java.lang.String getZzaindexItem() {
        return zzaindexItem;
    }


    /**
     * Sets the zzaindexItem value for this ZzqSConfigComponents.
     * 
     * @param zzaindexItem
     */
    public void setZzaindexItem(java.lang.String zzaindexItem) {
        this.zzaindexItem = zzaindexItem;
    }


    /**
     * Gets the zzconfigFlagItem value for this ZzqSConfigComponents.
     * 
     * @return zzconfigFlagItem
     */
    public java.lang.String getZzconfigFlagItem() {
        return zzconfigFlagItem;
    }


    /**
     * Sets the zzconfigFlagItem value for this ZzqSConfigComponents.
     * 
     * @param zzconfigFlagItem
     */
    public void setZzconfigFlagItem(java.lang.String zzconfigFlagItem) {
        this.zzconfigFlagItem = zzconfigFlagItem;
    }


    /**
     * Gets the sernpItem value for this ZzqSConfigComponents.
     * 
     * @return sernpItem
     */
    public java.lang.String getSernpItem() {
        return sernpItem;
    }


    /**
     * Sets the sernpItem value for this ZzqSConfigComponents.
     * 
     * @param sernpItem
     */
    public void setSernpItem(java.lang.String sernpItem) {
        this.sernpItem = sernpItem;
    }


    /**
     * Gets the itemInPlant value for this ZzqSConfigComponents.
     * 
     * @return itemInPlant
     */
    public java.lang.String getItemInPlant() {
        return itemInPlant;
    }


    /**
     * Sets the itemInPlant value for this ZzqSConfigComponents.
     * 
     * @param itemInPlant
     */
    public void setItemInPlant(java.lang.String itemInPlant) {
        this.itemInPlant = itemInPlant;
    }


    /**
     * Gets the configDummy value for this ZzqSConfigComponents.
     * 
     * @return configDummy
     */
    public java.lang.String getConfigDummy() {
        return configDummy;
    }


    /**
     * Sets the configDummy value for this ZzqSConfigComponents.
     * 
     * @param configDummy
     */
    public void setConfigDummy(java.lang.String configDummy) {
        this.configDummy = configDummy;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ZzqSConfigComponents)) return false;
        ZzqSConfigComponents other = (ZzqSConfigComponents) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.posno==null && other.getPosno()==null) || 
             (this.posno!=null &&
              this.posno.equals(other.getPosno()))) &&
            ((this.matnrHead==null && other.getMatnrHead()==null) || 
             (this.matnrHead!=null &&
              this.matnrHead.equals(other.getMatnrHead()))) &&
            ((this.maktxHead==null && other.getMaktxHead()==null) || 
             (this.maktxHead!=null &&
              this.maktxHead.equals(other.getMaktxHead()))) &&
            ((this.zzaindexBom==null && other.getZzaindexBom()==null) || 
             (this.zzaindexBom!=null &&
              this.zzaindexBom.equals(other.getZzaindexBom()))) &&
            ((this.werks==null && other.getWerks()==null) || 
             (this.werks!=null &&
              this.werks.equals(other.getWerks()))) &&
            ((this.zzaindexHead==null && other.getZzaindexHead()==null) || 
             (this.zzaindexHead!=null &&
              this.zzaindexHead.equals(other.getZzaindexHead()))) &&
            ((this.zzconfigFlagHead==null && other.getZzconfigFlagHead()==null) || 
             (this.zzconfigFlagHead!=null &&
              this.zzconfigFlagHead.equals(other.getZzconfigFlagHead()))) &&
            ((this.sernpHead==null && other.getSernpHead()==null) || 
             (this.sernpHead!=null &&
              this.sernpHead.equals(other.getSernpHead()))) &&
            ((this.matnrItem==null && other.getMatnrItem()==null) || 
             (this.matnrItem!=null &&
              this.matnrItem.equals(other.getMatnrItem()))) &&
            ((this.maktxItem==null && other.getMaktxItem()==null) || 
             (this.maktxItem!=null &&
              this.maktxItem.equals(other.getMaktxItem()))) &&
            ((this.zzaindexItem==null && other.getZzaindexItem()==null) || 
             (this.zzaindexItem!=null &&
              this.zzaindexItem.equals(other.getZzaindexItem()))) &&
            ((this.zzconfigFlagItem==null && other.getZzconfigFlagItem()==null) || 
             (this.zzconfigFlagItem!=null &&
              this.zzconfigFlagItem.equals(other.getZzconfigFlagItem()))) &&
            ((this.sernpItem==null && other.getSernpItem()==null) || 
             (this.sernpItem!=null &&
              this.sernpItem.equals(other.getSernpItem()))) &&
            ((this.itemInPlant==null && other.getItemInPlant()==null) || 
             (this.itemInPlant!=null &&
              this.itemInPlant.equals(other.getItemInPlant()))) &&
            ((this.configDummy==null && other.getConfigDummy()==null) || 
             (this.configDummy!=null &&
              this.configDummy.equals(other.getConfigDummy())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPosno() != null) {
            _hashCode += getPosno().hashCode();
        }
        if (getMatnrHead() != null) {
            _hashCode += getMatnrHead().hashCode();
        }
        if (getMaktxHead() != null) {
            _hashCode += getMaktxHead().hashCode();
        }
        if (getZzaindexBom() != null) {
            _hashCode += getZzaindexBom().hashCode();
        }
        if (getWerks() != null) {
            _hashCode += getWerks().hashCode();
        }
        if (getZzaindexHead() != null) {
            _hashCode += getZzaindexHead().hashCode();
        }
        if (getZzconfigFlagHead() != null) {
            _hashCode += getZzconfigFlagHead().hashCode();
        }
        if (getSernpHead() != null) {
            _hashCode += getSernpHead().hashCode();
        }
        if (getMatnrItem() != null) {
            _hashCode += getMatnrItem().hashCode();
        }
        if (getMaktxItem() != null) {
            _hashCode += getMaktxItem().hashCode();
        }
        if (getZzaindexItem() != null) {
            _hashCode += getZzaindexItem().hashCode();
        }
        if (getZzconfigFlagItem() != null) {
            _hashCode += getZzconfigFlagItem().hashCode();
        }
        if (getSernpItem() != null) {
            _hashCode += getSernpItem().hashCode();
        }
        if (getItemInPlant() != null) {
            _hashCode += getItemInPlant().hashCode();
        }
        if (getConfigDummy() != null) {
            _hashCode += getConfigDummy().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ZzqSConfigComponents.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:soap:functions:mc-style", "ZzqSConfigComponents"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("posno");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Posno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("matnrHead");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MatnrHead"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maktxHead");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MaktxHead"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("zzaindexBom");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZzaindexBom"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("werks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Werks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("zzaindexHead");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZzaindexHead"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("zzconfigFlagHead");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZzconfigFlagHead"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sernpHead");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SernpHead"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("matnrItem");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MatnrItem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maktxItem");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MaktxItem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("zzaindexItem");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZzaindexItem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("zzconfigFlagItem");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZzconfigFlagItem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sernpItem");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SernpItem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("itemInPlant");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ItemInPlant"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("configDummy");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ConfigDummy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
