/**
 * ZZQ_WS_CREATE_TESTREPLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.testReportUpload;

public class ZZQ_WS_CREATE_TESTREPLocator extends org.apache.axis.client.Service implements com.knorr_bremse.sap_com.testReportUpload.ZZQ_WS_CREATE_TESTREP {

    public ZZQ_WS_CREATE_TESTREPLocator() {
    }


    public ZZQ_WS_CREATE_TESTREPLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public ZZQ_WS_CREATE_TESTREPLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for CREATE_TESTREP
    private java.lang.String CREATE_TESTREP_address;

    public java.lang.String getCREATE_TESTREPAddress() {
        return CREATE_TESTREP_address;
    }
    
    public void setHttpAddress(java.lang.String httpAddress)
    {
    	CREATE_TESTREP_address = httpAddress;
    }


    // The WSDD service name defaults to the port name.
    private java.lang.String CREATE_TESTREPWSDDServiceName = "CREATE_TESTREP";

    public java.lang.String getCREATE_TESTREPWSDDServiceName() {
        return CREATE_TESTREPWSDDServiceName;
    }

    public void setCREATE_TESTREPWSDDServiceName(java.lang.String name) {
        CREATE_TESTREPWSDDServiceName = name;
    }

    public com.knorr_bremse.sap_com.testReportUpload.CREATE_TESTREP getCREATE_TESTREP() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(CREATE_TESTREP_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCREATE_TESTREP(endpoint);
    }

    public com.knorr_bremse.sap_com.testReportUpload.CREATE_TESTREP getCREATE_TESTREP(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.knorr_bremse.sap_com.testReportUpload.CREATE_TESTREPStub _stub = new com.knorr_bremse.sap_com.testReportUpload.CREATE_TESTREPStub(portAddress, this);
            _stub.setPortName(getCREATE_TESTREPWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCREATE_TESTREPEndpointAddress(java.lang.String address) {
        CREATE_TESTREP_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.knorr_bremse.sap_com.testReportUpload.CREATE_TESTREP.class.isAssignableFrom(serviceEndpointInterface)) {
                com.knorr_bremse.sap_com.testReportUpload.CREATE_TESTREPStub _stub = new com.knorr_bremse.sap_com.testReportUpload.CREATE_TESTREPStub(new java.net.URL(CREATE_TESTREP_address), this);
                _stub.setPortName(getCREATE_TESTREPWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("CREATE_TESTREP".equals(inputPortName)) {
            return getCREATE_TESTREP();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("urn:sap-com:document:sap:soap:functions:mc-style", "ZZQ_WS_CREATE_TESTREP");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("urn:sap-com:document:sap:soap:functions:mc-style", "CREATE_TESTREP"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("CREATE_TESTREP".equals(portName)) {
            setCREATE_TESTREPEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
