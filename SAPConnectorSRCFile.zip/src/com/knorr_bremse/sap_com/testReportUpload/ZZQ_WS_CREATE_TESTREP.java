/**
 * ZZQ_WS_CREATE_TESTREP.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.testReportUpload;

public interface ZZQ_WS_CREATE_TESTREP extends javax.xml.rpc.Service {
    public java.lang.String getCREATE_TESTREPAddress();
    public void setHttpAddress(java.lang.String httpAddress);

    public com.knorr_bremse.sap_com.testReportUpload.CREATE_TESTREP getCREATE_TESTREP() throws javax.xml.rpc.ServiceException;

    public com.knorr_bremse.sap_com.testReportUpload.CREATE_TESTREP getCREATE_TESTREP(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
