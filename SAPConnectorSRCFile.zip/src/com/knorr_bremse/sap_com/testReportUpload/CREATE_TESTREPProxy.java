package com.knorr_bremse.sap_com.testReportUpload;

public class CREATE_TESTREPProxy implements com.knorr_bremse.sap_com.testReportUpload.CREATE_TESTREP {
  private String _endpoint = null;
  private com.knorr_bremse.sap_com.testReportUpload.CREATE_TESTREP cREATE_TESTREP = null;
  
  public CREATE_TESTREPProxy() {
    _initCREATE_TESTREPProxy();
  }
  
  public CREATE_TESTREPProxy(String endpoint) {
    _endpoint = endpoint;
    _initCREATE_TESTREPProxy();
  }
  
  private void _initCREATE_TESTREPProxy() {
    try {
      cREATE_TESTREP = (new com.knorr_bremse.sap_com.testReportUpload.ZZQ_WS_CREATE_TESTREPLocator()).getCREATE_TESTREP();
      if (cREATE_TESTREP != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)cREATE_TESTREP)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)cREATE_TESTREP)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (cREATE_TESTREP != null)
      ((javax.xml.rpc.Stub)cREATE_TESTREP)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.knorr_bremse.sap_com.testReportUpload.CREATE_TESTREP getCREATE_TESTREP() {
    if (cREATE_TESTREP == null)
      _initCREATE_TESTREPProxy();
    return cREATE_TESTREP;
  }
  
  public void zzqCreateTestrepFromWs(java.lang.String ICallId, java.lang.String IFlDms, java.lang.String IFlXecm, com.knorr_bremse.sap_com.testReportUpload.ZzqSImportTestrepDataWs isDocumentData, java.lang.String isDocumentString, com.knorr_bremse.sap_com.testReportUpload.holders.ZzqSExportTestrepDataWsHolder esDocumentData, com.knorr_bremse.sap_com.testReportUpload.holders.ZzqTReturnMessageHolder etReturn) throws java.rmi.RemoteException{
    if (cREATE_TESTREP == null)
      _initCREATE_TESTREPProxy();
    cREATE_TESTREP.zzqCreateTestrepFromWs(ICallId, IFlDms, IFlXecm, isDocumentData, isDocumentString, esDocumentData, etReturn);
  }
  
  
}