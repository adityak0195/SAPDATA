/**
 * ZzqSExportTestrepDataWs.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.testReportUpload;

public class ZzqSExportTestrepDataWs  implements java.io.Serializable {
    private java.lang.String dokar;

    private java.lang.String doknr;

    private java.lang.String dokvr;

    private java.lang.String doktl;

    private java.lang.String matnr;

    private java.lang.String sernr;

    private java.lang.String hsdat;

    private java.lang.String equnr;

    private java.lang.String prorder;

    private java.lang.String doctype;

    private java.lang.String docresult;

    public ZzqSExportTestrepDataWs() {
    }

    public ZzqSExportTestrepDataWs(
           java.lang.String dokar,
           java.lang.String doknr,
           java.lang.String dokvr,
           java.lang.String doktl,
           java.lang.String matnr,
           java.lang.String sernr,
           java.lang.String hsdat,
           java.lang.String equnr,
           java.lang.String prorder,
           java.lang.String doctype,
           java.lang.String docresult) {
           this.dokar = dokar;
           this.doknr = doknr;
           this.dokvr = dokvr;
           this.doktl = doktl;
           this.matnr = matnr;
           this.sernr = sernr;
           this.hsdat = hsdat;
           this.equnr = equnr;
           this.prorder = prorder;
           this.doctype = doctype;
           this.docresult = docresult;
    }


    /**
     * Gets the dokar value for this ZzqSExportTestrepDataWs.
     * 
     * @return dokar
     */
    public java.lang.String getDokar() {
        return dokar;
    }


    /**
     * Sets the dokar value for this ZzqSExportTestrepDataWs.
     * 
     * @param dokar
     */
    public void setDokar(java.lang.String dokar) {
        this.dokar = dokar;
    }


    /**
     * Gets the doknr value for this ZzqSExportTestrepDataWs.
     * 
     * @return doknr
     */
    public java.lang.String getDoknr() {
        return doknr;
    }


    /**
     * Sets the doknr value for this ZzqSExportTestrepDataWs.
     * 
     * @param doknr
     */
    public void setDoknr(java.lang.String doknr) {
        this.doknr = doknr;
    }


    /**
     * Gets the dokvr value for this ZzqSExportTestrepDataWs.
     * 
     * @return dokvr
     */
    public java.lang.String getDokvr() {
        return dokvr;
    }


    /**
     * Sets the dokvr value for this ZzqSExportTestrepDataWs.
     * 
     * @param dokvr
     */
    public void setDokvr(java.lang.String dokvr) {
        this.dokvr = dokvr;
    }


    /**
     * Gets the doktl value for this ZzqSExportTestrepDataWs.
     * 
     * @return doktl
     */
    public java.lang.String getDoktl() {
        return doktl;
    }


    /**
     * Sets the doktl value for this ZzqSExportTestrepDataWs.
     * 
     * @param doktl
     */
    public void setDoktl(java.lang.String doktl) {
        this.doktl = doktl;
    }


    /**
     * Gets the matnr value for this ZzqSExportTestrepDataWs.
     * 
     * @return matnr
     */
    public java.lang.String getMatnr() {
        return matnr;
    }


    /**
     * Sets the matnr value for this ZzqSExportTestrepDataWs.
     * 
     * @param matnr
     */
    public void setMatnr(java.lang.String matnr) {
        this.matnr = matnr;
    }


    /**
     * Gets the sernr value for this ZzqSExportTestrepDataWs.
     * 
     * @return sernr
     */
    public java.lang.String getSernr() {
        return sernr;
    }


    /**
     * Sets the sernr value for this ZzqSExportTestrepDataWs.
     * 
     * @param sernr
     */
    public void setSernr(java.lang.String sernr) {
        this.sernr = sernr;
    }


    /**
     * Gets the hsdat value for this ZzqSExportTestrepDataWs.
     * 
     * @return hsdat
     */
    public java.lang.String getHsdat() {
        return hsdat;
    }


    /**
     * Sets the hsdat value for this ZzqSExportTestrepDataWs.
     * 
     * @param hsdat
     */
    public void setHsdat(java.lang.String hsdat) {
        this.hsdat = hsdat;
    }


    /**
     * Gets the equnr value for this ZzqSExportTestrepDataWs.
     * 
     * @return equnr
     */
    public java.lang.String getEqunr() {
        return equnr;
    }


    /**
     * Sets the equnr value for this ZzqSExportTestrepDataWs.
     * 
     * @param equnr
     */
    public void setEqunr(java.lang.String equnr) {
        this.equnr = equnr;
    }


    /**
     * Gets the prorder value for this ZzqSExportTestrepDataWs.
     * 
     * @return prorder
     */
    public java.lang.String getProrder() {
        return prorder;
    }


    /**
     * Sets the prorder value for this ZzqSExportTestrepDataWs.
     * 
     * @param prorder
     */
    public void setProrder(java.lang.String prorder) {
        this.prorder = prorder;
    }


    /**
     * Gets the doctype value for this ZzqSExportTestrepDataWs.
     * 
     * @return doctype
     */
    public java.lang.String getDoctype() {
        return doctype;
    }


    /**
     * Sets the doctype value for this ZzqSExportTestrepDataWs.
     * 
     * @param doctype
     */
    public void setDoctype(java.lang.String doctype) {
        this.doctype = doctype;
    }


    /**
     * Gets the docresult value for this ZzqSExportTestrepDataWs.
     * 
     * @return docresult
     */
    public java.lang.String getDocresult() {
        return docresult;
    }


    /**
     * Sets the docresult value for this ZzqSExportTestrepDataWs.
     * 
     * @param docresult
     */
    public void setDocresult(java.lang.String docresult) {
        this.docresult = docresult;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ZzqSExportTestrepDataWs)) return false;
        ZzqSExportTestrepDataWs other = (ZzqSExportTestrepDataWs) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.dokar==null && other.getDokar()==null) || 
             (this.dokar!=null &&
              this.dokar.equals(other.getDokar()))) &&
            ((this.doknr==null && other.getDoknr()==null) || 
             (this.doknr!=null &&
              this.doknr.equals(other.getDoknr()))) &&
            ((this.dokvr==null && other.getDokvr()==null) || 
             (this.dokvr!=null &&
              this.dokvr.equals(other.getDokvr()))) &&
            ((this.doktl==null && other.getDoktl()==null) || 
             (this.doktl!=null &&
              this.doktl.equals(other.getDoktl()))) &&
            ((this.matnr==null && other.getMatnr()==null) || 
             (this.matnr!=null &&
              this.matnr.equals(other.getMatnr()))) &&
            ((this.sernr==null && other.getSernr()==null) || 
             (this.sernr!=null &&
              this.sernr.equals(other.getSernr()))) &&
            ((this.hsdat==null && other.getHsdat()==null) || 
             (this.hsdat!=null &&
              this.hsdat.equals(other.getHsdat()))) &&
            ((this.equnr==null && other.getEqunr()==null) || 
             (this.equnr!=null &&
              this.equnr.equals(other.getEqunr()))) &&
            ((this.prorder==null && other.getProrder()==null) || 
             (this.prorder!=null &&
              this.prorder.equals(other.getProrder()))) &&
            ((this.doctype==null && other.getDoctype()==null) || 
             (this.doctype!=null &&
              this.doctype.equals(other.getDoctype()))) &&
            ((this.docresult==null && other.getDocresult()==null) || 
             (this.docresult!=null &&
              this.docresult.equals(other.getDocresult())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDokar() != null) {
            _hashCode += getDokar().hashCode();
        }
        if (getDoknr() != null) {
            _hashCode += getDoknr().hashCode();
        }
        if (getDokvr() != null) {
            _hashCode += getDokvr().hashCode();
        }
        if (getDoktl() != null) {
            _hashCode += getDoktl().hashCode();
        }
        if (getMatnr() != null) {
            _hashCode += getMatnr().hashCode();
        }
        if (getSernr() != null) {
            _hashCode += getSernr().hashCode();
        }
        if (getHsdat() != null) {
            _hashCode += getHsdat().hashCode();
        }
        if (getEqunr() != null) {
            _hashCode += getEqunr().hashCode();
        }
        if (getProrder() != null) {
            _hashCode += getProrder().hashCode();
        }
        if (getDoctype() != null) {
            _hashCode += getDoctype().hashCode();
        }
        if (getDocresult() != null) {
            _hashCode += getDocresult().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ZzqSExportTestrepDataWs.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:soap:functions:mc-style", "ZzqSExportTestrepDataWs"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dokar");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Dokar"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("doknr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Doknr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dokvr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Dokvr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("doktl");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Doktl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("matnr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Matnr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sernr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Sernr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hsdat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Hsdat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("equnr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Equnr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("prorder");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Prorder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("doctype");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Doctype"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("docresult");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Docresult"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
