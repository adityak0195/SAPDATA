/**
 * CREATE_TESTREP.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.testReportUpload;

public interface CREATE_TESTREP extends java.rmi.Remote {
    public void zzqCreateTestrepFromWs(java.lang.String ICallId, java.lang.String IFlDms, java.lang.String IFlXecm, com.knorr_bremse.sap_com.testReportUpload.ZzqSImportTestrepDataWs isDocumentData, java.lang.String isDocumentString, com.knorr_bremse.sap_com.testReportUpload.holders.ZzqSExportTestrepDataWsHolder esDocumentData, com.knorr_bremse.sap_com.testReportUpload.holders.ZzqTReturnMessageHolder etReturn) throws java.rmi.RemoteException;
}
