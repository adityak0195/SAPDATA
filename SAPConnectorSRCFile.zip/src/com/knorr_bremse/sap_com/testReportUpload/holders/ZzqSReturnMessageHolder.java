/**
 * ZzqSReturnMessageHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.testReportUpload.holders;

public final class ZzqSReturnMessageHolder implements javax.xml.rpc.holders.Holder {
    public com.knorr_bremse.sap_com.testReportUpload.ZzqSReturnMessage value;

    public ZzqSReturnMessageHolder() {
    }

    public ZzqSReturnMessageHolder(com.knorr_bremse.sap_com.testReportUpload.ZzqSReturnMessage value) {
        this.value = value;
    }

}
