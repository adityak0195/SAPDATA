/**
 * ZzqSImportTestrepDataWs.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.testReportUpload;

public class ZzqSImportTestrepDataWs  implements java.io.Serializable {
    private java.lang.String matnr;

    private java.lang.String sernr;

    private java.lang.String hsdat;

    private java.lang.String prorder;

    private java.lang.String doctype;

    private java.lang.String docresult;

    public ZzqSImportTestrepDataWs() {
    }

    public ZzqSImportTestrepDataWs(
           java.lang.String matnr,
           java.lang.String sernr,
           java.lang.String hsdat,
           java.lang.String prorder,
           java.lang.String doctype,
           java.lang.String docresult) {
           this.matnr = matnr;
           this.sernr = sernr;
           this.hsdat = hsdat;
           this.prorder = prorder;
           this.doctype = doctype;
           this.docresult = docresult;
    }


    /**
     * Gets the matnr value for this ZzqSImportTestrepDataWs.
     * 
     * @return matnr
     */
    public java.lang.String getMatnr() {
        return matnr;
    }


    /**
     * Sets the matnr value for this ZzqSImportTestrepDataWs.
     * 
     * @param matnr
     */
    public void setMatnr(java.lang.String matnr) {
        this.matnr = matnr;
    }


    /**
     * Gets the sernr value for this ZzqSImportTestrepDataWs.
     * 
     * @return sernr
     */
    public java.lang.String getSernr() {
        return sernr;
    }


    /**
     * Sets the sernr value for this ZzqSImportTestrepDataWs.
     * 
     * @param sernr
     */
    public void setSernr(java.lang.String sernr) {
        this.sernr = sernr;
    }


    /**
     * Gets the hsdat value for this ZzqSImportTestrepDataWs.
     * 
     * @return hsdat
     */
    public java.lang.String getHsdat() {
        return hsdat;
    }


    /**
     * Sets the hsdat value for this ZzqSImportTestrepDataWs.
     * 
     * @param hsdat
     */
    public void setHsdat(java.lang.String hsdat) {
        this.hsdat = hsdat;
    }


    /**
     * Gets the prorder value for this ZzqSImportTestrepDataWs.
     * 
     * @return prorder
     */
    public java.lang.String getProrder() {
        return prorder;
    }


    /**
     * Sets the prorder value for this ZzqSImportTestrepDataWs.
     * 
     * @param prorder
     */
    public void setProrder(java.lang.String prorder) {
        this.prorder = prorder;
    }


    /**
     * Gets the doctype value for this ZzqSImportTestrepDataWs.
     * 
     * @return doctype
     */
    public java.lang.String getDoctype() {
        return doctype;
    }


    /**
     * Sets the doctype value for this ZzqSImportTestrepDataWs.
     * 
     * @param doctype
     */
    public void setDoctype(java.lang.String doctype) {
        this.doctype = doctype;
    }


    /**
     * Gets the docresult value for this ZzqSImportTestrepDataWs.
     * 
     * @return docresult
     */
    public java.lang.String getDocresult() {
        return docresult;
    }


    /**
     * Sets the docresult value for this ZzqSImportTestrepDataWs.
     * 
     * @param docresult
     */
    public void setDocresult(java.lang.String docresult) {
        this.docresult = docresult;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ZzqSImportTestrepDataWs)) return false;
        ZzqSImportTestrepDataWs other = (ZzqSImportTestrepDataWs) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.matnr==null && other.getMatnr()==null) || 
             (this.matnr!=null &&
              this.matnr.equals(other.getMatnr()))) &&
            ((this.sernr==null && other.getSernr()==null) || 
             (this.sernr!=null &&
              this.sernr.equals(other.getSernr()))) &&
            ((this.hsdat==null && other.getHsdat()==null) || 
             (this.hsdat!=null &&
              this.hsdat.equals(other.getHsdat()))) &&
            ((this.prorder==null && other.getProrder()==null) || 
             (this.prorder!=null &&
              this.prorder.equals(other.getProrder()))) &&
            ((this.doctype==null && other.getDoctype()==null) || 
             (this.doctype!=null &&
              this.doctype.equals(other.getDoctype()))) &&
            ((this.docresult==null && other.getDocresult()==null) || 
             (this.docresult!=null &&
              this.docresult.equals(other.getDocresult())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMatnr() != null) {
            _hashCode += getMatnr().hashCode();
        }
        if (getSernr() != null) {
            _hashCode += getSernr().hashCode();
        }
        if (getHsdat() != null) {
            _hashCode += getHsdat().hashCode();
        }
        if (getProrder() != null) {
            _hashCode += getProrder().hashCode();
        }
        if (getDoctype() != null) {
            _hashCode += getDoctype().hashCode();
        }
        if (getDocresult() != null) {
            _hashCode += getDocresult().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ZzqSImportTestrepDataWs.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:soap:functions:mc-style", "ZzqSImportTestrepDataWs"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("matnr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Matnr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sernr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Sernr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hsdat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Hsdat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("prorder");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Prorder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("doctype");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Doctype"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("docresult");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Docresult"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
