/**
 * Ws_get_workcenter_capaLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.plannedCapa;

public class Ws_get_workcenter_capaLocator extends org.apache.axis.client.Service implements com.knorr_bremse.sap_com.plannedCapa.Ws_get_workcenter_capa {

    public Ws_get_workcenter_capaLocator() {
    }


    public Ws_get_workcenter_capaLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public Ws_get_workcenter_capaLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    public void setHttpsAddress(java.lang.String address) {
    	ws_get_workcenter_capa_address = address;
    }
    
    // Use to get a proxy class for ws_get_workcenter_capa
    private java.lang.String ws_get_workcenter_capa_address = "";

    public java.lang.String getws_get_workcenter_capaAddress() {
        return ws_get_workcenter_capa_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String ws_get_workcenter_capaWSDDServiceName = "ws_get_workcenter_capa";

    public java.lang.String getws_get_workcenter_capaWSDDServiceName() {
        return ws_get_workcenter_capaWSDDServiceName;
    }

    public void setws_get_workcenter_capaWSDDServiceName(java.lang.String name) {
        ws_get_workcenter_capaWSDDServiceName = name;
    }

    public com.knorr_bremse.sap_com.plannedCapa.Zzp_ws_get_workcenter_capa getws_get_workcenter_capa() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(ws_get_workcenter_capa_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getws_get_workcenter_capa(endpoint);
    }

    public com.knorr_bremse.sap_com.plannedCapa.Zzp_ws_get_workcenter_capa getws_get_workcenter_capa(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
        	com.knorr_bremse.sap_com.plannedCapa.Ws_get_workcenter_capaStub _stub = new com.knorr_bremse.sap_com.plannedCapa.Ws_get_workcenter_capaStub(portAddress, this);
            _stub.setPortName(getws_get_workcenter_capaWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setws_get_workcenter_capaEndpointAddress(java.lang.String address) {
        ws_get_workcenter_capa_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.knorr_bremse.sap_com.plannedCapa.Zzp_ws_get_workcenter_capa.class.isAssignableFrom(serviceEndpointInterface)) {
            	com.knorr_bremse.sap_com.plannedCapa.Ws_get_workcenter_capaStub _stub = new com.knorr_bremse.sap_com.plannedCapa.Ws_get_workcenter_capaStub(new java.net.URL(ws_get_workcenter_capa_address), this);
                _stub.setPortName(getws_get_workcenter_capaWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("ws_get_workcenter_capa".equals(inputPortName)) {
            return getws_get_workcenter_capa();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("urn:sap-com:document:sap:soap:functions:mc-style", "ws_get_workcenter_capa");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("urn:sap-com:document:sap:soap:functions:mc-style", "ws_get_workcenter_capa"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("ws_get_workcenter_capa".equals(portName)) {
            setws_get_workcenter_capaEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
