/**
 * ZzpTR3ResShiftHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.plannedCapa.holders;

public final class ZzpTR3ResShiftHolder implements javax.xml.rpc.holders.Holder {
    public com.knorr_bremse.sap_com.plannedCapa.ZzpR3ResShift[] value;

    public ZzpTR3ResShiftHolder() {
    }

    public ZzpTR3ResShiftHolder(com.knorr_bremse.sap_com.plannedCapa.ZzpR3ResShift[] value) {
        this.value = value;
    }

}
