/**
 * ZzpTBapireturn1Holder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.plannedCapa.holders;

public final class ZzpTBapireturn1Holder implements javax.xml.rpc.holders.Holder {
    public com.knorr_bremse.sap_com.plannedCapa.Bapireturn1[] value;

    public ZzpTBapireturn1Holder() {
    }

    public ZzpTBapireturn1Holder(com.knorr_bremse.sap_com.plannedCapa.Bapireturn1[] value) {
        this.value = value;
    }

}
