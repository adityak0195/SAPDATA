/**
 * Zzp_ws_get_workcenter_capa.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.plannedCapa;

public interface Zzp_ws_get_workcenter_capa extends java.rmi.Remote {
    public void zzpGetWorkcenterCapa(java.lang.String IDatub, java.lang.String IDatuv, java.lang.String IWerks, com.knorr_bremse.sap_com.plannedCapa.holders.ZzpTR3ResShiftHolder etR3ResShift, com.knorr_bremse.sap_com.plannedCapa.holders.ZzpTBapireturn1Holder etReturn) throws java.rmi.RemoteException;
}
