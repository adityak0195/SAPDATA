package com.knorr_bremse.sap_com.plannedCapa;

public class Zzp_ws_get_workcenter_capaProxy implements com.knorr_bremse.sap_com.plannedCapa.Zzp_ws_get_workcenter_capa {
  private String _endpoint = null;
  private com.knorr_bremse.sap_com.plannedCapa.Zzp_ws_get_workcenter_capa zzp_ws_get_workcenter_capa = null;
  
  public Zzp_ws_get_workcenter_capaProxy() {
    _initZzp_ws_get_workcenter_capaProxy();
  }
  
  public Zzp_ws_get_workcenter_capaProxy(String endpoint) {
    _endpoint = endpoint;
    _initZzp_ws_get_workcenter_capaProxy();
  }
  
  private void _initZzp_ws_get_workcenter_capaProxy() {
    try {
      zzp_ws_get_workcenter_capa = (new com.knorr_bremse.sap_com.plannedCapa.Ws_get_workcenter_capaLocator()).getws_get_workcenter_capa();
      if (zzp_ws_get_workcenter_capa != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)zzp_ws_get_workcenter_capa)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)zzp_ws_get_workcenter_capa)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (zzp_ws_get_workcenter_capa != null)
      ((javax.xml.rpc.Stub)zzp_ws_get_workcenter_capa)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.knorr_bremse.sap_com.plannedCapa.Zzp_ws_get_workcenter_capa getZzp_ws_get_workcenter_capa() {
    if (zzp_ws_get_workcenter_capa == null)
      _initZzp_ws_get_workcenter_capaProxy();
    return zzp_ws_get_workcenter_capa;
  }
  
  public void zzpGetWorkcenterCapa(java.lang.String IDatub, java.lang.String IDatuv, java.lang.String IWerks, com.knorr_bremse.sap_com.plannedCapa.holders.ZzpTR3ResShiftHolder etR3ResShift, com.knorr_bremse.sap_com.plannedCapa.holders.ZzpTBapireturn1Holder etReturn) throws java.rmi.RemoteException{
    if (zzp_ws_get_workcenter_capa == null)
      _initZzp_ws_get_workcenter_capaProxy();
    zzp_ws_get_workcenter_capa.zzpGetWorkcenterCapa(IDatub, IDatuv, IWerks, etR3ResShift, etReturn);
  }
  
  
}