/**
 * ZzpR3ResShift.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.plannedCapa;

public class ZzpR3ResShift  implements java.io.Serializable {
    private java.lang.String mandt;

    private java.lang.String werks;

    private java.lang.String arbpl;

    private java.lang.String startDate;

    private org.apache.axis.types.Time startTime;

    private org.apache.axis.types.Time endTime;

    private java.lang.String qualifier;

    private int einzt;

    private java.lang.String ngrad;

    private java.lang.String schnr;

    private short anzhl;

    public ZzpR3ResShift() {
    }

    public ZzpR3ResShift(
           java.lang.String mandt,
           java.lang.String werks,
           java.lang.String arbpl,
           java.lang.String startDate,
           org.apache.axis.types.Time startTime,
           org.apache.axis.types.Time endTime,
           java.lang.String qualifier,
           int einzt,
           java.lang.String ngrad,
           java.lang.String schnr,
           short anzhl) {
           this.mandt = mandt;
           this.werks = werks;
           this.arbpl = arbpl;
           this.startDate = startDate;
           this.startTime = startTime;
           this.endTime = endTime;
           this.qualifier = qualifier;
           this.einzt = einzt;
           this.ngrad = ngrad;
           this.schnr = schnr;
           this.anzhl = anzhl;
    }


    /**
     * Gets the mandt value for this ZzpR3ResShift.
     * 
     * @return mandt
     */
    public java.lang.String getMandt() {
        return mandt;
    }


    /**
     * Sets the mandt value for this ZzpR3ResShift.
     * 
     * @param mandt
     */
    public void setMandt(java.lang.String mandt) {
        this.mandt = mandt;
    }


    /**
     * Gets the werks value for this ZzpR3ResShift.
     * 
     * @return werks
     */
    public java.lang.String getWerks() {
        return werks;
    }


    /**
     * Sets the werks value for this ZzpR3ResShift.
     * 
     * @param werks
     */
    public void setWerks(java.lang.String werks) {
        this.werks = werks;
    }


    /**
     * Gets the arbpl value for this ZzpR3ResShift.
     * 
     * @return arbpl
     */
    public java.lang.String getArbpl() {
        return arbpl;
    }


    /**
     * Sets the arbpl value for this ZzpR3ResShift.
     * 
     * @param arbpl
     */
    public void setArbpl(java.lang.String arbpl) {
        this.arbpl = arbpl;
    }


    /**
     * Gets the startDate value for this ZzpR3ResShift.
     * 
     * @return startDate
     */
    public java.lang.String getStartDate() {
        return startDate;
    }


    /**
     * Sets the startDate value for this ZzpR3ResShift.
     * 
     * @param startDate
     */
    public void setStartDate(java.lang.String startDate) {
        this.startDate = startDate;
    }


    /**
     * Gets the startTime value for this ZzpR3ResShift.
     * 
     * @return startTime
     */
    public org.apache.axis.types.Time getStartTime() {
        return startTime;
    }


    /**
     * Sets the startTime value for this ZzpR3ResShift.
     * 
     * @param startTime
     */
    public void setStartTime(org.apache.axis.types.Time startTime) {
        this.startTime = startTime;
    }


    /**
     * Gets the endTime value for this ZzpR3ResShift.
     * 
     * @return endTime
     */
    public org.apache.axis.types.Time getEndTime() {
        return endTime;
    }


    /**
     * Sets the endTime value for this ZzpR3ResShift.
     * 
     * @param endTime
     */
    public void setEndTime(org.apache.axis.types.Time endTime) {
        this.endTime = endTime;
    }


    /**
     * Gets the qualifier value for this ZzpR3ResShift.
     * 
     * @return qualifier
     */
    public java.lang.String getQualifier() {
        return qualifier;
    }


    /**
     * Sets the qualifier value for this ZzpR3ResShift.
     * 
     * @param qualifier
     */
    public void setQualifier(java.lang.String qualifier) {
        this.qualifier = qualifier;
    }


    /**
     * Gets the einzt value for this ZzpR3ResShift.
     * 
     * @return einzt
     */
    public int getEinzt() {
        return einzt;
    }


    /**
     * Sets the einzt value for this ZzpR3ResShift.
     * 
     * @param einzt
     */
    public void setEinzt(int einzt) {
        this.einzt = einzt;
    }


    /**
     * Gets the ngrad value for this ZzpR3ResShift.
     * 
     * @return ngrad
     */
    public java.lang.String getNgrad() {
        return ngrad;
    }


    /**
     * Sets the ngrad value for this ZzpR3ResShift.
     * 
     * @param ngrad
     */
    public void setNgrad(java.lang.String ngrad) {
        this.ngrad = ngrad;
    }


    /**
     * Gets the schnr value for this ZzpR3ResShift.
     * 
     * @return schnr
     */
    public java.lang.String getSchnr() {
        return schnr;
    }


    /**
     * Sets the schnr value for this ZzpR3ResShift.
     * 
     * @param schnr
     */
    public void setSchnr(java.lang.String schnr) {
        this.schnr = schnr;
    }


    /**
     * Gets the anzhl value for this ZzpR3ResShift.
     * 
     * @return anzhl
     */
    public short getAnzhl() {
        return anzhl;
    }


    /**
     * Sets the anzhl value for this ZzpR3ResShift.
     * 
     * @param anzhl
     */
    public void setAnzhl(short anzhl) {
        this.anzhl = anzhl;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ZzpR3ResShift)) return false;
        ZzpR3ResShift other = (ZzpR3ResShift) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.mandt==null && other.getMandt()==null) || 
             (this.mandt!=null &&
              this.mandt.equals(other.getMandt()))) &&
            ((this.werks==null && other.getWerks()==null) || 
             (this.werks!=null &&
              this.werks.equals(other.getWerks()))) &&
            ((this.arbpl==null && other.getArbpl()==null) || 
             (this.arbpl!=null &&
              this.arbpl.equals(other.getArbpl()))) &&
            ((this.startDate==null && other.getStartDate()==null) || 
             (this.startDate!=null &&
              this.startDate.equals(other.getStartDate()))) &&
            ((this.startTime==null && other.getStartTime()==null) || 
             (this.startTime!=null &&
              this.startTime.equals(other.getStartTime()))) &&
            ((this.endTime==null && other.getEndTime()==null) || 
             (this.endTime!=null &&
              this.endTime.equals(other.getEndTime()))) &&
            ((this.qualifier==null && other.getQualifier()==null) || 
             (this.qualifier!=null &&
              this.qualifier.equals(other.getQualifier()))) &&
            this.einzt == other.getEinzt() &&
            ((this.ngrad==null && other.getNgrad()==null) || 
             (this.ngrad!=null &&
              this.ngrad.equals(other.getNgrad()))) &&
            ((this.schnr==null && other.getSchnr()==null) || 
             (this.schnr!=null &&
              this.schnr.equals(other.getSchnr()))) &&
            this.anzhl == other.getAnzhl();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMandt() != null) {
            _hashCode += getMandt().hashCode();
        }
        if (getWerks() != null) {
            _hashCode += getWerks().hashCode();
        }
        if (getArbpl() != null) {
            _hashCode += getArbpl().hashCode();
        }
        if (getStartDate() != null) {
            _hashCode += getStartDate().hashCode();
        }
        if (getStartTime() != null) {
            _hashCode += getStartTime().hashCode();
        }
        if (getEndTime() != null) {
            _hashCode += getEndTime().hashCode();
        }
        if (getQualifier() != null) {
            _hashCode += getQualifier().hashCode();
        }
        _hashCode += getEinzt();
        if (getNgrad() != null) {
            _hashCode += getNgrad().hashCode();
        }
        if (getSchnr() != null) {
            _hashCode += getSchnr().hashCode();
        }
        _hashCode += getAnzhl();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ZzpR3ResShift.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:soap:functions:mc-style", "ZzpR3ResShift"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mandt");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Mandt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("werks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Werks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arbpl");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Arbpl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "StartDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "StartTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "time"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("endTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "EndTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "time"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("qualifier");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Qualifier"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("einzt");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Einzt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ngrad");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Ngrad"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("schnr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Schnr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anzhl");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Anzhl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "short"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
