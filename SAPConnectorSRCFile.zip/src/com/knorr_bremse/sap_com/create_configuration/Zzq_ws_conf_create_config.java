/**
 * Zzq_ws_conf_create_config.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.create_configuration;

public interface Zzq_ws_conf_create_config extends java.rmi.Remote {
    public void zzqConfigCreateConfig(java.lang.String ICallId, com.knorr_bremse.sap_com.create_configuration.ZzqSIbaseDataFile[] itConfig, javax.xml.rpc.holders.StringHolder EFlCancel, javax.xml.rpc.holders.StringHolder EFlRework, com.knorr_bremse.sap_com.create_configuration.holders.ZzqTIbaseDataFileHolder etConfig, com.knorr_bremse.sap_com.create_configuration.holders.ZzqTConfigReturnMessageHolder etReturn) throws java.rmi.RemoteException;
}
