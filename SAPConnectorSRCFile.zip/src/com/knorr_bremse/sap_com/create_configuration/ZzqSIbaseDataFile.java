/**
 * ZzqSIbaseDataFile.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.create_configuration;

public class ZzqSIbaseDataFile  implements java.io.Serializable {
    private java.lang.String head;

    private java.lang.String komat;

    private java.lang.String koser;

    private java.lang.String posmat;

    private java.lang.String poser;

    private java.lang.String batch;

    private java.lang.String kweek;

    private java.lang.String kyear;

    private java.lang.String zzhsdat;

    private java.lang.String zzwerks;

    private java.lang.String zzaeind;

    private java.lang.String zzmodifStat;

    private java.lang.String zzmountedBy;

    private java.lang.String zzapprovedBy;

    private java.lang.String zzcertifiedBy;

    private java.lang.String notice;

    private java.lang.String aufnr;

    private java.lang.String flError;

    private java.lang.String missingItems;

    public ZzqSIbaseDataFile() {
    }

    public ZzqSIbaseDataFile(
           java.lang.String head,
           java.lang.String komat,
           java.lang.String koser,
           java.lang.String posmat,
           java.lang.String poser,
           java.lang.String batch,
           java.lang.String kweek,
           java.lang.String kyear,
           java.lang.String zzhsdat,
           java.lang.String zzwerks,
           java.lang.String zzaeind,
           java.lang.String zzmodifStat,
           java.lang.String zzmountedBy,
           java.lang.String zzapprovedBy,
           java.lang.String zzcertifiedBy,
           java.lang.String notice,
           java.lang.String aufnr,
           java.lang.String flError,
           java.lang.String missingItems) {
           this.head = head;
           this.komat = komat;
           this.koser = koser;
           this.posmat = posmat;
           this.poser = poser;
           this.batch = batch;
           this.kweek = kweek;
           this.kyear = kyear;
           this.zzhsdat = zzhsdat;
           this.zzwerks = zzwerks;
           this.zzaeind = zzaeind;
           this.zzmodifStat = zzmodifStat;
           this.zzmountedBy = zzmountedBy;
           this.zzapprovedBy = zzapprovedBy;
           this.zzcertifiedBy = zzcertifiedBy;
           this.notice = notice;
           this.aufnr = aufnr;
           this.flError = flError;
           this.missingItems = missingItems;
    }


    /**
     * Gets the head value for this ZzqSIbaseDataFile.
     * 
     * @return head
     */
    public java.lang.String getHead() {
        return head;
    }


    /**
     * Sets the head value for this ZzqSIbaseDataFile.
     * 
     * @param head
     */
    public void setHead(java.lang.String head) {
        this.head = head;
    }


    /**
     * Gets the komat value for this ZzqSIbaseDataFile.
     * 
     * @return komat
     */
    public java.lang.String getKomat() {
        return komat;
    }


    /**
     * Sets the komat value for this ZzqSIbaseDataFile.
     * 
     * @param komat
     */
    public void setKomat(java.lang.String komat) {
        this.komat = komat;
    }


    /**
     * Gets the koser value for this ZzqSIbaseDataFile.
     * 
     * @return koser
     */
    public java.lang.String getKoser() {
        return koser;
    }


    /**
     * Sets the koser value for this ZzqSIbaseDataFile.
     * 
     * @param koser
     */
    public void setKoser(java.lang.String koser) {
        this.koser = koser;
    }


    /**
     * Gets the posmat value for this ZzqSIbaseDataFile.
     * 
     * @return posmat
     */
    public java.lang.String getPosmat() {
        return posmat;
    }


    /**
     * Sets the posmat value for this ZzqSIbaseDataFile.
     * 
     * @param posmat
     */
    public void setPosmat(java.lang.String posmat) {
        this.posmat = posmat;
    }


    /**
     * Gets the poser value for this ZzqSIbaseDataFile.
     * 
     * @return poser
     */
    public java.lang.String getPoser() {
        return poser;
    }


    /**
     * Sets the poser value for this ZzqSIbaseDataFile.
     * 
     * @param poser
     */
    public void setPoser(java.lang.String poser) {
        this.poser = poser;
    }


    /**
     * Gets the batch value for this ZzqSIbaseDataFile.
     * 
     * @return batch
     */
    public java.lang.String getBatch() {
        return batch;
    }


    /**
     * Sets the batch value for this ZzqSIbaseDataFile.
     * 
     * @param batch
     */
    public void setBatch(java.lang.String batch) {
        this.batch = batch;
    }


    /**
     * Gets the kweek value for this ZzqSIbaseDataFile.
     * 
     * @return kweek
     */
    public java.lang.String getKweek() {
        return kweek;
    }


    /**
     * Sets the kweek value for this ZzqSIbaseDataFile.
     * 
     * @param kweek
     */
    public void setKweek(java.lang.String kweek) {
        this.kweek = kweek;
    }


    /**
     * Gets the kyear value for this ZzqSIbaseDataFile.
     * 
     * @return kyear
     */
    public java.lang.String getKyear() {
        return kyear;
    }


    /**
     * Sets the kyear value for this ZzqSIbaseDataFile.
     * 
     * @param kyear
     */
    public void setKyear(java.lang.String kyear) {
        this.kyear = kyear;
    }


    /**
     * Gets the zzhsdat value for this ZzqSIbaseDataFile.
     * 
     * @return zzhsdat
     */
    public java.lang.String getZzhsdat() {
        return zzhsdat;
    }


    /**
     * Sets the zzhsdat value for this ZzqSIbaseDataFile.
     * 
     * @param zzhsdat
     */
    public void setZzhsdat(java.lang.String zzhsdat) {
        this.zzhsdat = zzhsdat;
    }


    /**
     * Gets the zzwerks value for this ZzqSIbaseDataFile.
     * 
     * @return zzwerks
     */
    public java.lang.String getZzwerks() {
        return zzwerks;
    }


    /**
     * Sets the zzwerks value for this ZzqSIbaseDataFile.
     * 
     * @param zzwerks
     */
    public void setZzwerks(java.lang.String zzwerks) {
        this.zzwerks = zzwerks;
    }


    /**
     * Gets the zzaeind value for this ZzqSIbaseDataFile.
     * 
     * @return zzaeind
     */
    public java.lang.String getZzaeind() {
        return zzaeind;
    }


    /**
     * Sets the zzaeind value for this ZzqSIbaseDataFile.
     * 
     * @param zzaeind
     */
    public void setZzaeind(java.lang.String zzaeind) {
        this.zzaeind = zzaeind;
    }


    /**
     * Gets the zzmodifStat value for this ZzqSIbaseDataFile.
     * 
     * @return zzmodifStat
     */
    public java.lang.String getZzmodifStat() {
        return zzmodifStat;
    }


    /**
     * Sets the zzmodifStat value for this ZzqSIbaseDataFile.
     * 
     * @param zzmodifStat
     */
    public void setZzmodifStat(java.lang.String zzmodifStat) {
        this.zzmodifStat = zzmodifStat;
    }


    /**
     * Gets the zzmountedBy value for this ZzqSIbaseDataFile.
     * 
     * @return zzmountedBy
     */
    public java.lang.String getZzmountedBy() {
        return zzmountedBy;
    }


    /**
     * Sets the zzmountedBy value for this ZzqSIbaseDataFile.
     * 
     * @param zzmountedBy
     */
    public void setZzmountedBy(java.lang.String zzmountedBy) {
        this.zzmountedBy = zzmountedBy;
    }


    /**
     * Gets the zzapprovedBy value for this ZzqSIbaseDataFile.
     * 
     * @return zzapprovedBy
     */
    public java.lang.String getZzapprovedBy() {
        return zzapprovedBy;
    }


    /**
     * Sets the zzapprovedBy value for this ZzqSIbaseDataFile.
     * 
     * @param zzapprovedBy
     */
    public void setZzapprovedBy(java.lang.String zzapprovedBy) {
        this.zzapprovedBy = zzapprovedBy;
    }


    /**
     * Gets the zzcertifiedBy value for this ZzqSIbaseDataFile.
     * 
     * @return zzcertifiedBy
     */
    public java.lang.String getZzcertifiedBy() {
        return zzcertifiedBy;
    }


    /**
     * Sets the zzcertifiedBy value for this ZzqSIbaseDataFile.
     * 
     * @param zzcertifiedBy
     */
    public void setZzcertifiedBy(java.lang.String zzcertifiedBy) {
        this.zzcertifiedBy = zzcertifiedBy;
    }


    /**
     * Gets the notice value for this ZzqSIbaseDataFile.
     * 
     * @return notice
     */
    public java.lang.String getNotice() {
        return notice;
    }


    /**
     * Sets the notice value for this ZzqSIbaseDataFile.
     * 
     * @param notice
     */
    public void setNotice(java.lang.String notice) {
        this.notice = notice;
    }


    /**
     * Gets the aufnr value for this ZzqSIbaseDataFile.
     * 
     * @return aufnr
     */
    public java.lang.String getAufnr() {
        return aufnr;
    }


    /**
     * Sets the aufnr value for this ZzqSIbaseDataFile.
     * 
     * @param aufnr
     */
    public void setAufnr(java.lang.String aufnr) {
        this.aufnr = aufnr;
    }


    /**
     * Gets the flError value for this ZzqSIbaseDataFile.
     * 
     * @return flError
     */
    public java.lang.String getFlError() {
        return flError;
    }


    /**
     * Sets the flError value for this ZzqSIbaseDataFile.
     * 
     * @param flError
     */
    public void setFlError(java.lang.String flError) {
        this.flError = flError;
    }


    /**
     * Gets the missingItems value for this ZzqSIbaseDataFile.
     * 
     * @return missingItems
     */
    public java.lang.String getMissingItems() {
        return missingItems;
    }


    /**
     * Sets the missingItems value for this ZzqSIbaseDataFile.
     * 
     * @param missingItems
     */
    public void setMissingItems(java.lang.String missingItems) {
        this.missingItems = missingItems;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ZzqSIbaseDataFile)) return false;
        ZzqSIbaseDataFile other = (ZzqSIbaseDataFile) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.head==null && other.getHead()==null) || 
             (this.head!=null &&
              this.head.equals(other.getHead()))) &&
            ((this.komat==null && other.getKomat()==null) || 
             (this.komat!=null &&
              this.komat.equals(other.getKomat()))) &&
            ((this.koser==null && other.getKoser()==null) || 
             (this.koser!=null &&
              this.koser.equals(other.getKoser()))) &&
            ((this.posmat==null && other.getPosmat()==null) || 
             (this.posmat!=null &&
              this.posmat.equals(other.getPosmat()))) &&
            ((this.poser==null && other.getPoser()==null) || 
             (this.poser!=null &&
              this.poser.equals(other.getPoser()))) &&
            ((this.batch==null && other.getBatch()==null) || 
             (this.batch!=null &&
              this.batch.equals(other.getBatch()))) &&
            ((this.kweek==null && other.getKweek()==null) || 
             (this.kweek!=null &&
              this.kweek.equals(other.getKweek()))) &&
            ((this.kyear==null && other.getKyear()==null) || 
             (this.kyear!=null &&
              this.kyear.equals(other.getKyear()))) &&
            ((this.zzhsdat==null && other.getZzhsdat()==null) || 
             (this.zzhsdat!=null &&
              this.zzhsdat.equals(other.getZzhsdat()))) &&
            ((this.zzwerks==null && other.getZzwerks()==null) || 
             (this.zzwerks!=null &&
              this.zzwerks.equals(other.getZzwerks()))) &&
            ((this.zzaeind==null && other.getZzaeind()==null) || 
             (this.zzaeind!=null &&
              this.zzaeind.equals(other.getZzaeind()))) &&
            ((this.zzmodifStat==null && other.getZzmodifStat()==null) || 
             (this.zzmodifStat!=null &&
              this.zzmodifStat.equals(other.getZzmodifStat()))) &&
            ((this.zzmountedBy==null && other.getZzmountedBy()==null) || 
             (this.zzmountedBy!=null &&
              this.zzmountedBy.equals(other.getZzmountedBy()))) &&
            ((this.zzapprovedBy==null && other.getZzapprovedBy()==null) || 
             (this.zzapprovedBy!=null &&
              this.zzapprovedBy.equals(other.getZzapprovedBy()))) &&
            ((this.zzcertifiedBy==null && other.getZzcertifiedBy()==null) || 
             (this.zzcertifiedBy!=null &&
              this.zzcertifiedBy.equals(other.getZzcertifiedBy()))) &&
            ((this.notice==null && other.getNotice()==null) || 
             (this.notice!=null &&
              this.notice.equals(other.getNotice()))) &&
            ((this.aufnr==null && other.getAufnr()==null) || 
             (this.aufnr!=null &&
              this.aufnr.equals(other.getAufnr()))) &&
            ((this.flError==null && other.getFlError()==null) || 
             (this.flError!=null &&
              this.flError.equals(other.getFlError()))) &&
            ((this.missingItems==null && other.getMissingItems()==null) || 
             (this.missingItems!=null &&
              this.missingItems.equals(other.getMissingItems())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getHead() != null) {
            _hashCode += getHead().hashCode();
        }
        if (getKomat() != null) {
            _hashCode += getKomat().hashCode();
        }
        if (getKoser() != null) {
            _hashCode += getKoser().hashCode();
        }
        if (getPosmat() != null) {
            _hashCode += getPosmat().hashCode();
        }
        if (getPoser() != null) {
            _hashCode += getPoser().hashCode();
        }
        if (getBatch() != null) {
            _hashCode += getBatch().hashCode();
        }
        if (getKweek() != null) {
            _hashCode += getKweek().hashCode();
        }
        if (getKyear() != null) {
            _hashCode += getKyear().hashCode();
        }
        if (getZzhsdat() != null) {
            _hashCode += getZzhsdat().hashCode();
        }
        if (getZzwerks() != null) {
            _hashCode += getZzwerks().hashCode();
        }
        if (getZzaeind() != null) {
            _hashCode += getZzaeind().hashCode();
        }
        if (getZzmodifStat() != null) {
            _hashCode += getZzmodifStat().hashCode();
        }
        if (getZzmountedBy() != null) {
            _hashCode += getZzmountedBy().hashCode();
        }
        if (getZzapprovedBy() != null) {
            _hashCode += getZzapprovedBy().hashCode();
        }
        if (getZzcertifiedBy() != null) {
            _hashCode += getZzcertifiedBy().hashCode();
        }
        if (getNotice() != null) {
            _hashCode += getNotice().hashCode();
        }
        if (getAufnr() != null) {
            _hashCode += getAufnr().hashCode();
        }
        if (getFlError() != null) {
            _hashCode += getFlError().hashCode();
        }
        if (getMissingItems() != null) {
            _hashCode += getMissingItems().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ZzqSIbaseDataFile.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:soap:functions:mc-style", "ZzqSIbaseDataFile"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("head");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Head"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("komat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Komat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("koser");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Koser"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("posmat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Posmat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("poser");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Poser"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("batch");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Batch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("kweek");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Kweek"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("kyear");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Kyear"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("zzhsdat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Zzhsdat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("zzwerks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Zzwerks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("zzaeind");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Zzaeind"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("zzmodifStat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZzmodifStat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("zzmountedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZzmountedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("zzapprovedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZzapprovedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("zzcertifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ZzcertifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notice");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Notice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("aufnr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Aufnr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flError");
        elemField.setXmlName(new javax.xml.namespace.QName("", "FlError"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("missingItems");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MissingItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
