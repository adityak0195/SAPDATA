/**
 * WS_CONF_CREATE_CONFIG.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.create_configuration;

public interface WS_CONF_CREATE_CONFIG extends javax.xml.rpc.Service {
    public java.lang.String getCONF_CREATE_CONFIGAddress();

    public com.knorr_bremse.sap_com.create_configuration.Zzq_ws_conf_create_config getCONF_CREATE_CONFIG() throws javax.xml.rpc.ServiceException;
    public void setHttpsAddress(java.lang.String address);

    public com.knorr_bremse.sap_com.create_configuration.Zzq_ws_conf_create_config getCONF_CREATE_CONFIG(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
