package com.knorr_bremse.sap_com.create_configuration;

public class Zzq_ws_conf_create_configProxy implements com.knorr_bremse.sap_com.create_configuration.Zzq_ws_conf_create_config {
  private String _endpoint = null;
  private com.knorr_bremse.sap_com.create_configuration.Zzq_ws_conf_create_config zzq_ws_conf_create_config = null;
  
  public Zzq_ws_conf_create_configProxy() {
    _initZzq_ws_conf_create_configProxy();
  }
  
  public Zzq_ws_conf_create_configProxy(String endpoint) {
    _endpoint = endpoint;
    _initZzq_ws_conf_create_configProxy();
  }
  
  private void _initZzq_ws_conf_create_configProxy() {
    try {
      zzq_ws_conf_create_config = (new com.knorr_bremse.sap_com.create_configuration.WS_CONF_CREATE_CONFIGLocator()).getCONF_CREATE_CONFIG();
      if (zzq_ws_conf_create_config != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)zzq_ws_conf_create_config)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)zzq_ws_conf_create_config)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (zzq_ws_conf_create_config != null)
      ((javax.xml.rpc.Stub)zzq_ws_conf_create_config)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.knorr_bremse.sap_com.create_configuration.Zzq_ws_conf_create_config getZzq_ws_conf_create_config() {
    if (zzq_ws_conf_create_config == null)
      _initZzq_ws_conf_create_configProxy();
    return zzq_ws_conf_create_config;
  }
  
  public void zzqConfigCreateConfig(java.lang.String ICallId, com.knorr_bremse.sap_com.create_configuration.ZzqSIbaseDataFile[] itConfig, javax.xml.rpc.holders.StringHolder EFlCancel, javax.xml.rpc.holders.StringHolder EFlRework, com.knorr_bremse.sap_com.create_configuration.holders.ZzqTIbaseDataFileHolder etConfig, com.knorr_bremse.sap_com.create_configuration.holders.ZzqTConfigReturnMessageHolder etReturn) throws java.rmi.RemoteException{
    if (zzq_ws_conf_create_config == null)
      _initZzq_ws_conf_create_configProxy();
    zzq_ws_conf_create_config.zzqConfigCreateConfig(ICallId, itConfig, EFlCancel, EFlRework, etConfig, etReturn);
  }
  
  
}