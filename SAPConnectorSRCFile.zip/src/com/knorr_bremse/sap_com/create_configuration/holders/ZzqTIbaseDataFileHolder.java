/**
 * ZzqTIbaseDataFileHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.create_configuration.holders;

public final class ZzqTIbaseDataFileHolder implements javax.xml.rpc.holders.Holder {
    public com.knorr_bremse.sap_com.create_configuration.ZzqSIbaseDataFile[] value;

    public ZzqTIbaseDataFileHolder() {
    }

    public ZzqTIbaseDataFileHolder(com.knorr_bremse.sap_com.create_configuration.ZzqSIbaseDataFile[] value) {
        this.value = value;
    }

}
