/**
 * ZzqConfigReturnMessage.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.sap_com.create_configuration;

public class ZzqConfigReturnMessage  implements java.io.Serializable {
    private java.lang.String msgLine;

    private java.lang.String msgType;

    private java.lang.String msgId;

    private java.lang.String msgNo;

    private java.lang.String msgV1;

    private java.lang.String msgV2;

    private java.lang.String msgV3;

    private java.lang.String msgV4;

    private java.lang.String msgTxt;

    public ZzqConfigReturnMessage() {
    }

    public ZzqConfigReturnMessage(
           java.lang.String msgLine,
           java.lang.String msgType,
           java.lang.String msgId,
           java.lang.String msgNo,
           java.lang.String msgV1,
           java.lang.String msgV2,
           java.lang.String msgV3,
           java.lang.String msgV4,
           java.lang.String msgTxt) {
           this.msgLine = msgLine;
           this.msgType = msgType;
           this.msgId = msgId;
           this.msgNo = msgNo;
           this.msgV1 = msgV1;
           this.msgV2 = msgV2;
           this.msgV3 = msgV3;
           this.msgV4 = msgV4;
           this.msgTxt = msgTxt;
    }


    /**
     * Gets the msgLine value for this ZzqConfigReturnMessage.
     * 
     * @return msgLine
     */
    public java.lang.String getMsgLine() {
        return msgLine;
    }


    /**
     * Sets the msgLine value for this ZzqConfigReturnMessage.
     * 
     * @param msgLine
     */
    public void setMsgLine(java.lang.String msgLine) {
        this.msgLine = msgLine;
    }


    /**
     * Gets the msgType value for this ZzqConfigReturnMessage.
     * 
     * @return msgType
     */
    public java.lang.String getMsgType() {
        return msgType;
    }


    /**
     * Sets the msgType value for this ZzqConfigReturnMessage.
     * 
     * @param msgType
     */
    public void setMsgType(java.lang.String msgType) {
        this.msgType = msgType;
    }


    /**
     * Gets the msgId value for this ZzqConfigReturnMessage.
     * 
     * @return msgId
     */
    public java.lang.String getMsgId() {
        return msgId;
    }


    /**
     * Sets the msgId value for this ZzqConfigReturnMessage.
     * 
     * @param msgId
     */
    public void setMsgId(java.lang.String msgId) {
        this.msgId = msgId;
    }


    /**
     * Gets the msgNo value for this ZzqConfigReturnMessage.
     * 
     * @return msgNo
     */
    public java.lang.String getMsgNo() {
        return msgNo;
    }


    /**
     * Sets the msgNo value for this ZzqConfigReturnMessage.
     * 
     * @param msgNo
     */
    public void setMsgNo(java.lang.String msgNo) {
        this.msgNo = msgNo;
    }


    /**
     * Gets the msgV1 value for this ZzqConfigReturnMessage.
     * 
     * @return msgV1
     */
    public java.lang.String getMsgV1() {
        return msgV1;
    }


    /**
     * Sets the msgV1 value for this ZzqConfigReturnMessage.
     * 
     * @param msgV1
     */
    public void setMsgV1(java.lang.String msgV1) {
        this.msgV1 = msgV1;
    }


    /**
     * Gets the msgV2 value for this ZzqConfigReturnMessage.
     * 
     * @return msgV2
     */
    public java.lang.String getMsgV2() {
        return msgV2;
    }


    /**
     * Sets the msgV2 value for this ZzqConfigReturnMessage.
     * 
     * @param msgV2
     */
    public void setMsgV2(java.lang.String msgV2) {
        this.msgV2 = msgV2;
    }


    /**
     * Gets the msgV3 value for this ZzqConfigReturnMessage.
     * 
     * @return msgV3
     */
    public java.lang.String getMsgV3() {
        return msgV3;
    }


    /**
     * Sets the msgV3 value for this ZzqConfigReturnMessage.
     * 
     * @param msgV3
     */
    public void setMsgV3(java.lang.String msgV3) {
        this.msgV3 = msgV3;
    }


    /**
     * Gets the msgV4 value for this ZzqConfigReturnMessage.
     * 
     * @return msgV4
     */
    public java.lang.String getMsgV4() {
        return msgV4;
    }


    /**
     * Sets the msgV4 value for this ZzqConfigReturnMessage.
     * 
     * @param msgV4
     */
    public void setMsgV4(java.lang.String msgV4) {
        this.msgV4 = msgV4;
    }


    /**
     * Gets the msgTxt value for this ZzqConfigReturnMessage.
     * 
     * @return msgTxt
     */
    public java.lang.String getMsgTxt() {
        return msgTxt;
    }


    /**
     * Sets the msgTxt value for this ZzqConfigReturnMessage.
     * 
     * @param msgTxt
     */
    public void setMsgTxt(java.lang.String msgTxt) {
        this.msgTxt = msgTxt;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ZzqConfigReturnMessage)) return false;
        ZzqConfigReturnMessage other = (ZzqConfigReturnMessage) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.msgLine==null && other.getMsgLine()==null) || 
             (this.msgLine!=null &&
              this.msgLine.equals(other.getMsgLine()))) &&
            ((this.msgType==null && other.getMsgType()==null) || 
             (this.msgType!=null &&
              this.msgType.equals(other.getMsgType()))) &&
            ((this.msgId==null && other.getMsgId()==null) || 
             (this.msgId!=null &&
              this.msgId.equals(other.getMsgId()))) &&
            ((this.msgNo==null && other.getMsgNo()==null) || 
             (this.msgNo!=null &&
              this.msgNo.equals(other.getMsgNo()))) &&
            ((this.msgV1==null && other.getMsgV1()==null) || 
             (this.msgV1!=null &&
              this.msgV1.equals(other.getMsgV1()))) &&
            ((this.msgV2==null && other.getMsgV2()==null) || 
             (this.msgV2!=null &&
              this.msgV2.equals(other.getMsgV2()))) &&
            ((this.msgV3==null && other.getMsgV3()==null) || 
             (this.msgV3!=null &&
              this.msgV3.equals(other.getMsgV3()))) &&
            ((this.msgV4==null && other.getMsgV4()==null) || 
             (this.msgV4!=null &&
              this.msgV4.equals(other.getMsgV4()))) &&
            ((this.msgTxt==null && other.getMsgTxt()==null) || 
             (this.msgTxt!=null &&
              this.msgTxt.equals(other.getMsgTxt())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMsgLine() != null) {
            _hashCode += getMsgLine().hashCode();
        }
        if (getMsgType() != null) {
            _hashCode += getMsgType().hashCode();
        }
        if (getMsgId() != null) {
            _hashCode += getMsgId().hashCode();
        }
        if (getMsgNo() != null) {
            _hashCode += getMsgNo().hashCode();
        }
        if (getMsgV1() != null) {
            _hashCode += getMsgV1().hashCode();
        }
        if (getMsgV2() != null) {
            _hashCode += getMsgV2().hashCode();
        }
        if (getMsgV3() != null) {
            _hashCode += getMsgV3().hashCode();
        }
        if (getMsgV4() != null) {
            _hashCode += getMsgV4().hashCode();
        }
        if (getMsgTxt() != null) {
            _hashCode += getMsgTxt().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ZzqConfigReturnMessage.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sap-com:document:sap:soap:functions:mc-style", "ZzqConfigReturnMessage"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msgLine");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MsgLine"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msgType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MsgType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msgId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MsgId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msgNo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MsgNo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msgV1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MsgV1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msgV2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MsgV2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msgV3");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MsgV3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msgV4");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MsgV4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msgTxt");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MsgTxt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
