package com.ptc.kb.sap;

import java.util.Date;

import com.ptc.kb.sap.KBsapConfigConnectorTemplate;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileInputStream;
import jcifs.smb.SmbFileOutputStream;

public class TestConfigConnection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
						
			KBsapConfigConnectorTemplate conDev = new KBsapConfigConnectorTemplate("", "svc.bud.cfgmgmtcopy", "xtP23Buw", "smb://mucs0242/KMDprfprt/TWXTEST/");
			conDev.SMB_Init_Worker();
			SmbFile[] files = conDev.SMB_Dir_worker("smb://mucs0242/KMDprfprt/TWXTEST/");
			
			System.out.println("*******************************************************************");
			System.out.println("Check KMDprfprt:");
			System.out.println("# of files in directory: "+files.length);
			
			String file = "smb://mucs0242/KMDprfprt/TWXTEST/TWX_Test_"+String.valueOf((new Date()).getTime())+".txt";
			
			System.out.println("Create file "+file);
			
			conDev.SMB_Write_Text_worker(file, "Sample text written/read into/from file (KMDprfprt)");
			System.out.println("Writing ok");
			System.out.println(conDev.SMB_Read_Text_worker(file));
			System.out.println("Reading ok");
			conDev.SMB_Delete_worker(file);
			System.out.println("Deleting ok");
			
			System.out.println("KMDprfprt ok");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			System.out.println("*******************************************************************");
		}

		try {
						
			KBsapConfigConnectorTemplate conProd = new KBsapConfigConnectorTemplate("", "svc.MUC.thingworx", "V\\X4fB~^", "smb://mucs0242/KMPPrfPrt/TWXTEST/");
			conProd.SMB_Init_Worker();
			SmbFile[] files = conProd.SMB_Dir_worker("smb://mucs0242/KMPPrfPrt/TWXTEST/");
			
			System.out.println("*******************************************************************");
			System.out.println("Check KMPPrfPrt:");
			System.out.println("# of files in directory: "+files.length);
			
			String file = "smb://mucs0242/KMPPrfPrt/TWXTEST/TWX_Test_"+String.valueOf((new Date()).getTime())+".txt";
			
			System.out.println("Create file "+file);
			
			conProd.SMB_Write_Text_worker(file, "Sample text written/read into/from file (KMPPrfPrt)");
			System.out.println("Writing ok");
			System.out.println(conProd.SMB_Read_Text_worker(file));
			System.out.println("Reading ok");
			conProd.SMB_Delete_worker(file);
			System.out.println("Deleting ok");

			System.out.println("KMPPrfPrt ok");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			System.out.println("*******************************************************************");
		}
	}

}
