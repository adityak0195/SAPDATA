package com.ptc.kb.sap;

import java.text.SimpleDateFormat;

import javax.xml.rpc.ServiceException;

import org.joda.time.DateTime;

import com.thingworx.data.util.InfoTableInstanceFactory;
import com.thingworx.metadata.annotations.ThingworxConfigurationTableDefinition;
import com.thingworx.metadata.annotations.ThingworxConfigurationTableDefinitions;
import com.thingworx.metadata.annotations.ThingworxDataShapeDefinition;
import com.thingworx.metadata.annotations.ThingworxFieldDefinition;
import com.thingworx.metadata.annotations.ThingworxServiceDefinition;
import com.thingworx.metadata.annotations.ThingworxServiceParameter;
import com.thingworx.metadata.annotations.ThingworxServiceResult;
import com.thingworx.system.ContextType;										
import com.thingworx.things.Thing;
import com.thingworx.types.InfoTable;
import com.thingworx.types.collections.ValueCollection;
import com.thingworx.types.primitives.StringPrimitive;
																  
import com.knorr_bremse.sap_com.plannedWorkingTime.Y_P_GET_PLANNED_WORKING_TIMEResponse;
import com.knorr_bremse.sap_com.plannedWorkingTime.ZAPO_RES_SHIFTS;
import com.knorr_bremse.sap_com.sernrUpdateInProdOrder.ZZQ_CONFIG_RETURN_MESSAGE;
import com.knorr_bremse.sap_com.sernrUpdateInProdOrder.ZZQ_S_IBASE_DATA_FILE;
import com.knorr_bremse.sap_com.testReportUpload.ZzqSImportTestrepDataWs;

@ThingworxConfigurationTableDefinitions(tables = {
		@ThingworxConfigurationTableDefinition(
				name = "SAPConfiguration",
				description = "SAP server configuration", 
				isMultiRow = false,
				dataShape = @ThingworxDataShapeDefinition(fields = {
						@ThingworxFieldDefinition(name = "Username_APO_ShiftCalendar", description = "User name for accessing SAP APO", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),
						@ThingworxFieldDefinition(name = "Password_APO_ShiftCalendar", description = "Password for accessing SAP APO", baseType = "PASSWORD"),
						@ThingworxFieldDefinition(name = "URL_APO_ShiftCalendar", description = "Full URL to access PI for APO shift calenar", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),
						
						@ThingworxFieldDefinition(name = "Username_POI_Confirmation", description = "User name for accessing SAP APO", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),
						@ThingworxFieldDefinition(name = "Password_POI_Confirmation", description = "Password for accessing SAP APO", baseType = "PASSWORD"),
						@ThingworxFieldDefinition(name = "URL_POI_Confirmation", description = "Full URL to access PI for Confirmation (TWX --> SAP only)", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),
						
						@ThingworxFieldDefinition(name = "Username_PM", description = "User name for accessing SAP PM", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),
						@ThingworxFieldDefinition(name = "Password_PM", description = "Password for accessing SAP PM", baseType = "PASSWORD"),
						@ThingworxFieldDefinition(name = "URL_PM", description = "Full URL to access PM sending Notification (TWX --> SAP only)", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),
						
						@ThingworxFieldDefinition(name = "Username_PM_MD", description = "User name for accessing SAP PM MD", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),
						@ThingworxFieldDefinition(name = "Password_PM_MD", description = "Password for accessing SAP PM MD", baseType = "PASSWORD"),
						@ThingworxFieldDefinition(name = "URL_PM_MD", description = "Full URL to access PM Master Data (TWX --> SAP only)", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),
						
						@ThingworxFieldDefinition(name = "Username_SAP_Components_Check", description = "User name for accessing SAP APO", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),
						@ThingworxFieldDefinition(name = "Password_SAP_Components_Check", description = "Password for accessing SAP APO", baseType = "PASSWORD"),
						@ThingworxFieldDefinition(name = "URL_SAP_Components_Check", description = "Full URL to access PI for Confirmation Check (TWX --> SAP only)", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),

						@ThingworxFieldDefinition(name = "Username_SAP_Testprotocol_Upload", description = "User name for accessing SAP for test protocol upload", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),
						@ThingworxFieldDefinition(name = "Password_SAP_Testprotocol_Upload", description = "Password for accessing SAP for test protocol upload", baseType = "PASSWORD"),
						@ThingworxFieldDefinition(name = "URL_SAP_Testprotocol_Upload", description = "Full URL to access SAP for test protocol upload (TWX --> SAP only)", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),

						@ThingworxFieldDefinition(name = "Username_SAP_Components_Status", description = "User name for accessing SAP APO", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),
						@ThingworxFieldDefinition(name = "Password_SAP_Components_Status", description = "Password for accessing SAP APO", baseType = "PASSWORD"),
						@ThingworxFieldDefinition(name = "URL_SAP_Components_Status", description = "Full URL to access PI for Confirmation Status (TWX --> SAP only)", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),

						@ThingworxFieldDefinition(name = "Username_SAP_Create_Configuration", description = "User name for accessing SAP APO", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),
						@ThingworxFieldDefinition(name = "Password_SAP_Create_Configuration", description = "Password for accessing SAP APO", baseType = "PASSWORD"),
						@ThingworxFieldDefinition(name = "URL_SAP_Create_Configuration", description = "Full URL to access PI for Create Configuration (TWX --> SAP only)", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),

						@ThingworxFieldDefinition(name = "URL_SAP_Create_Configuration", description = "Full URL to access PI for Confirmation Check (TWX --> SAP only)", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),
						
						@ThingworxFieldDefinition(name = "Username_SAP_SernrUpdateInProdOrder", description = "User name for Sernr Update In Prod Order", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"}),
						@ThingworxFieldDefinition(name = "Password_SAP_SernrUpdateInProdOrder", description = "Password for Sernr Update In Prod Order", baseType = "PASSWORD"),
						@ThingworxFieldDefinition(name = "URL_SAP_SernrUpdateInProdOrder", description = "Full URL to Sernr Update In Prod Order", baseType = "STRING", aspects = {"defaultValue:dont_change_to_get_from_global_settings"})
					}) 
			)
	})
public class SAPServer extends Thing {

	private static final long serialVersionUID = 1L;
	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd.MM.yyyy");
	
	private com.knorr_bremse.sap_com.plannedWorkingTime.SI_OUT_Worx_PlannedWorkingTime_SYNC bindingPlannedWorkingTime;
																												 
	private String workingtimestatus;
										

	@ThingworxServiceDefinition(name = "GetPlannedWorkingTime", description = "Get planned working time from SAP")
	@ThingworxServiceResult(name = "Result", description = "", baseType = "INFOTABLE", aspects = {"dataShape:KBSAPPlannedWorkingTimeDataShape"})
	public InfoTable GetPlannedWorkingTime(
			@ThingworxServiceParameter(name = "plant", description = "Plant", baseType = "STRING", aspects = {"isRequired:true"}) String plant,
			@ThingworxServiceParameter(name = "version", description = "Version (default is 000)", baseType = "STRING", aspects = {"isRequired:false", "defaultValue:000"}) String version,
			@ThingworxServiceParameter(name = "dateFrom", description = "From", baseType = "DATETIME", aspects = {"isRequired:false"}) DateTime dateFrom,
			@ThingworxServiceParameter(name = "dateTo", description = "To", baseType = "DATETIME", aspects = {"isRequired:false"}) DateTime dateTo
		) throws Exception {
    	
		_logger.debug("SAPServer/GetPlannedWorkingTime: Entering Service: " + plant + " " + version + " " + dateFrom + " " + dateTo);
		System.out.println("SAPServer/GetPlannedWorkingTime: Entering Service: " + plant + " " + version + " " + dateFrom + " " + dateTo);

		
		com.knorr_bremse.sap_com.plannedWorkingTime.DT_Worx_PlannedWorkingTime request = new com.knorr_bremse.sap_com.plannedWorkingTime.DT_Worx_PlannedWorkingTime(
    			version, 
    			plant, 
    			DATE_FORMAT.format(dateFrom.toDate()), 
    			DATE_FORMAT.format(dateTo.toDate())
			);
		
		System.out.println("SAPServer/GetPlannedWorkingTime: Y_P_GET_PLANNED_WORKING_TIMEResponse");
		Y_P_GET_PLANNED_WORKING_TIMEResponse response = bindingPlannedWorkingTime.SI_OUT_Worx_PlannedWorkingTime_SYNC(request);
        
		// InfoTable res = InfoTableInstanceFactory.createInfoTableFromDataShape(ZAPO_RES_SHIFTS.DATA_SHAPE);
		System.out.println("SAPServer/GetPlannedWorkingTime: InfoTable res");
		InfoTable res = InfoTableInstanceFactory.createInfoTableFromDataShape("KBSAPPlannedWorkingTimeDataShape");
		System.out.println("SAPServer/GetPlannedWorkingTime: loop");
        for (ZAPO_RES_SHIFTS shift: response.getET_DATA()){
        	res.addRow(shift.toValueCollection());
        }

		_logger.debug("SAPServer/GetPlannedWorkingTime: Exiting Service: " + plant + " " + version + " " + dateFrom + " " + dateTo);
		System.out.println("SAPServer/GetPlannedWorkingTime: Exiting Service: " + plant + " " + version + " " + dateFrom + " " + dateTo);
        return res;
	}

	@ThingworxServiceDefinition(name = "PushTestprotocolRail", description = "Pushes test protocol (Rail) to SAP")
	@ThingworxServiceResult(name = "Result", description = "", baseType = "INFOTABLE", aspects = {"dataShape:KBSAPTestprotocolUploadRailDataShape_V2"})
	public InfoTable PushTestprotocolRail(
			@ThingworxServiceParameter(name = "ICallId", description = "ICallId", baseType = "STRING", aspects = {"isRequired:true"}) String ICallId,
			@ThingworxServiceParameter(name = "Matnr", description = "isDocumentData.setMatnr", baseType = "STRING", aspects = {"isRequired:false"}) String Matnr,
			@ThingworxServiceParameter(name = "Prorder", description = "isDocumentData.setProrder", baseType = "STRING", aspects = {"isRequired:false"}) String Prorder,
			@ThingworxServiceParameter(name = "Sernr", description = "isDocumentData.setSernr", baseType = "STRING", aspects = {"isRequired:false"}) String Sernr,
			@ThingworxServiceParameter(name = "Doctype", description = "isDocumentData.setDoctype", baseType = "STRING", aspects = {"isRequired:false"}) String Doctype,
			@ThingworxServiceParameter(name = "Docresult", description = "isDocumentData.setDocresult", baseType = "STRING", aspects = {"isRequired:false"}) String Docresult,
			@ThingworxServiceParameter(name = "Hsdat", description = "isDocumentData.setHsdat", baseType = "STRING", aspects = {"isRequired:false"}) String Hsdat,
			@ThingworxServiceParameter(name = "isDocumentString", description = "isDocumentString", baseType = "STRING", aspects = {"isRequired:false"}) String isDocumentString
			) throws Exception {
    	
		_logger.debug("SAPServer/PushTestprotocolRail: Entering Service");

		//parameters which are currently not in use
		java.lang.String IFlDms = null;
		java.lang.String IFlXecm = null;
		
		//setting up ZzqSImportTestrepDataWs
		ZzqSImportTestrepDataWs isDocumentData = new ZzqSImportTestrepDataWs();
		isDocumentData.setMatnr(Matnr);
		isDocumentData.setProrder(Prorder);
		isDocumentData.setSernr(Sernr);
		isDocumentData.setDoctype(Doctype);
		isDocumentData.setDocresult(Docresult);
		isDocumentData.setHsdat(Hsdat);

		com.knorr_bremse.sap_com.testReportUpload.holders.ZzqSExportTestrepDataWsHolder esDocumentData = new com.knorr_bremse.sap_com.testReportUpload.holders.ZzqSExportTestrepDataWsHolder();
		com.knorr_bremse.sap_com.testReportUpload.holders.ZzqTReturnMessageHolder etReturn = new com.knorr_bremse.sap_com.testReportUpload.holders.ZzqTReturnMessageHolder();

		com.knorr_bremse.sap_com.testReportUpload.CREATE_TESTREP binding;
		com.knorr_bremse.sap_com.testReportUpload.ZZQ_WS_CREATE_TESTREP service = new com.knorr_bremse.sap_com.testReportUpload.ZZQ_WS_CREATE_TESTREPLocator();
		
		service.setHttpAddress(getStringConfigurationSetting("SAPConfiguration", "URL_SAP_Testprotocol_Upload"));
		
		binding = service.getCREATE_TESTREP();
		com.knorr_bremse.sap_com.testReportUpload.CREATE_TESTREPStub stub = (com.knorr_bremse.sap_com.testReportUpload.CREATE_TESTREPStub) binding;
        stub.setUsername(getStringConfigurationSetting("SAPConfiguration", "Username_SAP_Testprotocol_Upload"));
        stub.setPassword(getStringConfigurationSetting("SAPConfiguration", "Password_SAP_Testprotocol_Upload"));
		
		binding.zzqCreateTestrepFromWs(ICallId, IFlDms, IFlXecm, isDocumentData, isDocumentString,  esDocumentData,  etReturn);

		InfoTable res = InfoTableInstanceFactory.createInfoTableFromDataShape("KBSAPTestprotocolUploadRailDataShape_V2");
		

		for (int x = 0; x < etReturn.value.length; x++) {
			ValueCollection returnVal = new ValueCollection();
			returnVal.put("Identifier", new StringPrimitive("Return"));
			returnVal.put("MsgLine", new StringPrimitive(etReturn.value[x].getMsgLine()));
			returnVal.put("MsgType", new StringPrimitive(etReturn.value[x].getMsgType()));
			returnVal.put("MsgId", new StringPrimitive(etReturn.value[x].getMsgId()));
			returnVal.put("MsgNo", new StringPrimitive(etReturn.value[x].getMsgNo()));
			returnVal.put("MsgV1", new StringPrimitive(etReturn.value[x].getMsgV1()));
			returnVal.put("MsgV2", new StringPrimitive(etReturn.value[x].getMsgV2()));
			returnVal.put("MsgV3", new StringPrimitive(etReturn.value[x].getMsgV3()));
			returnVal.put("MsgV4", new StringPrimitive(etReturn.value[x].getMsgV4()));
			returnVal.put("MsgTxt", new StringPrimitive(etReturn.value[x].getMsgTxt()));
        	res.addRow(returnVal);
		}

		if (esDocumentData != null) {
			ValueCollection message = new ValueCollection();
			com.knorr_bremse.sap_com.testReportUpload.ZzqSExportTestrepDataWs result = esDocumentData.value;
			message.put("Identifier", new StringPrimitive("DocumentData"));
			message.put("Docresult", new StringPrimitive(result.getDocresult()));
			message.put("Doctype", new StringPrimitive(result.getDoctype()));
			message.put("Dokar", new StringPrimitive(result.getDokar()));
			message.put("Doknr", new StringPrimitive(result.getDoknr()));
			message.put("Doktl", new StringPrimitive(result.getDoktl()));
			message.put("Dokvr", new StringPrimitive(result.getDokvr()));
			message.put("Equnr", new StringPrimitive(result.getEqunr()));
			message.put("Hsdat", new StringPrimitive(result.getHsdat()));
			message.put("Matnr", new StringPrimitive(result.getMatnr()));
			message.put("Prorder", new StringPrimitive(result.getProrder()));
			message.put("Sernr", new StringPrimitive(result.getSernr()));
	    	res.addRow(message);
		}		

		_logger.debug("SAPServer/PushTestprotocolRail: Exiting Service");
        return res;
	}
	
	@ThingworxServiceDefinition(name = "GetComponentsCheckRail", description = "Get Components Check (Rail) from SAP")
	@ThingworxServiceResult(name = "Result", description = "", baseType = "INFOTABLE", aspects = {"dataShape:KBSAPComponentsCheckRailDataShape"})
	public InfoTable GetComponentsCheckRail(
			@ThingworxServiceParameter(name = "ICallId", description = "ICallId", baseType = "STRING", aspects = {"isRequired:true"}) String ICallId,
			@ThingworxServiceParameter(name = "IAufnr", description = "IAufnr", baseType = "STRING", aspects = {"isRequired:false"}) String IAufnr,
			@ThingworxServiceParameter(name = "IMatnr", description = "IMatnr", baseType = "STRING", aspects = {"isRequired:false"}) String IMatnr,
			@ThingworxServiceParameter(name = "IZzaeind", description = "IZzaeind", baseType = "STRING", aspects = {"isRequired:false"}) String IZzaeind
			) throws Exception {
    	
		_logger.debug("SAPServer/GetComponentsCheckRail: Entering Service");

		com.knorr_bremse.sap_com.components_check.holders.ZzqTConfigComponentsHolder etComponents = new com.knorr_bremse.sap_com.components_check.holders.ZzqTConfigComponentsHolder();
		com.knorr_bremse.sap_com.components_check.holders.ZzqTConfigReturnMessageHolder etReturn = new com.knorr_bremse.sap_com.components_check.holders.ZzqTConfigReturnMessageHolder();
		
		com.knorr_bremse.sap_com.components_check.Zzq_ws_conf_get_components_PortType binding;
		com.knorr_bremse.sap_com.components_check.Zzq_ws_conf_get_components_ServiceLocator service = new com.knorr_bremse.sap_com.components_check.Zzq_ws_conf_get_components_ServiceLocator();
		service.setHttpsAddress(getStringConfigurationSetting("SAPConfiguration", "URL_SAP_Components_Check"));
		binding = service.getCONF_GET_COMPONENTS();
		com.knorr_bremse.sap_com.components_check.CONF_GET_COMPONENTSStub stub = (com.knorr_bremse.sap_com.components_check.CONF_GET_COMPONENTSStub) binding;
        stub.setUsername(getStringConfigurationSetting("SAPConfiguration", "Username_SAP_Components_Check"));
        stub.setPassword(getStringConfigurationSetting("SAPConfiguration", "Password_SAP_Components_Check"));
		
		binding.zzqConfigGetComponents(IAufnr, ICallId, IMatnr, IZzaeind, etComponents, etReturn);


		InfoTable res = InfoTableInstanceFactory.createInfoTableFromDataShape("KBSAPComponentsCheckRailDataShape");
		
		for (int x = 0; x < etComponents.value.length; x++) {
			ValueCollection message = new ValueCollection();
			message.put("Identifier", new StringPrimitive("Components"));
			message.put("posno", new StringPrimitive(etComponents.value[x].getPosno()));
			message.put("matnrHead", new StringPrimitive(etComponents.value[x].getMatnrHead()));
			message.put("maktxHead", new StringPrimitive(etComponents.value[x].getMaktxHead()));
			message.put("zzaindexBom", new StringPrimitive(etComponents.value[x].getZzaindexBom()));
			message.put("werks", new StringPrimitive(etComponents.value[x].getWerks()));
			message.put("zzaindexHead", new StringPrimitive(etComponents.value[x].getZzaindexHead()));
			message.put("zzconfigFlagHead", new StringPrimitive(etComponents.value[x].getZzconfigFlagHead()));
			message.put("sernpHead", new StringPrimitive(etComponents.value[x].getSernpHead()));
			message.put("matnrItem", new StringPrimitive(etComponents.value[x].getMatnrItem()));
			message.put("maktxItem", new StringPrimitive(etComponents.value[x].getMaktxItem()));
			message.put("zzaindexItem", new StringPrimitive(etComponents.value[x].getZzaindexItem()));
			message.put("zzconfigFlagItem", new StringPrimitive(etComponents.value[x].getZzconfigFlagItem()));
			message.put("sernpItem", new StringPrimitive(etComponents.value[x].getSernpItem()));
			message.put("itemInPlant", new StringPrimitive(etComponents.value[x].getItemInPlant()));
			message.put("configDummy", new StringPrimitive(etComponents.value[x].getConfigDummy()));
        	res.addRow(message);
		}
		
		
		for (int x = 0; x < etReturn.value.length; x++) {
			ValueCollection returnVal = new ValueCollection();
			returnVal.put("Identifier", new StringPrimitive("Return"));
			returnVal.put("MsgLine", new StringPrimitive(etReturn.value[x].getMsgLine()));
			returnVal.put("MsgType", new StringPrimitive(etReturn.value[x].getMsgType()));
			returnVal.put("MsgId", new StringPrimitive(etReturn.value[x].getMsgId()));
			returnVal.put("MsgNo", new StringPrimitive(etReturn.value[x].getMsgNo()));
			returnVal.put("MsgV1", new StringPrimitive(etReturn.value[x].getMsgV1()));
			returnVal.put("MsgV2", new StringPrimitive(etReturn.value[x].getMsgV2()));
			returnVal.put("MsgV3", new StringPrimitive(etReturn.value[x].getMsgV3()));
			returnVal.put("MsgV4", new StringPrimitive(etReturn.value[x].getMsgV4()));
			returnVal.put("MsgTxt", new StringPrimitive(etReturn.value[x].getMsgTxt()));
        	res.addRow(returnVal);
		}

		_logger.debug("SAPServer/GetComponentsCheckRail: Exiting Service");
        return res;
	}
	
	@ThingworxServiceDefinition(name = "GetSernrUpdateInProdOrder", description = "Get Components Check (Rail) from SAP")
	@ThingworxServiceResult(name = "Result", description = "", baseType = "INFOTABLE", aspects = {"dataShape:KBSAPSernrUpdateInProdOrderDataShape"})
	public InfoTable GetSernrUpdateInProdOrder(
			@ThingworxServiceParameter(name = "ICallId", description = "IV_CALLER_ID", baseType = "STRING", aspects = {"isRequired:true"}) String ICallId,
			@ThingworxServiceParameter(name = "ICurrentSerialNumber", description = "IV_CURRENT_SERIALNUMBER", baseType = "STRING", aspects = {"isRequired:true"}) String ICurrentSerialNumber,
			@ThingworxServiceParameter(name = "IDoAllPrechecksOnly", description = "IV_DO_ALL_PRECHECKS_ONLY", baseType = "STRING", aspects = {"isRequired:false"}) String IDoAllPrechecksOnly,
			@ThingworxServiceParameter(name = "IMatnr", description = "IV_MATERIAL_NUMBER", baseType = "STRING", aspects = {"isRequired:true"}) String IMatnr,
			@ThingworxServiceParameter(name = "INewSerialNumber", description = "IV_NEW_SERIALNUMBER", baseType = "STRING", aspects = {"isRequired:true"}) String INewSerialNumber,
			@ThingworxServiceParameter(name = "IProductionOrder", description = "IV_PRODUCTION_ORDER", baseType = "STRING", aspects = {"isRequired:true"}) String IProductionOrder
			) throws Exception {
    	
		_logger.debug("SAPServer/GetSernrUpdateInProdOrder: Entering Service");

		com.knorr_bremse.sap_com.sernrUpdateInProdOrder.ZZQ_SERNR_UPDATE_IN_PRODORDER_ServiceLocator service = new com.knorr_bremse.sap_com.sernrUpdateInProdOrder.ZZQ_SERNR_UPDATE_IN_PRODORDER_ServiceLocator();
		service.setHttpAddress(getStringConfigurationSetting("SAPConfiguration", "URL_SAP_SernrUpdateInProdOrder"));
		com.knorr_bremse.sap_com.sernrUpdateInProdOrder.ZZQ_SERNR_UPDATE_IN_PRODORDER_PortType binding = service.getCONF_EXCH_SERNR();
		com.knorr_bremse.sap_com.sernrUpdateInProdOrder.CONF_EXCH_SERNRStub stub = (com.knorr_bremse.sap_com.sernrUpdateInProdOrder.CONF_EXCH_SERNRStub) binding;
		stub.setUsername(getStringConfigurationSetting("SAPConfiguration", "Username_SAP_SernrUpdateInProdOrder"));
		stub.setPassword(getStringConfigurationSetting("SAPConfiguration", "Password_SAP_SernrUpdateInProdOrder"));

		
		com.knorr_bremse.sap_com.sernrUpdateInProdOrder.holders.ZZQ_T_IBASE_DATA_FILEHolder ET_CONFIG = new com.knorr_bremse.sap_com.sernrUpdateInProdOrder.holders.ZZQ_T_IBASE_DATA_FILEHolder();
		com.knorr_bremse.sap_com.sernrUpdateInProdOrder.holders.ZZQ_T_CONFIG_RETURN_MESSAGEHolder ET_RETURN = new com.knorr_bremse.sap_com.sernrUpdateInProdOrder.holders.ZZQ_T_CONFIG_RETURN_MESSAGEHolder();
		javax.xml.rpc.holders.StringHolder e_FL_CANCEL = new javax.xml.rpc.holders.StringHolder();
		javax.xml.rpc.holders.StringHolder e_FL_REWORK = new javax.xml.rpc.holders.StringHolder();
		
					
		binding.ZZQ_SERNR_UPDATE_IN_PRODORDER(ICallId, ICurrentSerialNumber, IDoAllPrechecksOnly, IMatnr, INewSerialNumber, IProductionOrder, ET_CONFIG, ET_RETURN, e_FL_CANCEL, e_FL_REWORK);
			
		InfoTable res = InfoTableInstanceFactory.createInfoTableFromDataShape("KBSAPSernrUpdateInProdOrderDataShape");

		
		
		if (ET_RETURN != null) {
	        for (ZZQ_CONFIG_RETURN_MESSAGE message: ET_RETURN.value){
				ValueCollection returnVal = new ValueCollection();
				returnVal.put("Identifier", new StringPrimitive("Return"));
				returnVal.put("MSG_LINE", new StringPrimitive(message.getMSG_LINE()));
				returnVal.put("MSG_ID", new StringPrimitive(message.getMSG_ID()));
				returnVal.put("MSG_NO", new StringPrimitive(message.getMSG_NO()));
				returnVal.put("MSG_TXT", new StringPrimitive(message.getMSG_TXT()));
				returnVal.put("MSG_TYPE", new StringPrimitive(message.getMSG_TYPE()));
				returnVal.put("MSG_V1", new StringPrimitive(message.getMSG_V1()));
				returnVal.put("MSG_V2", new StringPrimitive(message.getMSG_V2()));
				returnVal.put("MSG_V3", new StringPrimitive(message.getMSG_V3()));
				returnVal.put("MSG_V4", new StringPrimitive(message.getMSG_V4()));
	        	res.addRow(returnVal);
	        }
		}
        
		if (ET_CONFIG != null) {
	        for (ZZQ_S_IBASE_DATA_FILE result: ET_CONFIG.value){
				ValueCollection returnVal = new ValueCollection();
				returnVal.put("Identifier", new StringPrimitive("Data"));
				returnVal.put("AUFNR", new StringPrimitive(result.getAUFNR()));
				returnVal.put("BATCH", new StringPrimitive(result.getBATCH()));
				returnVal.put("FL_ERROR", new StringPrimitive(result.getFL_ERROR()));
				returnVal.put("HEAD", new StringPrimitive(result.getHEAD()));
				returnVal.put("KOMAT", new StringPrimitive(result.getKOMAT()));
				returnVal.put("KOSER", new StringPrimitive(result.getKOSER()));
				returnVal.put("KWEEK", new StringPrimitive(result.getKWEEK()));
				returnVal.put("KYEAR", new StringPrimitive(result.getKYEAR()));
				returnVal.put("MISSING_ITEMS", new StringPrimitive(result.getMISSING_ITEMS()));
				returnVal.put("NOTICE", new StringPrimitive(result.getNOTICE()));
				returnVal.put("POSER", new StringPrimitive(result.getPOSER()));
	        	res.addRow(returnVal);
	        }
        }

		_logger.debug("SAPServer/GetSernrUpdateInProdOrder: Exiting Service");
        return res;
	}
	
	@ThingworxServiceDefinition(name = "GetComponentsStatusRail", description = "Get Components Status (Rail) from SAP")
	@ThingworxServiceResult(name = "Result", description = "", baseType = "INFOTABLE", aspects = {"dataShape:KBSAPComponentsStatusRailDataShape"})
	public InfoTable GetComponentsStatusRail(
			@ThingworxServiceParameter(name = "ICallId", description = "ICallId", baseType = "STRING", aspects = {"isRequired:true"}) String ICallId,
			@ThingworxServiceParameter(name = "IMatnr", description = "IMatnr", baseType = "STRING", aspects = {"isRequired:true"}) String IMatnr,
			@ThingworxServiceParameter(name = "ISernr", description = "IZzaeind", baseType = "STRING", aspects = {"isRequired:true"}) String ISernr
			) throws Exception {
    	
		_logger.debug("SAPServer/GetComponentsStatusRail: Entering Service");


		com.knorr_bremse.sap_com.comp_status.Zzq_ws_conf_check_comp_status binding;
		com.knorr_bremse.sap_com.comp_status.ZZQ_WS_CONF_CHECK_COMP_STATUS_SERVICELocator service = new com.knorr_bremse.sap_com.comp_status.ZZQ_WS_CONF_CHECK_COMP_STATUS_SERVICELocator();
		service.setHttpsAddress(getStringConfigurationSetting("SAPConfiguration", "URL_SAP_Components_Status"));
		binding = service.getCONF_CHECK_COMP_STATUS();
		com.knorr_bremse.sap_com.comp_status.CONF_CHECK_COMP_STATUSStub stub = (com.knorr_bremse.sap_com.comp_status.CONF_CHECK_COMP_STATUSStub) binding;
        stub.setUsername(getStringConfigurationSetting("SAPConfiguration", "Username_SAP_Components_Status"));
        stub.setPassword(getStringConfigurationSetting("SAPConfiguration", "Password_SAP_Components_Status"));
		
		com.knorr_bremse.sap_com.comp_status.ZzqConfigReturnMessage[] message = binding.zzqConfigCheckCompStatus(ICallId, IMatnr, ISernr);

		InfoTable res = InfoTableInstanceFactory.createInfoTableFromDataShape("KBSAPComponentsStatusRailDataShape");
		
		for (int x = 0; x < message.length; x++) {
			ValueCollection returnVal = new ValueCollection();
			returnVal.put("Identifier", new StringPrimitive("Return"));
			returnVal.put("MsgLine", new StringPrimitive(message[x].getMsgLine()));
			returnVal.put("MsgType", new StringPrimitive(message[x].getMsgType()));
			returnVal.put("MsgId", new StringPrimitive(message[x].getMsgId()));
			returnVal.put("MsgNo", new StringPrimitive(message[x].getMsgNo()));
			returnVal.put("MsgV1", new StringPrimitive(message[x].getMsgV1()));
			returnVal.put("MsgV2", new StringPrimitive(message[x].getMsgV2()));
			returnVal.put("MsgV3", new StringPrimitive(message[x].getMsgV3()));
			returnVal.put("MsgV4", new StringPrimitive(message[x].getMsgV4()));
			returnVal.put("MsgTxt", new StringPrimitive(message[x].getMsgTxt()));
        	res.addRow(returnVal);
		}

		_logger.debug("SAPServer/GetComponentsStatusRail: Exiting Service");
        return res;
	}

	@ThingworxServiceDefinition(name = "SetComponentsConfiguratonRail", description = "Set Components Configuration (Rail) from SAP")
	@ThingworxServiceResult(name = "Result", description = "", baseType = "INFOTABLE", aspects = {"dataShape:KBSAPComponentsConfigurationResultRailDataShape"})
	public InfoTable SetComponentsConfiguratonRail(
			@ThingworxServiceParameter(name = "ICallId", description = "ICallId", baseType = "STRING", aspects = {"isRequired:true"}) String ICallId,
			@ThingworxServiceParameter(name = "Config", description = "Config", baseType = "INFOTABLE", aspects = {"isRequired:true", "dataShape:KBSAPComponentsConfigurationRailDataShape"}) InfoTable Config
			) throws Exception {
    	
		_logger.debug("SAPServer/SetComponentsConfiguratonRail: Entering Service");
		
		int arraySize = Config.getLength();
		com.knorr_bremse.sap_com.create_configuration.ZzqSIbaseDataFile[] itConfig = new com.knorr_bremse.sap_com.create_configuration.ZzqSIbaseDataFile[ arraySize ];
		String[] value = new String[20];
		
		for (int x = 0; x < arraySize; x++) {
			value[0] = Config.getRow(x).getStringValue("Head");
			value[1] = Config.getRow(x).getStringValue("Komat");
			value[2] = Config.getRow(x).getStringValue("Koser");
			value[3] = Config.getRow(x).getStringValue("Posmat");
			value[4] = Config.getRow(x).getStringValue("Poser");
			value[5] = Config.getRow(x).getStringValue("Batch");
			value[6] = Config.getRow(x).getStringValue("Kweek");
			value[7] = Config.getRow(x).getStringValue("Kyear");
			value[8] = Config.getRow(x).getStringValue("Zzhsdat");
			value[9] = Config.getRow(x).getStringValue("Zzwerks");
			value[10] = Config.getRow(x).getStringValue("Zzaeind");
			value[11] = Config.getRow(x).getStringValue("ZzmodifStat");
			value[12] = Config.getRow(x).getStringValue("ZzmountedBy");
			value[13] = Config.getRow(x).getStringValue("ZzapprovedBy");
			value[14] = Config.getRow(x).getStringValue("ZzcertifiedBy");
			value[15] = Config.getRow(x).getStringValue("Notice");
			value[16] = Config.getRow(x).getStringValue("Aufnr");
			value[17] = Config.getRow(x).getStringValue("FlError");
			value[18] = Config.getRow(x).getStringValue("MissingItems");
			
			for (int xx = 0;xx<20;xx++) {
				if (value[xx] == null) {
					value[xx] = "";
				}
			}

			itConfig[x] = new com.knorr_bremse.sap_com.create_configuration.ZzqSIbaseDataFile(
					value[0],
					value[1],
					value[2],
					value[3],
					value[4],
					value[5],
					value[6],
					value[7],
					value[8],
					value[9],
					value[10],
					value[11],
					value[12],
					value[13],
					value[14],
					value[15],
					value[16],
					value[17],
					value[18]);
		}		
		
		javax.xml.rpc.holders.StringHolder EFlCancel = new javax.xml.rpc.holders.StringHolder();
		javax.xml.rpc.holders.StringHolder EFlRework = new javax.xml.rpc.holders.StringHolder();
		com.knorr_bremse.sap_com.create_configuration.holders.ZzqTIbaseDataFileHolder etConfig = new com.knorr_bremse.sap_com.create_configuration.holders.ZzqTIbaseDataFileHolder();
		com.knorr_bremse.sap_com.create_configuration.holders.ZzqTConfigReturnMessageHolder etReturn = new com.knorr_bremse.sap_com.create_configuration.holders.ZzqTConfigReturnMessageHolder();
		
		com.knorr_bremse.sap_com.create_configuration.Zzq_ws_conf_create_config binding;
		com.knorr_bremse.sap_com.create_configuration.WS_CONF_CREATE_CONFIGLocator service = new com.knorr_bremse.sap_com.create_configuration.WS_CONF_CREATE_CONFIGLocator();
		service.setHttpsAddress(getStringConfigurationSetting("SAPConfiguration", "URL_SAP_Create_Configuration"));
		binding = service.getCONF_CREATE_CONFIG();
		com.knorr_bremse.sap_com.create_configuration.CONF_CREATE_CONFIGStub stub = (com.knorr_bremse.sap_com.create_configuration.CONF_CREATE_CONFIGStub) binding;
        stub.setUsername(getStringConfigurationSetting("SAPConfiguration", "Username_SAP_Create_Configuration"));
        stub.setPassword(getStringConfigurationSetting("SAPConfiguration", "Password_SAP_Create_Configuration"));
		
		binding.zzqConfigCreateConfig(ICallId, itConfig, EFlCancel, EFlRework, etConfig, etReturn);
		com.knorr_bremse.sap_com.create_configuration.ZzqConfigReturnMessage[] message = etReturn.value;

		InfoTable res = InfoTableInstanceFactory.createInfoTableFromDataShape("KBSAPComponentsConfigurationResultRailDataShape");
		
		for (int x = 0; x < message.length; x++) {
			ValueCollection returnVal = new ValueCollection();
			returnVal.put("Identifier", new StringPrimitive("Return"));
			returnVal.put("MsgLine", new StringPrimitive(message[x].getMsgLine()));
			returnVal.put("MsgType", new StringPrimitive(message[x].getMsgType()));
			returnVal.put("MsgId", new StringPrimitive(message[x].getMsgId()));
			returnVal.put("MsgNo", new StringPrimitive(message[x].getMsgNo()));
			returnVal.put("MsgV1", new StringPrimitive(message[x].getMsgV1()));
			returnVal.put("MsgV2", new StringPrimitive(message[x].getMsgV2()));
			returnVal.put("MsgV3", new StringPrimitive(message[x].getMsgV3()));
			returnVal.put("MsgV4", new StringPrimitive(message[x].getMsgV4()));
			returnVal.put("MsgTxt", new StringPrimitive(message[x].getMsgTxt()));
        	res.addRow(returnVal);
		}

		{
			ValueCollection returnVal = new ValueCollection();
			returnVal.put("Identifier", new StringPrimitive("EFlCancel"));
			returnVal.put("MsgTxt", new StringPrimitive(EFlCancel.value));
        	res.addRow(returnVal);
		}

		{
			ValueCollection returnVal = new ValueCollection();
			returnVal.put("Identifier", new StringPrimitive("EFlRework"));
			returnVal.put("MsgTxt", new StringPrimitive(EFlRework.value));
        	res.addRow(returnVal);
		}

		for (int x = 0; x < etConfig.value.length; x++) {
			ValueCollection message1 = new ValueCollection();
			message1.put("Identifier", new StringPrimitive("Config"));
			message1.put("Head", new StringPrimitive(etConfig.value[x].getHead()));
			message1.put("Komat", new StringPrimitive(etConfig.value[x].getKomat()));
			message1.put("Koser", new StringPrimitive(etConfig.value[x].getKoser()));
			message1.put("Posmat", new StringPrimitive(etConfig.value[x].getPosmat()));
			message1.put("Poser", new StringPrimitive(etConfig.value[x].getPoser()));
			message1.put("Batch", new StringPrimitive(etConfig.value[x].getBatch()));
			message1.put("Zzwerks", new StringPrimitive(etConfig.value[x].getZzwerks()));
			message1.put("Zzaeind", new StringPrimitive(etConfig.value[x].getZzaeind()));
			message1.put("ZzmodifStat", new StringPrimitive(etConfig.value[x].getZzmodifStat()));
			message1.put("ZzmountedBy", new StringPrimitive(etConfig.value[x].getZzmountedBy()));
			message1.put("ZzapprovedBy", new StringPrimitive(etConfig.value[x].getZzapprovedBy()));
			message1.put("ZzcertifiedBy", new StringPrimitive(etConfig.value[x].getZzcertifiedBy()));
			message1.put("Notice", new StringPrimitive(etConfig.value[x].getNotice()));
			message1.put("Aufnr", new StringPrimitive(etConfig.value[x].getAufnr()));
			message1.put("MissingItems", new StringPrimitive(etConfig.value[x].getMissingItems()));
			message1.put("FlError", new StringPrimitive(etConfig.value[x].getFlError()));
			message1.put("Kweek", new StringPrimitive(etConfig.value[x].getKweek()));
			message1.put("Kyear", new StringPrimitive(etConfig.value[x].getKyear()));
			message1.put("Zzhsdat", new StringPrimitive(etConfig.value[x].getZzhsdat()));

			value[6] = Config.getRow(x).getStringValue("");
			value[7] = Config.getRow(x).getStringValue("");
			value[8] = Config.getRow(x).getStringValue("");
			res.addRow(message1);
		}

		_logger.debug("SAPServer/SetComponentsConfiguratonRail: Exiting Service");
        return res;
	}

	
	@Override
	 protected void startThing(ContextType contextType) throws Exception {
		 try {
			 workingtimestatus = "Not Started on System " + getName();
			 //partsperoperationstatus = "Not Started on System " + getName();
			 // System.out.println("SAPServer startThing: startThing workingtimestatus: "+workingtimestatus+", partsperoperationstatus: "+partsperoperationstatus);
			 System.out.println("SAPServer startThing: startThing workingtimestatus: "+workingtimestatus);
			 if (getName().equals("KBRailSAPServer")) {
				 workingtimestatus = "Starting on System" + getName()+"...";
				//  System.out.println("SAPServer KBRailSAPServer startThing: startThing workingtimestatus: "+workingtimestatus+", partsperoperationstatus: "+partsperoperationstatus);
				 System.out.println("SAPServer KBRailSAPServer startThing: startThing workingtimestatus: "+workingtimestatus);
				 initPlannedWorkingTime();
				 workingtimestatus = "Init done on System" + getName();
				 // System.out.println("SAPServer KBRailSAPServer startThing: startThing workingtimestatus: "+workingtimestatus+", partsperoperationstatus: "+partsperoperationstatus);
				  System.out.println("SAPServer KBRailSAPServer startThing: startThing workingtimestatus: "+workingtimestatus);
			 } else if (getName().equals("KBTruckSAPServer")) {
				 workingtimestatus = "Starting on System" + getName()+"...";
				 // System.out.println("SAPServer KBTruckSAPServer startThing: startThing workingtimestatus: "+workingtimestatus+", partsperoperationstatus: "+partsperoperationstatus);
				 System.out.println("SAPServer KBTruckSAPServer startThing: startThing workingtimestatus: "+workingtimestatus);
				 initPlannedWorkingTime();
				 workingtimestatus = "Init done on System" + getName();
				 // System.out.println("SAPServer KBTruckSAPServer startThing: startThing workingtimestatus: "+workingtimestatus+", partsperoperationstatus: "+partsperoperationstatus);
				 System.out.println("SAPServer KBTruckSAPServer startThing: startThing workingtimestatus: "+workingtimestatus);
	
				 //partsperoperationstatus = "Starting on System" + getName()+"...";
				 // System.out.println("SAPServer KBTruckSAPServer startThing: startThing workingtimestatus: "+workingtimestatus+", partsperoperationstatus: "+partsperoperationstatus);
				 System.out.println("SAPServer KBTruckSAPServer startThing: startThing workingtimestatus: "+workingtimestatus);
				 //initPartsPerOperation();
				 //partsperoperationstatus = "Init done on System" + getName();
				 // System.out.println("SAPServer KBTruckSAPServer startThing: startThing workingtimestatus: "+workingtimestatus+", partsperoperationstatus: "+partsperoperationstatus);
				 System.out.println("SAPServer KBTruckSAPServer startThing: startThing workingtimestatus: "+workingtimestatus);
			 }
		 } catch (Exception e) {
			//TODO Auto-generated catch block
			 System.out.println("SAPServer: Error during start: "+e.toString());
		 }
			
	 }

	private void initPlannedWorkingTime() throws ServiceException {
		
		System.out.println("SAPServer: initPlannedWorkingTime Start");
		
		String HttpsAddress = getStringConfigurationSetting("SAPConfiguration", "URL_APO_ShiftCalendar");
		String HttpAddress = getStringConfigurationSetting("SAPConfiguration", "URL_APO_ShiftCalendar");
		String Username = getStringConfigurationSetting("SAPConfiguration", "Username_APO_ShiftCalendar");
		String Password = getStringConfigurationSetting("SAPConfiguration", "Password_APO_ShiftCalendar");

		System.out.println("SAPServer initPlannedWorkingTime: "+HttpsAddress);
		System.out.println("SAPServer initPlannedWorkingTime: "+HttpAddress);
		System.out.println("SAPServer initPlannedWorkingTime: "+Username);
		//System.out.println("SAPServer initPlannedWorkingTime: "+Password);
		
		com.knorr_bremse.sap_com.plannedWorkingTime.SI_OUT_Worx_PlannedWorkingTime_SYNCService service = new com.knorr_bremse.sap_com.plannedWorkingTime.SI_OUT_Worx_PlannedWorkingTime_SYNCServiceLocator();
		service.setHttpsAddress(HttpsAddress);
		service.setHttpAddress(HttpAddress);
		
		bindingPlannedWorkingTime = service.getHTTPS_Port();
		com.knorr_bremse.sap_com.plannedWorkingTime.SI_OUT_Worx_PlannedWorkingTime_SYNCBindingStub stub = (com.knorr_bremse.sap_com.plannedWorkingTime.SI_OUT_Worx_PlannedWorkingTime_SYNCBindingStub) bindingPlannedWorkingTime;
        stub.setUsername(Username);
        stub.setPassword(Password);
		System.out.println("SAPServer: initPlannedWorkingTime OK");
	}

	@ThingworxServiceDefinition(name = "GetWorkingTimeStatus", description = "")
	@ThingworxServiceResult(name = "Result", description = "", baseType = "STRING")
	public String GetWorkingTimeStatus() throws Exception {
    	
        return workingtimestatus;
	}
} 
