package com.ptc.kb.sap;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import com.thingworx.metadata.DataShapeDefinition;
import com.thingworx.metadata.FieldDefinition;
import com.thingworx.metadata.annotations.ThingworxConfigurationTableDefinition;
import com.thingworx.metadata.annotations.ThingworxConfigurationTableDefinitions;
import com.thingworx.metadata.annotations.ThingworxDataShapeDefinition;
import com.thingworx.metadata.annotations.ThingworxFieldDefinition;
import com.thingworx.metadata.annotations.ThingworxPropertyDefinition;
import com.thingworx.metadata.annotations.ThingworxPropertyDefinitions;
import com.thingworx.metadata.annotations.ThingworxServiceDefinition;
import com.thingworx.metadata.annotations.ThingworxServiceParameter;
import com.thingworx.metadata.annotations.ThingworxServiceResult;
import com.thingworx.metadata.collections.FieldDefinitionCollection;
import com.thingworx.system.ContextType;
import com.thingworx.things.Thing;
import com.thingworx.types.InfoTable;
import com.thingworx.types.collections.ValueCollection;
import com.thingworx.types.primitives.BooleanPrimitive;
import com.thingworx.types.primitives.IntegerPrimitive;
import com.thingworx.types.primitives.LongPrimitive;
import com.thingworx.types.primitives.StringPrimitive;
import com.thingworx.webservices.context.ThreadLocalContext;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileInputStream;
import jcifs.smb.SmbFileOutputStream;

@ThingworxPropertyDefinitions(properties = {
		@ThingworxPropertyDefinition(name = "LastExportStart", description = "Last start of Fastems Import", baseType = "DATETIME", category = "SMB", aspects = {
		"isPersistent:true" }),
		@ThingworxPropertyDefinition(name = "LastExportStart", description = "Last start of Fastems Import", baseType = "DATETIME", category = "SMB", aspects = {
				"isPersistent:true" }),
		@ThingworxPropertyDefinition(name = "LastExportEnd", description = "Last end of Fastems Import", baseType = "DATETIME", category = "SMB", aspects = {
				"isPersistent:true" }),
		@ThingworxPropertyDefinition(name = "ExportStatus", description = "Last end of Fastems Import", baseType = "STRING", category = "SMB", aspects = {
				"isPersistent:true" }),
		@ThingworxPropertyDefinition(name = "isSAPConfigConnected", description = "SMB isConnected", baseType = "BOOLEAN", category = "SMB", aspects = {
				"isPersistent:false", "defaultValue:false" }) })
@ThingworxConfigurationTableDefinitions(tables = {
		@ThingworxConfigurationTableDefinition(name = "KBsapConfigConnectorConfigurationTable", description = "", isMultiRow = false, ordinal = 0, 
												dataShape = @ThingworxDataShapeDefinition(fields = {
				@ThingworxFieldDefinition(name = "Domain", description = "", baseType = "STRING", ordinal = 0, aspects = { "isRequired:false" }),
				@ThingworxFieldDefinition(name = "Username", description = "", baseType = "STRING", ordinal = 0, aspects = { "isRequired:false" }),
				@ThingworxFieldDefinition(name = "Password", description = "", baseType = "PASSWORD", ordinal = 0, aspects = { "isRequired:false" }),
				@ThingworxFieldDefinition(name = "TestUrl", description = "", baseType = "STRING", ordinal = 0, aspects = { "isRequired:false" }),
				@ThingworxFieldDefinition(name = "TargetUrl", description = "", baseType = "STRING", ordinal = 0, aspects = { "isRequired:false" }),
				@ThingworxFieldDefinition(name = "DeleteFilesAfterExport", description = "", baseType = "BOOLEAN", ordinal = 0, aspects = { "isRequired:false" })
				})) })

@SuppressWarnings("serial")
public class KBsapConfigConnectorTemplate extends Thing {

	private boolean _isSAPConfigConnected;
	private String _domain = null;
	private String _username = null;
	private String _password = null;
	private String _testUrl = null;
	private String _targetUrl = null;

	public KBsapConfigConnectorTemplate() {

	}

	public KBsapConfigConnectorTemplate(String domain, String username, String password, String testUrl) {
		_domain = domain;
		_username = username;
		_password = password;
		_testUrl = testUrl;
	}

	private void init() {
		System.out.println("KBsapConfigConnectorTemplate: init Start");
	    _domain = (String) this.getConfigurationSetting("KBsapConfigConnectorConfigurationTable", "Domain");
	    _username = (String) this.getConfigurationSetting("KBsapConfigConnectorConfigurationTable", "Username");
	    _testUrl = (String) this.getConfigurationSetting("KBsapConfigConnectorConfigurationTable", "TestUrl");
	    _targetUrl = (String) this.getConfigurationSetting("KBsapConfigConnectorConfigurationTable", "TargetUrl");
	    _password = (String) this.getConfigurationSetting("KBsapConfigConnectorConfigurationTable", "Password");

		System.out.println("KBsapConfigConnectorTemplate: init "+_domain);
		System.out.println("KBsapConfigConnectorTemplate: init "+_username);
		System.out.println("KBsapConfigConnectorTemplate: init "+_testUrl);
		System.out.println("KBsapConfigConnectorTemplate: init "+_targetUrl);
	    System.out.println("KBsapConfigConnectorTemplate: init OK");
	}
	
	@Override
	public void initializeThing(ContextType contextType) throws Exception {
	    super.initializeThing(contextType);
	    init();
	}

	@Override
	public void startThing(ContextType contextType) throws Exception {
	    super.startThing(contextType);
	    init();

		System.out.println("KBsapConfigConnectorTemplate: startThing Start");
		// Retrieves the &quot;me&quot; context for the current thread.
		Object me = ThreadLocalContext.getMeContext();

		// Ensure we have a Thing object before attempting to cast the result to Thing.
		if (me instanceof Thing) {
			Thing meThing = (Thing) me;
			// Do further operations requiring the &quot;me&quot; context using the meThing
			// object.
			
			System.out.println("KBsapConfigConnectorTemplate: startThing "+meThing.getName());
			if (_username != "" && _password != "" && _testUrl != "") {
				if (SMB_Init_Worker()) {
					meThing.setPropertyValue("isSAPConfigConnected", new BooleanPrimitive(_isSAPConfigConnected));
				}
			}
		}
		System.out.println("KBsapConfigConnectorTemplate: startThing OK");
	}	
	
	protected boolean SMB_Init_Worker() throws Exception {
		boolean result = false;

		SmbFile dir = null;

		try {
			NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication(_domain, _username, _password);
			dir = new SmbFile(_testUrl, auth);
			dir.listFiles();
			_isSAPConfigConnected = true;
			result = true;
		} catch (Exception e) {
			_isSAPConfigConnected = false;
			throw new Exception(e);
		}

		return result;
	}

	protected SmbFile[] SMB_Dir_worker(String url) throws Exception {
		SmbFile dir = null;
		SmbFile[] files = null;
		if (_username != "" && _password != "" && _testUrl != "" && SMB_Init_Worker()) {
			try {
				NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication(_domain, _username, _password);
				dir = new SmbFile(url, auth);
				files = dir.listFiles();
			} catch (Exception e) {
				throw new Exception(e);
			}
		}
		return files;
	}

	@ThingworxServiceDefinition(name = "SMB_Dir", description = "", category = "ThingWorxSystem", isAllowOverride = false, aspects = {
			"isAsync:false" })
	@ThingworxServiceResult(name = "Result", description = "", baseType = "INFOTABLE", aspects = {})
	public InfoTable SMB_Dir(
			@ThingworxServiceParameter(name = "url", description = "url", baseType = "STRING", aspects = {
					"isRequired:true" }) String url)
			throws Exception {
		InfoTable fileInfotable = new InfoTable();
		DataShapeDefinition dsd = new DataShapeDefinition();
		FieldDefinitionCollection fields = new FieldDefinitionCollection();
		fields.addFieldDefinition(new FieldDefinition("Name", "STRING"));
		fields.addFieldDefinition(new FieldDefinition("isFile", "BOOLEAN"));
		fields.addFieldDefinition(new FieldDefinition("isDirectory", "BOOLEAN"));
		fields.addFieldDefinition(new FieldDefinition("isHidden", "BOOLEAN"));
		fields.addFieldDefinition(new FieldDefinition("Attributes", "INTEGER"));
		fields.addFieldDefinition(new FieldDefinition("Date", "LONG"));
		// fields.addFieldDefinition(new FieldDefinition("CanonicalPath", "STRING"));
		// fields.addFieldDefinition(new FieldDefinition("CanonicalUNCPath", "STRING"));
		fields.addFieldDefinition(new FieldDefinition("Path", "STRING"));
		fields.addFieldDefinition(new FieldDefinition("UNCPath", "STRING"));

		dsd.setFields(fields);
		fileInfotable.setDataShape(dsd);
		ValueCollection vc;

		SmbFile[] files = SMB_Dir_worker(url);
		for (int i = 0; i < files.length; i++) {
			vc = new ValueCollection();
			vc.put("Name", new StringPrimitive(files[i].getName()));
			vc.put("isFile", new BooleanPrimitive(files[i].isFile()));
			vc.put("isDirectory", new BooleanPrimitive(files[i].isDirectory()));
			vc.put("isHidden", new BooleanPrimitive(files[i].isHidden()));
			vc.put("Attributes", new IntegerPrimitive(files[i].getAttributes()));
			vc.put("Date", new LongPrimitive(files[i].getDate()));
			// vc.put("CanonicalPath", new StringPrimitive(files[i].getCanonicalPath()));
			// vc.put("CanonicalUNCPath", new
			// StringPrimitive(files[i].getCanonicalUncPath()));
			vc.put("Path", new StringPrimitive(files[i].getPath()));
			vc.put("UNCPath", new StringPrimitive(files[i].getUncPath()));

			fileInfotable.AddRow(vc.toJSON());
		}

		// Retrieves the &quot;me&quot; context for the current thread.
		Object me = ThreadLocalContext.getMeContext();

		// Ensure we have a Thing object before attempting to cast the result to Thing.
		if (me instanceof Thing) {
			Thing meThing = (Thing) me;
			// Do further operations requiring the &quot;me&quot; context using the meThing
			// object.
			meThing.setPropertyValue("isSAPConfigConnected", new BooleanPrimitive(_isSAPConfigConnected));
		}

		return fileInfotable;
	}

	protected Boolean SMB_Write_Text_worker(String url, String content) throws Exception {

		SmbFileOutputStream sfos = null;
		SmbFile dir = null;
		boolean result = false;
		if (_username != "" && _password != "" && _testUrl != "" && SMB_Init_Worker()) {
			try {

				NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication(_domain, _username, _password);
				dir = new SmbFile(url, auth);
				sfos = new SmbFileOutputStream(dir);
				sfos.write(content.getBytes());
				result = true;
			} catch (Exception e) {
				throw new Exception(e);
			} finally {
				if (sfos != null && sfos.isOpen()) {
					try {
						sfos.close();
					} catch (Exception ex) {
					}
				}
			}
		}
		return result;
	}

	protected Boolean SMB_Write_Binary_worker(String url, byte[] content) throws Exception {

		SmbFileOutputStream sfos = null;
		SmbFile dir = null;
		boolean result = false;
		if (_username != "" && _password != "" && _testUrl != "" && SMB_Init_Worker()) {
			try {

				NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication(_domain, _username, _password);
				dir = new SmbFile(url, auth);
				sfos = new SmbFileOutputStream(dir);
				sfos.write(content);
				result = true;
			} catch (Exception e) {
				throw new Exception(e);
			} finally {
				if (sfos != null && sfos.isOpen()) {
					try {
						sfos.close();
					} catch (Exception ex) {
					}
				}
			}
		}
		return result;
	}

	@ThingworxServiceDefinition(name = "SMB_Write_Binary", description = "", category = "ThingWorxSystem", isAllowOverride = false, aspects = {
			"isAsync:false" })
	@ThingworxServiceResult(name = "Result", description = "", baseType = "BOOLEAN", aspects = {})
	public Boolean SMB_Write_Binary(
			@ThingworxServiceParameter(name = "url", description = "url", baseType = "STRING", aspects = {
					"isRequired:true" }) String url,
			@ThingworxServiceParameter(name = "content", description = "content", baseType = "BLOB", aspects = {
					"isRequired:false" }) byte[] content)
			throws Exception {
		boolean result = SMB_Write_Binary_worker(url, content);

		// Retrieves the &quot;me&quot; context for the current thread.
		Object me = ThreadLocalContext.getMeContext();

		// Ensure we have a Thing object before attempting to cast the result to Thing.
		if (me instanceof Thing) {
			Thing meThing = (Thing) me;
			// Do further operations requiring the &quot;me&quot; context using the meThing
			// object.
			meThing.setPropertyValue("isSAPConfigConnected", new BooleanPrimitive(_isSAPConfigConnected));
		}

		return result;

	}

	@ThingworxServiceDefinition(name = "SMB_Write_Text", description = "", category = "ThingWorxSystem", isAllowOverride = false, aspects = {
			"isAsync:false" })
	@ThingworxServiceResult(name = "Result", description = "", baseType = "BOOLEAN", aspects = {})
	public Boolean SMB_Write_Text(
			@ThingworxServiceParameter(name = "url", description = "url", baseType = "STRING", aspects = {
					"isRequired:true" }) String url,
			@ThingworxServiceParameter(name = "content", description = "content", baseType = "STRING", aspects = {
					"isRequired:false" }) String content)
			throws Exception {
		boolean result = SMB_Write_Text_worker(url, content);

		// Retrieves the &quot;me&quot; context for the current thread.
		Object me = ThreadLocalContext.getMeContext();

		// Ensure we have a Thing object before attempting to cast the result to Thing.
		if (me instanceof Thing) {
			Thing meThing = (Thing) me;
			// Do further operations requiring the &quot;me&quot; context using the meThing
			// object.
			meThing.setPropertyValue("isSAPConfigConnected", new BooleanPrimitive(_isSAPConfigConnected));
		}

		return result;

	}

	protected String SMB_Read_Text_worker(String url) throws Exception {

		SmbFileInputStream sfis = null;
		SmbFile dir = null;
		String result = null;
		if (_username != "" && _password != "" && _testUrl != "" && SMB_Init_Worker()) {
			try {

				NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication(_domain, _username, _password);
				dir = new SmbFile(url, auth);
				sfis = new SmbFileInputStream(dir);

				try (BufferedReader reader = new BufferedReader(new InputStreamReader(sfis))) {
					String line = reader.readLine();
					result = "";
					while (line != null) {
						result += "\n" + line;
						line = reader.readLine();
					}
				}
			} catch (Exception e) {
				throw new Exception(e);
			} finally {
				if (sfis != null) {
					try {
						sfis.close();
					} catch (Exception ex) {
					}
				}
			}
		}
		return result;
	}

	@ThingworxServiceDefinition(name = "SMB_Read_Text", description = "", category = "ThingWorxSystem", isAllowOverride = false, aspects = {
			"isAsync:false" })
	@ThingworxServiceResult(name = "Result", description = "", baseType = "STRING", aspects = {})
	public String SMB_Read_Text(
			@ThingworxServiceParameter(name = "url", description = "url", baseType = "STRING", aspects = {
					"isRequired:true" }) String url)
			throws Exception {
		String result = SMB_Read_Text_worker(url);

		// Retrieves the &quot;me&quot; context for the current thread.
		Object me = ThreadLocalContext.getMeContext();

		// Ensure we have a Thing object before attempting to cast the result to Thing.
		if (me instanceof Thing) {
			Thing meThing = (Thing) me;
			// Do further operations requiring the &quot;me&quot; context using the meThing
			// object.
			meThing.setPropertyValue("isSAPConfigConnected", new BooleanPrimitive(_isSAPConfigConnected));
		}

		return result;

	}

	protected Boolean SMB_Delete_worker(String url) throws Exception {

		boolean result = false;
		SmbFile dir = null;

		if (_username != "" && _password != "" && _testUrl != "" && SMB_Init_Worker()) {
			try {
				NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication(_domain, _username, _password);
				dir = new SmbFile(url, auth);
				dir.delete();
				result = true;
			} catch (Exception e) {
				throw new Exception(e);
			}
		}

		return result;
	}

	@ThingworxServiceDefinition(name = "SMB_Delete", description = "", category = "ThingWorxSystem", isAllowOverride = false, aspects = {
			"isAsync:false" })
	@ThingworxServiceResult(name = "Result", description = "", baseType = "BOOLEAN", aspects = {})
	public Boolean SMB_Delete(
			@ThingworxServiceParameter(name = "url", description = "url", baseType = "STRING", aspects = {
					"isRequired:true" }) String url)
			throws Exception {

		boolean result = SMB_Delete_worker(url);

		// Retrieves the &quot;me&quot; context for the current thread.
		Object me = ThreadLocalContext.getMeContext();

		// Ensure we have a Thing object before attempting to cast the result to Thing.
		if (me instanceof Thing) {
			Thing meThing = (Thing) me;
			// Do further operations requiring the &quot;me&quot; context using the meThing
			// object.
			meThing.setPropertyValue("isSAPConfigConnected", new BooleanPrimitive(_isSAPConfigConnected));
		}

		return result;
	}

}
