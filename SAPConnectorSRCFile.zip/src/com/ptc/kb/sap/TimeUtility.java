package com.ptc.kb.sap;


import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class TimeUtility {

	private final static DateTimeFormatter FORMATTER = DateTimeFormat
			.forPattern("yyyy-MM-dd HH:mm:ss")
			.withZone(DateTimeZone.forID("Europe/Berlin"));
	
	// date: 2015-12-20
	// time: 22:30:00 or 24:00:00
	public static DateTime makeTimestamp(String date, String time) {
		boolean addOneDay = time.equals("24:00:00");
		if (addOneDay) {
			time = "00:00:00";
		}
		DateTime res = FORMATTER.parseDateTime(date + " " + time);
		return addOneDay ? res.plusDays(1) : res;
	}
	

}
