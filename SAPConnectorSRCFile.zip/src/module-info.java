/**
 * 
 */
/**
 * @author flassakm
 *
 */
module TWX_Ext_KBsapConnector {
	exports com.knorr_bremse.clients;
	exports com.knorr_bremse.sap_com.comp_status;
	exports com.knorr_bremse.sap_com.components_check;
	exports com.knorr_bremse.sap_com.components_check.holders;
	exports com.knorr_bremse.sap_com.create_configuration;
	exports com.knorr_bremse.sap_com.create_configuration.holders;
	exports com.knorr_bremse.sap_com.plannedCapa;
	exports com.knorr_bremse.sap_com.plannedCapa.holders;
	exports com.knorr_bremse.sap_com.plannedWorkingTime;
	exports com.knorr_bremse.sap_com.sernrUpdateInProdOrder;
	exports com.knorr_bremse.sap_com.sernrUpdateInProdOrder.holders;
	exports com.knorr_bremse.sap_com.testReportUpload;
	exports com.knorr_bremse.sap_com.testReportUpload.holders;
	exports com.ptc.kb.sap;
	requires jaxrpc;
	requires java.rmi;
	requires org.joda.time;
	requires axis;
	requires java.xml;
	requires thingworx.ext.sdk;
	requires jcifs;
	requires org.slf4j;
	requires java.naming;
	requires java.sql;
}